# adas-brake-arbiter

The agent writes `/app/controller.py`, the longitudinal control policy of a forward collision
system. It is driven in closed loop: the verifier owns the simulator, sends one observation per
50 Hz step, and the acceleration the controller returns changes the state it is shown next. Grading
replays fourteen sealed scenarios on four vehicle builds the agent never sees.

## Difficulty

Four independent pieces of judgement all have to be right at once, and each of them is two sided,
so neither the cautious nor the aggressive extreme passes.

The radar emits false tracks that appear ahead of the ego, close on it quickly and vanish inside a
second. Braking for them costs unjustified braking events and, because the ego then has to recover
its speed, costs progress as well. But the scenarios also contain vehicles that were screened by the
one in front and are reported for the first time at 56 to 70 metres, already closing, with no track
history at all, which is exactly the signature of a false track at the moment it appears. Rejecting
anything young loses those. Quality helps on average and separates nothing on its own: real
detections average 0.86, false ones run 0.50 to 0.80, and the ranges overlap. What works is
releasing braking authority in proportion to the evidence a track has accumulated, which is a
policy, not a threshold. Removing it costs 43 unjustified braking events against the reference's
zero, and 4.731 m/s of speed shortfall against 0.634.

The radar also loses a real vehicle for windows up to 0.78 seconds, and one of those windows always
lands just after the lead starts braking hard. A controller that drops the target when the detection
stops will accelerate into a closing gap and then have to recover from a fresh, low confidence
track. Removing the coasting produces an actual collision in one of the fourteen scenarios, and it
is the only bar that variant fails.

Target selection is the third piece. Vehicles travel in the neighbouring lanes without ever entering
the ego path, and one scenario contains nothing else, so a controller that simply takes the nearest
track brakes for traffic that was never in its way: four unjustified braking events and a speed
shortfall of 5.502 m/s against 0.634. A vehicle that is changing lanes has to be picked up before it
finishes arriving, which is why the lateral offset has to be extrapolated rather than thresholded.

The fourth is estimating how hard the vehicle ahead is decelerating rather than reacting only to the
closing speed, which the three emergency braking scenarios punish: removing it takes time spent
inside a safe following distance from 0.00 s to 4.70 s against a 3.0 s bar, and that is the only
bar it fails.

The data is synthetic and this is disclosed. A seeded generator
(`authoring/provenance/gen_scenarios.py`) scripts every road user in absolute road coordinates
before any controller runs, so the trajectories grading is based on never depend on the solver. A
scenario is rejected unless a controller handed the true object states still keeps a 3.0 m gap on
that build, and any scenario containing a lane change is rejected unless the merging vehicle is
still at least 18 m ahead when the change completes. Closed loop is what keeps the difficulty out of
reach of a solver that reconstructs the simulator, which is the failure mode a previous task in this
series ran into: the agent's own commands determine what it sees next, and the four graded builds
differ from the development vehicle in transport delay, brake dead time, lag constant, delivered
braking fraction and radar noise, so a policy fitted to the development car's timing is being asked
to generalise. What the builds are not is the hard part in their own right; that is stated honestly
in `authoring/evidence/results.md`, which records that online identification of the actuator was
built, measured, found not to be load bearing and removed rather than claimed.

CPU only, `gpus = 0`. The workload is a strictly sequential 50 Hz control loop over a handful of
tracks: there is nothing to batch and a device would sit idle.

## Reference solution

`solution/controller.py`. Tracks are maintained per radar track number with an alpha beta filter on
range and a filtered lateral rate. A track is in path if its lateral offset is inside 1.7 m or if
extrapolating its lateral rate over 1.1 s brings it inside while it is still moving inward, which
picks up a lane change before it completes. The nearest in path track becomes the target. The demand
is the smaller of a cruise term, a constant time gap feedback term at 1.55 s plus 5.5 m, and the
deceleration required to avoid the target given the closing speed and the estimated deceleration of
the vehicle ahead. Both the gap and the ego speed are propagated forward by the assumed actuator lag
before any of that is computed, so the policy acts on the state the car will be in when the command
bites.

The part that carries the task is the authority limit. A track first seen beyond 75 m, or one that
has simply been present for 2.1 s, is a vehicle and gets the whole brake. Anything else earns
authority on a ramp that stays deliberately weak while a false track could still plausibly be alive
and then opens quickly once this one has outlived one, with the knee moved by detection quality. The
limit is applied to the command that is actually sent and not only to the demand, because the lag
inversion would otherwise multiply straight past it, which is a mistake that cost a large number of
false braking events during authoring before it was found.

Targets are coasted for up to 0.9 s after the last detection, which is sized against the generator's
0.78 s ceiling on a blind window.

## Verification

`tests/harness.py` runs the agent's program as an unprivileged user in an empty directory, one
scenario per process, in its own session, killing the process group in a finally block; the
scenarios, the builds and the plant live under `/tests` readable by root only, and `test.sh` makes
`/logs/verifier` root owned and mode 700 before pytest starts, so the reward channel is out of reach
of the program the verifier executes. The controller sees one step at a time and cannot read ahead.

Four bars, measured over all fourteen scenarios together: no collision, at most 3.0 s spent closer
to the vehicle ahead than 0.9 times the ego speed plus 2.0 m, at most 2 unjustified braking events,
and at most 2.0 m/s mean speed shortfall on clear road. The reference scores 0 collisions, 0.00 s,
0 events and 0.634 m/s. An independently written controller, different at every stage (least squares
fits over a sliding window instead of alpha beta filters, an evidence counter in frames and metres
traversed instead of a confidence ramp, and a safety distance rule instead of gap error feedback),
scores 0, 0.64 s, 1 event and 0.515 m/s. Across the broken variants the strongest reaches 4.70 s of
unsafe time, 43 braking events and 17.529 m/s of shortfall, and three of them collide, so every bar
sits between the weakest correct controller and the strongest broken one. Six perturbations of the
reference's own design constants all pass, at worst 1.76 s of unsafe time against the 3.0 s bar.

A time to collision shortcut of the kind written in a few minutes fails all four bars. Two do
nothing baselines, one commanding zero and one holding the set speed while ignoring every track,
each collide in 12 of the 14 scenarios; the only two they clear are the clear road and neighbouring
lane scenarios, whose designed role is to punish braking that nothing asked for. A controller that
stays safe by never going anywhere fails on progress alone at 17.529 m/s, and one that brakes at
full authority for every track it sees fails on braking events at 22 while passing the shortfall
bar at 1.042 m/s, which is what shows those two bars are not duplicates.

Minimum gap and jerk are recorded but not graded, and `authoring/evidence/results.md` explains why
each was dropped rather than kept as an extra way for a correct controller to fail. That file also
records two defects an agentic review found in an earlier version of this bundle, a collision check
that could never fire and a cut in scenario whose merge completed behind the ego, along with what
was changed and how each fix was verified. Every number here is reproducible with
`python authoring/evidence/evaluate.py`.
