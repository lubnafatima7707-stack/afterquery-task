import json, os, sys
HERE=os.path.dirname(os.path.abspath(__file__)); ROOT=os.path.abspath(os.path.join(HERE,"..",".."))
sys.path.insert(0,os.path.join(ROOT,"tests")); sys.path.insert(0,os.path.join(ROOT,"solution")); sys.path.insert(0,HERE)
import plant, scoring, controller as ref
from evaluate import run_one, load, reference
d=load(os.path.join(ROOT,"tests","hidden","scenarios.json"))
kw={}
for a in sys.argv[1:]:
    k,v=a.split("="); kw[k]= (v=="True")
f=reference(**kw)
for spec in d["scenarios"]:
    b=d["builds"][spec["build"]]
    m=run_one(f,spec,b,spec["seed"])
    print("%-16s %-7s gap=%6.2f uns=%5.2f fb=%-3d jerk_rms=%6.3f deficit=%6.3f meanv=%5.1f coll=%s" % (
        spec["kind"], spec["build"], m["min_gap_m"], m["unsafe_s"], m["false_brake_events"],
        (m["jerk_sq_sum"]/max(m["jerk_n"],1))**0.5, m["deficit_sum"]/max(m["deficit_n"],1),
        m["mean_speed_mps"], m["collided"]))
