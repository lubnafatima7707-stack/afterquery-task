"""
Rescores the reference controller, its ablations, its tuning perturbations, an
independently written controller and a shortcut baseline against the sealed
hidden scenarios, using the verifier's own metric code.

    python authoring/evidence/evaluate.py            # everything
    python authoring/evidence/evaluate.py --group ablation

Writes results.json beside this file. Controllers run in process here; the verifier
drives the same logic over the line protocol in a subprocess, and the command is
rounded to the protocol's four decimals here so the two agree exactly.
"""
import argparse
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "tests"))
sys.path.insert(0, os.path.join(ROOT, "solution"))
sys.path.insert(0, HERE)

import plant  # noqa: E402
import scoring  # noqa: E402
import controller as ref  # noqa: E402


def load(path):
    with open(path) as f:
        return json.load(f)


def run_one(factory, spec, build_d, seed):
    build = plant.Build(build_d)
    sim = plant.Sim(spec, build, seed)
    ctl = factory(plant.DT, sim.v_set, plant.A_MIN, plant.A_MAX)
    for k in range(sim.n_steps):
        t, v_meas, a_meas, rows = sim.observation(k)
        # Quantise exactly as the line protocol does, so what the controller sees
        # here is what it would see through the verifier, digit for digit.
        t = float("%.3f" % t)
        v_meas = float("%.4f" % v_meas)
        a_meas = float("%.4f" % a_meas)
        rows2 = [(int(r[0]),) + tuple(float("%.4f" % float(x)) for x in r[1:5]) for r in rows]
        a = ctl.step(t, v_meas, a_meas, rows2)
        # The protocol carries the command as "%.4f", so round here too and the
        # evidence reproduces what the verifier actually applies, to the digit.
        sim.step(k, float("%.4f" % a))
    return scoring.scenario_metrics(sim.log, sim.v_set)


def run_all(factory, data):
    per = []
    for spec in data["scenarios"]:
        build_d = data["builds"][spec["build"]] if "build" in spec else list(data["builds"].values())[0]
        per.append(run_one(factory, spec, build_d, spec["seed"]))
    return per, scoring.aggregate(per)


def reference(**kw):
    def f(dt, v_set, a_min, a_max):
        return ref.Controller(dt, v_set, a_min, a_max, **kw)
    return f


def knob(mod):
    """The reference with one design constant moved."""
    def f(dt, v_set, a_min, a_max):
        return ref.Controller(dt, v_set, a_min, a_max, **mod)
    return f


def variants(group):
    v = []
    v.append(("reference", "solution/controller.py", reference(), "all"))
    v.append(("no graded threat confidence", "graded=False", reference(graded=False), "ablation"))
    v.append(("no coasting through dropouts", "coast=False", reference(coast=False), "ablation"))
    v.append(("no lateral target selection", "lateral=False", reference(lateral=False), "ablation"))
    v.append(("no lead acceleration estimate", "lead_accel=False", reference(lead_accel=False), "ablation"))
    for label, mod in (("time gap 1.40 s", dict(time_gap_s=1.40)),
                       ("time gap 1.70 s", dict(time_gap_s=1.70)),
                       ("full authority at 1.8 s", dict(full_authority_s=1.8)),
                       ("full authority at 2.5 s", dict(full_authority_s=2.5)),
                       ("coast window 0.7 s", dict(coast_max_s=0.7)),
                       ("in path gate 1.5 m", dict(in_path_m=1.5))):
        v.append(("reference, " + label, repr(mod), knob(mod), "perturb"))
    try:
        import independent_controller as ind
        v.append(("independent controller", "independent_controller.py",
                  lambda dt, vs, lo, hi: ind.Controller(dt, vs, lo, hi), "all"))
    except ImportError:
        pass
    try:
        import shortcut_controller as sc
        v.append(("shortcut baseline", "shortcut_controller.py",
                  lambda dt, vs, lo, hi: sc.Controller(dt, vs, lo, hi), "all"))
        v.append(("crawler baseline", "shortcut_controller.py Crawler",
                  lambda dt, vs, lo, hi: sc.Crawler(dt, vs, lo, hi), "all"))
        v.append(("null (commands nothing)", "shortcut_controller.py Null",
                  lambda dt, vs, lo, hi: sc.Null(dt, vs, lo, hi), "all"))
        v.append(("cruise (ignores every track)", "shortcut_controller.py Cruise",
                  lambda dt, vs, lo, hi: sc.Cruise(dt, vs, lo, hi), "all"))
        v.append(("brakes for every track", "shortcut_controller.py GhostBraker",
                  lambda dt, vs, lo, hi: sc.GhostBraker(dt, vs, lo, hi), "all"))
    except ImportError:
        pass
    if group and group != "all":
        v = [x for x in v if x[3] in (group, "all")] if group == "ablation" else \
            [x for x in v if x[3] == group]
    return v


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--group", default="all")
    ap.add_argument("--out", default=HERE)
    args = ap.parse_args()

    hidden = load(os.path.join(ROOT, "tests", "hidden", "scenarios.json"))
    rows = []
    for name, source, factory, grp in variants(args.group):
        t0 = time.time()
        per, agg = run_all(factory, hidden)
        agg["name"] = name
        agg["source"] = source
        agg["wall_s"] = round(time.time() - t0, 2)
        agg["per_scenario_min_headway"] = [round(p["min_headway_s"], 3)
                                           if p["min_headway_s"] < 1e6 else None for p in per]
        agg["per_scenario_false_brakes"] = [p["false_brake_events"] for p in per]
        rows.append(agg)
        print("%-34s coll=%d gap=%6.2f unsafe=%6.2f fb=%-3d jerk=%.3f deficit=%.3f (%.1fs)" % (
            name, agg["collisions"], agg["min_gap_m"], agg["unsafe_s"],
            agg["false_brake_events"], agg["jerk_rms_mps3"], agg["speed_deficit_mps"],
            agg["wall_s"]))

    with open(os.path.join(args.out, "results.json"), "w", newline="\n") as f:
        json.dump(rows, f, indent=1)
        f.write("\n")


if __name__ == "__main__":
    main()
