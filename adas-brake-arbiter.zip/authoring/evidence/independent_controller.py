"""
A second correct controller, written to a different design than the reference, so
the bars can sit outside the spread of correct answers rather than beside one
implementation.

Differences from solution/controller.py at every stage: range and range rate come
from a least squares fit over a sliding window instead of an alpha beta filter,
the in path test uses the median lateral offset of the window rather than a
filtered value and a linear extrapolation, braking authority is released by an
evidence counter in frames and metres of range traversed rather than a continuous
confidence ramp, and the demand comes from a safety distance rule compared against
a constant time gap rule instead of a gap error feedback law.
"""
import collections

import numpy as np

WIN = 14
HOLD_S = 0.8
IN_PATH_M = 1.75
T_GAP_S = 1.6
D0_M = 5.5
RESPONSE_S = 0.45


class Hist(object):
    def __init__(self, oid, t):
        self.oid = oid
        self.t0 = t
        self.t = collections.deque(maxlen=WIN)
        self.r = collections.deque(maxlen=WIN)
        self.y = collections.deque(maxlen=WIN)
        self.q = collections.deque(maxlen=WIN)
        self.rr_meas = collections.deque(maxlen=WIN)
        self.last_t = t
        self.frames = 0
        self.r_max = 0.0

    def add(self, t, r, rr, y, q):
        self.t.append(t)
        self.r.append(r)
        self.y.append(y)
        self.q.append(q)
        self.rr_meas.append(rr)
        self.last_t = t
        self.frames += 1
        self.r_max = max(self.r_max, r)

    def fit(self):
        """Quadratic least squares on range: position, rate and relative acceleration."""
        n = len(self.t)
        if n < 3:
            return self.r[-1], self.rr_meas[-1], 0.0
        tt = np.asarray(self.t) - self.t[-1]
        rr = np.asarray(self.r)
        deg = 2 if n >= 8 else 1
        c = np.polyfit(tt, rr, deg)
        if deg == 2:
            return float(c[2]), float(c[1]), float(2.0 * c[0])
        return float(c[1]), float(c[0]), 0.0


class Controller(object):
    def __init__(self, dt, v_set, a_min, a_max):
        self.dt = dt
        self.v_set = v_set
        self.a_min = a_min
        self.a_max = a_max
        self.h = {}
        self.prev = 0.0

    def step(self, t, v, a_meas, rows):
        for oid, r, rr, y, q in rows:
            if oid not in self.h:
                self.h[oid] = Hist(oid, t)
            self.h[oid].add(t, r, rr, y, q)
        for k in [k for k, hh in self.h.items() if t - hh.last_t > HOLD_S]:
            del self.h[k]

        best = None
        for hh in self.h.values():
            rf, rrf, raf = hh.fit()
            coast = t - hh.last_t
            rf = rf + rrf * coast
            if rf <= 0.5 or rf > 160.0:
                continue
            if abs(float(np.median(hh.y))) > IN_PATH_M:
                continue
            if best is None or rf < best[0]:
                best = (rf, rrf, raf, hh)

        if best is None:
            a = 0.5 * (self.v_set - v)
        else:
            gap, rrate, racc, hh = best
            lead_v = max(0.0, v + rrate)
            lead_a = float(np.clip(a_meas + racc, -7.0, 3.0))

            # How much of the brake this evidence justifies. A track that has been
            # watched over a long stretch of range, or for many frames, is a vehicle.
            if hh.r_max > 78.0 or hh.frames > 105:
                auth = 1.0
            else:
                # Nothing counts until this track has outlasted the longest false one.
                by_frames = max(0.0, hh.frames - 50.0) / 55.0
                by_range = max(0.0, hh.r_max - gap - 12.0) / 30.0
                auth = float(np.clip(0.10 + 0.90 * max(by_frames, by_range), 0.08, 1.0))
                if float(np.mean(hh.q)) < 0.62:
                    auth *= 0.75

            # Constant time gap demand.
            a_gap = 0.34 * (gap - (T_GAP_S * v + D0_M)) + 1.0 * (lead_v - v)
            # Safety distance: what is needed to stop short of where the lead stops.
            closing = v - lead_v
            if closing > 0.2:
                # Do not bank on the lead needing a long distance to stop.
                brake_lead = min(lead_a, -3.5)
                d_lead = (lead_v * lead_v) / (2.0 * abs(brake_lead))
                # Allow for the time it takes this vehicle to respond before the
                # brake is doing anything, the way a safety distance rule should.
                need = max(gap - D0_M + d_lead - v * RESPONSE_S, 0.5)
                a_safe = -(v * v) / (2.0 * need)
            else:
                a_safe = 0.0
            a = min(0.5 * (self.v_set - v), a_gap, a_safe if a_safe < 0.0 else 99.0)
            a = max(a, self.a_min * auth)

        # Push past the demand while the measured acceleration is still catching up,
        # otherwise the actuator lag shows up as a late brake.
        a = a + 0.5 * (a - a_meas)
        a = self.prev + float(np.clip(a - self.prev, -0.28, 0.28))
        self.prev = a
        return float(np.clip(a, self.a_min, self.a_max))
