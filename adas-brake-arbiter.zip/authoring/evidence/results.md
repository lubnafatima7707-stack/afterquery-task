# Evidence for the adas-brake-arbiter thresholds

Everything here is produced by scripts in this folder and can be rerun:

```
python authoring/provenance/gen_scenarios.py   # regenerates environment/data/dev and tests/hidden
python authoring/evidence/evaluate.py          # scores every controller below, writes results.json
python authoring/evidence/diag.py              # the same run broken out per scenario
```

`evaluate.py` scores every run with `tests/scoring.py`, the module the verifier imports, so the
numbers below come from the grader's own code. Controllers run in process here; the verifier drives
the identical logic over the line protocol in a subprocess. `evaluate.py` quantises the observation
and the command to the same four decimals the protocol carries, so the two paths agree digit for
digit: running the reference and the shortcut through the real `test_verify.py` reproduces the
table below exactly.

Hidden set: fourteen scenarios, 46 s each at 50 Hz, on four vehicle builds the agent never sees.
The mix is three emergency braking runs, three in which the lead drops out of the track list, two
where a vehicle screened by the one in front appears at close range with no history, one lane
change into the ego path, one where the only moving traffic stays in the neighbouring lanes, one
stop and go, one mixed run that combines a merge with dropouts and hard braking, one clear road
carrying 9 false tracks, and one ordinary following run. Four of the fourteen carry blind windows
on the vehicle ahead.
A scenario is only accepted if a controller given the true object states still keeps a 3.0 m gap on
that build, and any scenario containing a lane change is also rejected unless the merging vehicle is
still at least 18 m ahead when the change completes.

Bars: no collision in any scenario, at most 3.0 s spent closer than 0.9 times the ego speed plus
2.0 m, at most 2 unjustified braking events, and at most 2.0 m/s of mean speed shortfall on clear
road.

| controller | source | collisions | min gap m | unsafe s | false brakes | jerk rms | shortfall m/s | verdict |
|---|---|---|---|---|---|---|---|---|
| reference | solution/controller.py | 0 | 6.95 | 0.00 | 0 | 3.261 | 0.634 | pass |
| independent controller | independent_controller.py | 0 | 4.08 | 0.64 | 1 | 4.281 | 0.515 | pass |
| reference, time gap 1.40 s | time_gap_s=1.40 | 0 | 6.37 | 1.76 | 0 | 3.261 | 0.628 | pass |
| reference, time gap 1.70 s | time_gap_s=1.70 | 0 | 7.19 | 0.00 | 0 | 3.482 | 0.636 | pass |
| reference, full authority at 1.8 s | full_authority_s=1.8 | 0 | 6.95 | 0.00 | 0 | 3.261 | 0.634 | pass |
| reference, full authority at 2.5 s | full_authority_s=2.5 | 0 | 6.95 | 0.00 | 0 | 3.261 | 0.634 | pass |
| reference, coast window 0.7 s | coast_max_s=0.7 | 0 | 6.59 | 0.00 | 0 | 3.156 | 0.576 | pass |
| reference, in path gate 1.5 m | in_path_m=1.5 | 0 | 6.91 | 0.00 | 0 | 3.363 | 0.594 | pass |
| no graded threat confidence | graded=False | 0 | 7.51 | 0.00 | 43 | 3.864 | 4.731 | fail (false brakes, shortfall) |
| no coasting through dropouts | coast=False | 1 | 0.05 | 1.42 | 1 | 3.063 | 1.199 | fail (collision only) |
| no lateral target selection | lateral=False | 0 | 6.85 | 0.00 | 4 | 3.567 | 5.502 | fail (false brakes, shortfall) |
| no lead acceleration estimate | lead_accel=False | 0 | 3.78 | 4.70 | 0 | 2.137 | 0.615 | fail (unsafe only) |
| time to collision shortcut | shortcut_controller.py Controller | 4 | 0.06 | 37.12 | 15 | 6.815 | 4.319 | fail (all four) |
| crawler | shortcut_controller.py Crawler | 0 | 19.44 | 0.00 | 0 | 0.565 | 17.529 | fail (shortfall only) |
| null, commands nothing | shortcut_controller.py Null | 12 | 0.01 | 73.32 | 0 | 0.000 | 1.622 | fail (collision, unsafe) |
| cruise, ignores every track | shortcut_controller.py Cruise | 12 | 0.00 | 68.12 | 0 | 0.505 | 0.033 | fail (collision, unsafe) |
| brakes for every track | shortcut_controller.py GhostBraker | 0 | 2.18 | 5.32 | 22 | 4.706 | 1.042 | fail (unsafe, false brakes) |

Each bar sits between the weakest correct controller and the strongest broken one. Unsafe time runs
1.76 s at worst across the eight correct runs against 4.70 s for the strongest broken one, so the
3.0 s bar has 69 percent of headroom below it and the nearest failure is 57 percent above it. False
brake events run 1 at worst correct against 4 broken. Speed shortfall runs 0.636 m/s at worst
correct against 17.529 m/s for the crawler.

Three of the four bars are the sole reason some variant fails: dropping the coasting fails on
collision alone, dropping the lead acceleration estimate fails on unsafe time alone, and the crawler
fails on shortfall alone. The unjustified braking bar is the one that no variant fails in complete
isolation, and it is kept anyway because it is not a duplicate of the shortfall bar: GhostBraker
passes shortfall comfortably at 1.042 m/s while failing braking events at 22, because it recovers
its speed immediately after every phantom brake. Phantom braking that costs no time is still the
failure this task is about.

## The collision bar, and a defect that made it unreachable

An earlier version of this bundle shipped with the collision check dead. `plant._truth` retired an
object on the same step its relative position turned non positive, which is exactly the step that
defines contact, so the object never reached the log with a gap of zero and `collisions` was
identically zero. A 25 m/s ego commanding nothing drove straight through a stopped car 30 m ahead
and was scored as collision free. The retirement rule had been added for a good reason, to stop a
vehicle the ego had overtaken from counting as a near miss when it later caught up, but it
conflated two different things.

The fix separates them. An object becomes a following target only once it has genuinely been ahead,
more than 12 m in front. Traffic that was never properly ahead is overtaking and is ignored. An
object that was properly ahead, is in the ego lane, and whose range then reaches zero is contact,
and that is recorded before the object is retired rather than instead of it. The reviewer's own test
case now reports contact, and the do nothing baselines collide in 12 of the 14 scenarios.

Adding the null and cruise baselines is what should have caught this during authoring, and they are
now part of the standard run. A do nothing controller clears only `clear_ghosts` and
`adjacent_only`, which is by design: those two scenarios exist to punish braking that nothing asked
for, and a controller that never brakes is supposed to pass them. Every other scenario ends in a
collision for both nulls.

## The lane change, and a scenario that was not testing one

The same review found that the one advertised cut in scenario was not one. The merging vehicle was
drawn 20 to 30 m ahead but 2.5 to 5.0 m/s slower than the ego, so over the 13 to 21 s before its
lane change it fell 32 to 105 m behind, and the merge completed 9.4 m behind the ego. The dev cut in
had the same geometry at 28.9 m behind.

A merging vehicle is now placed from the relative distance it has to have when the merge completes,
working backwards through the closing speed, and the generator refuses any scenario whose lane
change lands less than 18 m ahead under an informed controller. The merges now complete 45.6 m
ahead in `hidden_1`, 30.0 m in `hidden_6` and 50.3 m in the dev scenario, and a null controller
collides in all three instead of clearing them.

## Other things worth stating plainly

- Online identification of the actuator was built, measured and then removed. Fitting the transport
  delay, the lag constant and the delivered braking fraction from the command and acceleration
  histories, and inverting them, changed nothing that mattered: across several rounds of scenario
  tuning the variant that simply assumed fixed constants scored the same on every bar, and in the
  last of those rounds slightly better on both minimum gap and worst scenario jerk. Those figures
  are not quoted because the identification code is no longer in the bundle and they are not
  reproducible from the shipped scripts. The reason is physical: in an emergency the command
  saturates at the actuator limit, so knowing the actuator does not let you ask for more, and
  outside an emergency the time gap policy leaves enough margin that a few tenths of a second of lag
  error costs nothing measurable. The builds still vary so that a controller cannot be tuned to one
  vehicle's timing, not because adapting to them is the hard part.
- The false track population cannot be separated by any single field. Quality averages higher for
  real vehicles, 0.86 against 0.50 to 0.80, but the ranges overlap; false tracks live under a second,
  but so does the useful history of a vehicle screened until it was close. That is the intended
  shape: an age gate alone loses the screened vehicles, and no gate at all costs false brake events.
- Minimum gap and jerk are measured and recorded but are deliberately not bars. Minimum gap is a
  single worst instant out of roughly 32000 graded steps and spreads from 4.08 to 7.19 m across
  correct controllers, which is too wide to bar without cutting into correct answers, and the
  collision and unsafe time bars measure the same property more stably. Jerk fails for nothing the
  other bars do not already fail.
- The generator refuses to emit a blind window longer than 0.78 s or two windows closer together
  than 1.6 s. An earlier version let two periodic windows merge into a 0.98 s gap that landed on the
  lead's hard braking, which destroyed the track and left a correct controller no way through. That
  was an unwinnable scenario rather than a hard one.

Scores are deterministic. Repeated `evaluate.py` runs give identical numbers.
