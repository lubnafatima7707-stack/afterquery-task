"""
Baselines of the kind a reviewer writes in a few minutes, kept here so the bars can
be checked against something other than weakened copies of the reference.

Controller is the obvious time to collision rule applied to whatever track is
nearest, with no notion of which lane a track is in, how long it has been there,
or what to do while it is missing. Crawler is the degenerate way to be safe, which
is to drive far below the set speed and never need to brake hard. Null and Cruise
are the two do nothing controllers: any scenario either of them clears on every
metric is a scenario that is not discriminating, so they are scored on each
scenario individually as well as in total.
"""
import numpy as np


class Controller(object):
    """Nearest track, brake on time to collision, cruise otherwise."""

    def __init__(self, dt, v_set, a_min, a_max):
        self.dt = dt
        self.v_set = v_set
        self.a_min = a_min
        self.a_max = a_max

    def step(self, t, v, a_meas, rows):
        best = None
        for oid, r, rr, y, q in rows:
            if r <= 0.5:
                continue
            if best is None or r < best[0]:
                best = (r, rr)
        if best is None:
            return float(np.clip(0.6 * (self.v_set - v), self.a_min, self.a_max))
        gap, rrate = best
        closing = -rrate
        ttc = gap / closing if closing > 0.1 else 1e9
        if ttc < 2.5:
            return self.a_min
        if ttc < 5.0:
            return -3.0
        if gap < 1.6 * v + 5.0:
            return -1.0
        return float(np.clip(0.6 * (self.v_set - v), self.a_min, self.a_max))


class Crawler(object):
    """Never gets close to anything because it never goes fast."""

    def __init__(self, dt, v_set, a_min, a_max):
        self.dt = dt
        self.v_set = v_set
        self.a_min = a_min
        self.a_max = a_max
        self.cap = min(8.0, 0.35 * v_set)

    def step(self, t, v, a_meas, rows):
        # Eases down to its cap rather than braking, so the only thing it fails on
        # is getting anywhere.
        return float(np.clip(0.25 * (self.cap - v), -1.8, self.a_max))


class Null(object):
    """Commands nothing at all, ever."""

    def __init__(self, dt, v_set, a_min, a_max):
        pass

    def step(self, t, v, a_meas, rows):
        return 0.0


class Cruise(object):
    """Holds the set speed and ignores every track."""

    def __init__(self, dt, v_set, a_min, a_max):
        self.v_set = v_set
        self.a_min = a_min
        self.a_max = a_max

    def step(self, t, v, a_meas, rows):
        return float(np.clip(0.6 * (self.v_set - v), -1.0, self.a_max))


class GhostBraker(object):
    """Correct lane gating and following, no discipline about young tracks.

    It brakes at full authority for anything that turns up in its lane and then
    climbs straight back to the set speed, so it loses almost no progress. It
    exists to show that the unjustified braking bar is not a duplicate of the
    speed shortfall bar: this one fails only the former.
    """

    def __init__(self, dt, v_set, a_min, a_max):
        self.dt = dt
        self.v_set = v_set
        self.a_min = a_min
        self.a_max = a_max
        self.prev = 0.0

    def step(self, t, v, a_meas, rows):
        best = None
        for oid, r, rr, y, q in rows:
            if r <= 0.5 or abs(y) > 1.7:
                continue
            if best is None or r < best[0]:
                best = (r, rr)
        if best is None:
            a = 1.6 * (self.v_set - v)
        else:
            gap, rrate = best
            lead_v = max(0.0, v + rrate)
            closing = v - lead_v
            room = max(gap - 5.5, 0.6)
            a_req = -(closing * closing) / (2.0 * room) if closing > 0.2 else 0.0
            a_gap = 0.38 * (gap - (1.55 * v + 5.5)) + 1.05 * (lead_v - v)
            a = min(1.6 * (self.v_set - v), a_gap, a_req if a_req < 0.0 else 99.0)
        a = self.prev + float(np.clip(a - self.prev, -0.32, 0.32))
        self.prev = a
        return float(np.clip(a, self.a_min, self.a_max))
