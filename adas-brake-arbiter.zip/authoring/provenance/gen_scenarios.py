"""
Seeded generator for the development and hidden driving scenarios.

Every road user is scripted in absolute road coordinates before any controller
runs, so grading never depends on the solver. Each scenario is checked for
feasibility with an informed controller that is given the true object states and
the true build, and is rejected unless that controller keeps a real gap.

    python authoring/provenance/gen_scenarios.py
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "tests"))

import plant  # noqa: E402

DEV_BUILD = dict(name="dev", tau_s=0.18, delay_s=0.07, brake_deadtime_s=0.02, accel_scale=1.10,
                 range_sigma_m=0.14, rate_sigma_mps=0.050, lat_sigma_m=0.23,
                 v_sigma_mps=0.08, a_sigma_mps2=0.11, a_bias_mps2=0.03)

HIDDEN_BUILDS = [
    dict(name="unit_a", tau_s=0.16, delay_s=0.06, brake_deadtime_s=0.02, accel_scale=1.12,
         range_sigma_m=0.13, rate_sigma_mps=0.048, lat_sigma_m=0.22,
         v_sigma_mps=0.07, a_sigma_mps2=0.10, a_bias_mps2=-0.05),
    dict(name="unit_b", tau_s=0.55, delay_s=0.24, brake_deadtime_s=0.10, accel_scale=0.84,
         range_sigma_m=0.21, rate_sigma_mps=0.070, lat_sigma_m=0.31,
         v_sigma_mps=0.12, a_sigma_mps2=0.16, a_bias_mps2=0.08),
    dict(name="unit_c", tau_s=0.52, delay_s=0.24, brake_deadtime_s=0.11, accel_scale=0.87,
         range_sigma_m=0.18, rate_sigma_mps=0.061, lat_sigma_m=0.28,
         v_sigma_mps=0.10, a_sigma_mps2=0.14, a_bias_mps2=0.06),
    dict(name="unit_d", tau_s=0.22, delay_s=0.09, brake_deadtime_s=0.03, accel_scale=1.06,
         range_sigma_m=0.15, rate_sigma_mps=0.052, lat_sigma_m=0.24,
         v_sigma_mps=0.08, a_sigma_mps2=0.11, a_bias_mps2=-0.03),
]

LANE = 3.5


def flat(y, t0=0.0, t1=200.0):
    return [[t0, y], [t1, y]]


def cutin(y_from, y_to, t_start, t_dur):
    return [[0.0, y_from], [t_start, y_from], [t_start + t_dur, y_to], [200.0, y_to]]


MAX_BLIND_S = 0.78
MIN_BLIND_SEP_S = 1.6


def sanitize_dropouts(windows):
    """Merge overlaps, then refuse anything that would blind the sensor for too long.

    A blind window longer than a controller can reasonably coast through is not a
    harder scenario, it is an unwinnable one, so the generator trims rather than
    emitting it, and separates windows so two cannot run together.
    """
    out = []
    for w in sorted(tuple(x) for x in windows):
        t0, t1 = float(w[0]), float(w[1])
        if out and t0 - out[-1][1] < MIN_BLIND_SEP_S:
            prev0, prev1 = out[-1]
            merged1 = max(prev1, t1)
            if merged1 - prev0 <= MAX_BLIND_S:
                out[-1] = (prev0, merged1)
            continue
        out.append((t0, min(t1, t0 + MAX_BLIND_S)))
    for a, b in out:
        assert b - a <= MAX_BLIND_S + 1e-9, (a, b)
    for i in range(1, len(out)):
        assert out[i][0] - out[i - 1][1] >= MIN_BLIND_SEP_S - 1e-9, out
    return [[round(a, 3), round(b, 3)] for a, b in out]


def ghost(gid, t0, dur, range0, rate, lateral, quality):
    return dict(id=gid, t0=round(t0, 3), t1=round(t0 + dur, 3), range0_m=round(range0, 3),
                rate_mps=round(rate, 3), lateral_m=round(lateral, 3), quality=round(quality, 3))


def ghost_burst(rng, gid, t0, v_ego_guess):
    """A short lived false track ahead, closing fast enough to look like a threat."""
    dur = float(rng.uniform(0.30, 0.95))
    rng0 = float(rng.uniform(16.0, 68.0))
    rate = float(rng.uniform(-1.0, 1.0) - 0.28 * v_ego_guess)
    lat = float(rng.normal(0.0, 0.75))
    q = float(rng.uniform(0.50, 0.80))
    return ghost(gid, t0, dur, rng0, rate, lat, q)


def make_scenario(name, rng, kind, duration=46.0):
    v0 = float(rng.uniform(18.0, 30.0))
    v_set = float(np.clip(v0 + rng.uniform(-1.0, 4.0), 14.0, 33.0))
    objs = []
    ghosts = []
    gid = 900

    def lead(s0, lv, accel, lateral, dropouts=(), oid=1, pd=0.985, reveal=None, merge_done=None):
        d = dict(id=oid, s0_m=round(s0, 3), v0_mps=round(lv, 3), accel=accel,
                 lateral=lateral, dropouts=sanitize_dropouts(dropouts), pd=pd)
        if reveal is not None:
            d["reveal_below_m"] = round(float(reveal), 3)
        if merge_done is not None:
            d["lane_change_done_s"] = round(float(merge_done), 3)
        return d

    def merge_start(t_done, v_merge, v_ego_est, rel_done):
        """Where a merging vehicle has to start so it is still rel_done ahead at t_done."""
        return rel_done + max(v_ego_est - v_merge, 0.0) * t_done

    if kind == "follow_brake":
        lv = v0 - rng.uniform(0.5, 2.5)
        t_b = float(rng.uniform(12.0, 20.0))
        objs.append(lead(rng.uniform(38.0, 58.0), lv,
                         [[t_b, t_b + rng.uniform(3.0, 5.0), -rng.uniform(2.2, 3.4)],
                          [t_b + 9.0, t_b + 13.0, rng.uniform(0.8, 1.4)]], flat(0.0)))
    elif kind == "hard_brake":
        lv = v0 - rng.uniform(0.0, 1.5)
        t_b = float(rng.uniform(14.0, 22.0))
        objs.append(lead(rng.uniform(26.0, 36.0), lv,
                         [[t_b, t_b + rng.uniform(3.2, 4.0), -rng.uniform(7.0, 7.8)]], flat(0.0)))
    elif kind == "cut_in":
        # The vehicle in front is far enough ahead and fast enough to be irrelevant;
        # the merge is the event, and the merging car has to still be ahead when it
        # arrives, which means starting far enough up the road to survive the closing.
        objs.append(lead(rng.uniform(108.0, 138.0), v0 + rng.uniform(2.5, 4.5), [], flat(0.0)))
        t_c = float(rng.uniform(12.0, 18.0))
        dur = float(rng.uniform(1.6, 2.8))
        v_m = v0 - rng.uniform(3.0, 5.5)
        s0 = merge_start(t_c + dur, v_m, v_set, rng.uniform(28.0, 36.0))
        objs.append(lead(s0, v_m,
                         [[t_c + dur + 2.0, t_c + dur + 5.0, -rng.uniform(1.0, 2.0)]],
                         cutin(-LANE, 0.0, t_c, dur), oid=2, merge_done=t_c + dur))
    elif kind == "adjacent_only":
        objs.append(lead(rng.uniform(22.0, 34.0), v0 - rng.uniform(3.0, 6.0),
                         [[16.0, 20.0, -rng.uniform(1.5, 3.0)]],
                         [[0.0, -LANE], [14.0, -LANE - 0.35], [30.0, -LANE + 0.5], [200.0, -LANE]], oid=2))
        objs.append(lead(rng.uniform(60.0, 90.0), v0 + rng.uniform(2.0, 5.0), [], flat(LANE), oid=3))
    elif kind == "dropout_follow":
        lv = v0 - rng.uniform(0.5, 2.0)
        t_b = float(rng.uniform(16.0, 22.0))
        drops = []
        tt = 8.0
        while tt < duration - 4.0:
            drops.append([round(tt, 3), round(tt + rng.uniform(0.45, 1.05), 3)])
            tt += rng.uniform(5.0, 8.0)
        drops.append([round(t_b + 0.45, 3), round(t_b + 0.45 + rng.uniform(0.45, 0.75), 3)])
        drops.sort()
        objs.append(lead(rng.uniform(36.0, 50.0), lv,
                         [[t_b, t_b + 3.6, -rng.uniform(5.2, 6.2)]], flat(0.0), dropouts=drops, pd=0.93))
    elif kind == "stop_go":
        lv = v0 - rng.uniform(1.0, 3.0)
        objs.append(lead(rng.uniform(30.0, 42.0), lv,
                         [[10.0, 14.0, -rng.uniform(2.0, 2.8)], [18.0, 22.0, rng.uniform(1.0, 1.6)],
                          [26.0, 30.5, -rng.uniform(2.4, 3.2)], [34.0, 39.0, rng.uniform(0.9, 1.5)]],
                         flat(0.0)))
    elif kind == "clear_ghosts":
        objs.append(lead(rng.uniform(120.0, 145.0), v0 + rng.uniform(3.0, 7.0), [], flat(0.0)))
    elif kind == "emerge":
        # A much slower vehicle screened by the one in front until the gap is small.
        # It has no track history at the moment it matters, which is exactly what a
        # false track looks like too.
        objs.append(lead(rng.uniform(70.0, 95.0), v0 + rng.uniform(1.0, 2.5), [], flat(-LANE)))
        objs.append(lead(rng.uniform(240.0, 340.0), v0 - rng.uniform(8.0, 12.5), [],
                         flat(0.0), oid=2, reveal=rng.uniform(56.0, 70.0)))
    elif kind == "mixed":
        lv = v0 - rng.uniform(1.0, 2.5)
        t_b = float(rng.uniform(24.0, 30.0))
        drops = [[11.0, 11.7], [19.5, 20.4], [round(t_b + 0.5, 3), round(t_b + 1.15, 3)]]
        objs.append(lead(rng.uniform(40.0, 55.0), lv,
                         [[t_b, t_b + 3.4, -rng.uniform(4.5, 5.6)]], flat(0.0), dropouts=drops, pd=0.95))
        t_c = float(rng.uniform(13.0, 17.0))
        dur = float(rng.uniform(1.8, 3.0))
        v_m = v0 - rng.uniform(3.0, 5.5)
        # Here the ego is already following the lead, so it closes at the lead's speed.
        s0 = merge_start(t_c + dur, v_m, lv, rng.uniform(24.0, 32.0))
        objs.append(lead(s0, v_m, [], cutin(LANE, 0.2, t_c, dur), oid=2, merge_done=t_c + dur))
    else:
        raise ValueError(kind)

    n_ghost = {"clear_ghosts": 9, "adjacent_only": 6, "mixed": 5}.get(kind, 4)
    tg = 5.0
    for _ in range(n_ghost):
        tg += float(rng.uniform(2.5, 5.5))
        if tg > duration - 3.0:
            break
        ghosts.append(ghost_burst(rng, gid, tg, v0))
        gid += 1

    return dict(name=name, kind=kind, duration_s=duration, set_speed_mps=round(v_set, 3),
                ego_v0_mps=round(v0, 3), objects=objs, ghosts=ghosts)


def _visible_truth(sim, k):
    """Nearest in path object the radar could actually report at this step."""
    t = k * plant.DT
    best = None
    clear = True
    for i, ob in enumerate(sim.objects.items):
        rel = ob["s"][k] - sim.s_ego
        if rel <= 0.0 or rel > plant.MAX_RANGE_M:
            continue
        if not sim.objects.visible(i, t):
            continue
        if abs(ob["y"][k]) <= plant.IN_PATH_LAT_M:
            if rel <= 120.0:
                clear = False
            if best is None or rel < best[0]:
                best = (rel, ob["v"][k])
    return best, clear


MERGE_MIN_AHEAD_M = 18.0


def informed_run(spec, build_d, seed):
    """Controller with true object states and the true build, used only as a feasibility check.

    Returns the smallest gap it ever holds and, for every vehicle that changes lane
    into the ego path, how far ahead it still was when the change completed. A merge
    that lands behind the ego is not a lane change the controller can be graded on.
    """
    build = plant.Build(build_d)
    sim = plant.Sim(spec, build, seed)
    min_gap = 1e9
    merges = {i: None for i, ob in enumerate(spec["objects"]) if "lane_change_done_s" in ob}
    for k in range(sim.n_steps):
        t_now = k * plant.DT
        for i in merges:
            t_done = float(spec["objects"][i]["lane_change_done_s"])
            if merges[i] is None and t_now >= t_done:
                merges[i] = float(sim.objects.items[i]["s"][k] - sim.s_ego)
        sim.observation(k)
        best, clear = _visible_truth(sim, k)
        if best is None:
            a = 1.2 if sim.v_ego < sim.v_set else -0.4
        else:
            gap, lv = best
            min_gap = min(min_gap, gap)
            des = max(6.0, 1.6 * sim.v_ego + 5.0)
            a = 0.85 * (lv - sim.v_ego) + 0.55 * (gap - des)
            a -= 1.15 * max(0.0, sim.v_ego - lv) ** 2 / max(2.0 * max(gap - 5.0, 1.0), 1.0)
            if sim.v_ego > sim.v_set:
                a = min(a, -0.3)
        sim.step(k, float(np.clip(a, plant.A_MIN, plant.A_MAX)))
        if sim.collided(k):
            return -1.0, [-1.0]
    return min_gap, [v if v is not None else -1.0 for v in merges.values()]


def acceptable(spec, build_d, seed):
    gap, merges = informed_run(spec, build_d, seed)
    if gap < 3.0:
        return False
    return all(m >= MERGE_MIN_AHEAD_M for m in merges)


def main():
    out_hidden = os.path.join(ROOT, "tests", "hidden")
    out_dev = os.path.join(ROOT, "environment", "data", "dev")
    os.makedirs(out_hidden, exist_ok=True)
    os.makedirs(out_dev, exist_ok=True)

    dev_kinds = ["follow_brake", "cut_in", "dropout_follow", "emerge"]
    # Build assignment is deliberate, not round robin: the scenarios that demand
    # braking near the limit sit on the units with the slowest and weakest brakes,
    # which is where getting the actuator response wrong actually costs distance.
    hidden_plan = [("hard_brake", "unit_c"), ("cut_in", "unit_a"),
                   ("clear_ghosts", "unit_c"), ("dropout_follow", "unit_d"),
                   ("adjacent_only", "unit_d"), ("stop_go", "unit_b"),
                   ("mixed", "unit_c"), ("emerge", "unit_d"),
                   ("hard_brake", "unit_b"), ("emerge", "unit_a"),
                   ("follow_brake", "unit_b"), ("dropout_follow", "unit_c"),
                   ("hard_brake", "unit_d"), ("dropout_follow", "unit_b")]

    dev = []
    for i, kind in enumerate(dev_kinds):
        for attempt in range(400):
            rng = np.random.default_rng(7000 + 97 * i + attempt)
            spec = make_scenario("dev_%d" % i, rng, kind)
            if acceptable(spec, DEV_BUILD, 41000 + i):
                spec["seed"] = 41000 + i
                dev.append(spec)
                break
        else:
            raise RuntimeError("no feasible dev scenario for " + kind)

    by_name = {b["name"]: b for b in HIDDEN_BUILDS}
    hidden = []
    for i, (kind, bname) in enumerate(hidden_plan):
        build_d = by_name[bname]
        for attempt in range(400):
            rng = np.random.default_rng(9000 + 131 * i + attempt)
            spec = make_scenario("hidden_%d" % i, rng, kind)
            if acceptable(spec, build_d, 52000 + i):
                spec["seed"] = 52000 + i
                spec["build"] = build_d["name"]
                hidden.append(spec)
                break
        else:
            raise RuntimeError("no feasible hidden scenario for " + kind)

    with open(os.path.join(out_hidden, "scenarios.json"), "w", newline="\n") as f:
        json.dump(dict(builds={b["name"]: b for b in HIDDEN_BUILDS}, scenarios=hidden), f, indent=1)
        f.write("\n")
    with open(os.path.join(out_dev, "scenarios.json"), "w", newline="\n") as f:
        json.dump(dict(builds={DEV_BUILD["name"]: DEV_BUILD}, scenarios=dev), f, indent=1)
        f.write("\n")
    print("dev scenarios  :", [s["kind"] for s in dev])
    print("hidden scenarios:", [(s["kind"], s["build"]) for s in hidden])


if __name__ == "__main__":
    main()
