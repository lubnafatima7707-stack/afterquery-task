"""
Closed loop longitudinal plant, radar sensor model and scenario replay.

The scenario scripts every other road user in absolute road coordinates before
any controller runs, so the object trajectories that grading is based on do not
depend on the controller under test. Only the ego motion, and therefore the gap,
responds to the commands.
"""
import math

import numpy as np

DT = 0.02
A_MIN = -8.0
A_MAX = 2.0
MAX_RANGE_M = 150.0
IN_PATH_LAT_M = 1.6
ELIGIBLE_MIN_M = 12.0
EGO_FRONT_TO_LEAD_REAR_M = 0.0


class Build(object):
    """One vehicle build: actuator response and radar noise, never told to the controller."""

    def __init__(self, d):
        self.name = d["name"]
        self.tau_s = float(d["tau_s"])
        self.delay_s = float(d["delay_s"])
        self.brake_deadtime_s = float(d["brake_deadtime_s"])
        self.accel_scale = float(d["accel_scale"])
        self.range_sigma_m = float(d["range_sigma_m"])
        self.rate_sigma_mps = float(d["rate_sigma_mps"])
        self.lat_sigma_m = float(d["lat_sigma_m"])
        self.v_sigma_mps = float(d["v_sigma_mps"])
        self.a_sigma_mps2 = float(d["a_sigma_mps2"])
        self.a_bias_mps2 = float(d["a_bias_mps2"])


def _piecewise_accel(profile, t):
    for seg in profile:
        if seg[0] <= t < seg[1]:
            return float(seg[2])
    return 0.0


def _lateral(waypoints, t):
    """Linear interpolation through (time, lateral) waypoints, held at both ends."""
    if t <= waypoints[0][0]:
        return float(waypoints[0][1])
    for i in range(1, len(waypoints)):
        t0, y0 = waypoints[i - 1]
        t1, y1 = waypoints[i]
        if t <= t1:
            f = (t - t0) / max(t1 - t0, 1e-9)
            return float(y0 + f * (y1 - y0))
    return float(waypoints[-1][1])


class Objects(object):
    """Scripted road users, integrated once up front and independent of the ego."""

    def __init__(self, spec, n_steps):
        self.items = []
        for ob in spec["objects"]:
            s = np.zeros(n_steps)
            v = np.zeros(n_steps)
            y = np.zeros(n_steps)
            s[0] = float(ob["s0_m"])
            v[0] = float(ob["v0_mps"])
            for k in range(n_steps):
                t = k * DT
                y[k] = _lateral(ob["lateral"], t)
                if k + 1 < n_steps:
                    a = _piecewise_accel(ob["accel"], t)
                    v[k + 1] = max(0.0, v[k] + a * DT)
                    s[k + 1] = s[k] + v[k] * DT + 0.5 * a * DT * DT
            self.items.append(dict(oid=int(ob["id"]), s=s, v=v, y=y,
                                   dropouts=[tuple(w) for w in ob.get("dropouts", [])],
                                   reveal_below_m=float(ob.get("reveal_below_m", 1e9)),
                                   pd=float(ob.get("pd", 0.98))))

    def visible(self, i, t, rel=None):
        it = self.items[i]
        for w in it["dropouts"]:
            if w[0] <= t < w[1]:
                return False
        if rel is not None and rel > it["reveal_below_m"]:
            return False
        return True


class Sim(object):
    def __init__(self, spec, build, seed):
        self.spec = spec
        self.build = build
        self.n_steps = int(round(float(spec["duration_s"]) / DT))
        self.objects = Objects(spec, self.n_steps)
        self.v_set = float(spec["set_speed_mps"])
        self.rng = np.random.default_rng(int(seed))
        self.delay_steps = int(round(build.delay_s / DT))
        self.dead_steps = int(round(build.brake_deadtime_s / DT))
        self.cmd_hist = [0.0] * (self.delay_steps + self.dead_steps + 2)
        self.v_ego = float(spec["ego_v0_mps"])
        self.s_ego = 0.0
        self.a_act = 0.0
        self.ghosts = spec.get("ghosts", [])
        # An object only counts as something the ego is following once it has been
        # seen properly ahead. Anything that has fallen behind, or that first turns
        # up almost level with the bumper, is overtaking traffic and is never a
        # following target again.
        self.eligible = [False] * len(self.objects.items)
        self.retired = [False] * len(self.objects.items)
        self.contact = [False] * len(self.objects.items)
        self.log = dict(t=[], v_ego=[], a_act=[], a_cmd=[], gap=[], lead_v=[],
                        lead_present=[], threat=[], clear=[], contact=[])

    # ---------------- sensing ----------------
    def observation(self, k):
        t = k * DT
        b = self.build
        rows = []
        for i, ob in enumerate(self.objects.items):
            rel = ob["s"][k] - self.s_ego
            if rel <= 0.0 or rel > MAX_RANGE_M:
                continue
            if not self.objects.visible(i, t, rel):
                continue
            if self.rng.random() > ob["pd"]:
                continue
            rr = ob["v"][k] - self.v_ego
            rows.append((ob["oid"],
                         rel + self.rng.normal(0.0, b.range_sigma_m),
                         rr + self.rng.normal(0.0, b.rate_sigma_mps),
                         ob["y"][k] + self.rng.normal(0.0, b.lat_sigma_m),
                         float(np.clip(self.rng.normal(0.86, 0.09), 0.0, 1.0))))
        for g in self.ghosts:
            if not (g["t0"] <= t < g["t1"]):
                continue
            age = t - g["t0"]
            rows.append((int(g["id"]),
                         float(g["range0_m"] + g["rate_mps"] * age + self.rng.normal(0.0, b.range_sigma_m * 1.6)),
                         float(g["rate_mps"] + self.rng.normal(0.0, b.rate_sigma_mps * 2.2)),
                         float(g["lateral_m"] + self.rng.normal(0.0, b.lat_sigma_m * 1.4)),
                         float(np.clip(self.rng.normal(g.get("quality", 0.63), 0.11), 0.0, 1.0))))
        self.rng.shuffle(rows)
        v_meas = self.v_ego + self.rng.normal(0.0, b.v_sigma_mps)
        a_meas = self.a_act + b.a_bias_mps2 + self.rng.normal(0.0, b.a_sigma_mps2)
        return t, max(0.0, v_meas), a_meas, rows

    # ---------------- truth bookkeeping ----------------
    def _truth(self, k):
        """Nearest genuine in path object ahead, whether the road is clear, and contact.

        An object becomes a following target only once it has genuinely been ahead,
        so traffic that was never properly in front is overtaking and is ignored. An
        object that was properly ahead, is in the ego lane, and whose range then
        reaches zero is contact: two vehicles cannot occupy the same road space, and
        that is recorded before the object is retired rather than instead of it.
        """
        best = None
        clear = True
        for i, ob in enumerate(self.objects.items):
            rel = ob["s"][k] - self.s_ego
            in_path = abs(ob["y"][k]) <= IN_PATH_LAT_M
            if rel > ELIGIBLE_MIN_M:
                self.eligible[i] = True
            if self.retired[i] or not self.eligible[i]:
                continue
            if rel <= 0.0:
                if in_path:
                    self.contact[i] = True
                self.retired[i] = True
                continue
            if rel > MAX_RANGE_M:
                continue
            if in_path:
                if rel <= 120.0:
                    clear = False
                if best is None or rel < best[0]:
                    best = (rel, ob["v"][k])
        return best, clear

    # ---------------- dynamics ----------------
    def step(self, k, a_cmd):
        b = self.build
        a_cmd = float(np.clip(a_cmd, A_MIN, A_MAX))
        self.cmd_hist.append(a_cmd)
        idx = -1 - self.delay_steps
        target = self.cmd_hist[idx]
        if target < 0.0:
            idx2 = -1 - self.delay_steps - self.dead_steps
            older = self.cmd_hist[idx2]
            if older >= 0.0:
                target = 0.0
        target = target * b.accel_scale if target < 0.0 else target
        self.a_act += (target - self.a_act) * (DT / b.tau_s)
        best, clear = self._truth(k)
        threat = 0.0
        if best is not None:
            closing = self.v_ego - best[1]
            ttc = best[0] / closing if closing > 0.05 else 1e9
            thw = best[0] / max(self.v_ego, 0.1)
            # Braking is justified by any in path vehicle that is close, closing,
            # or near in time, which includes holding station behind a stopped one.
            threat = 1.0 if (ttc < 12.0 or thw < 4.0 or best[0] < 40.0) else 0.0
        self.log["t"].append(k * DT)
        self.log["v_ego"].append(self.v_ego)
        self.log["a_act"].append(self.a_act)
        self.log["a_cmd"].append(a_cmd)
        self.log["gap"].append(best[0] if best is not None else float("nan"))
        self.log["lead_v"].append(best[1] if best is not None else float("nan"))
        self.log["lead_present"].append(1.0 if best is not None else 0.0)
        self.log["threat"].append(threat)
        self.log["clear"].append(1.0 if clear else 0.0)
        self.log["contact"].append(1.0 if any(self.contact) else 0.0)
        self.v_ego = max(0.0, self.v_ego + self.a_act * DT)
        self.s_ego += self.v_ego * DT
        return best

    def collided(self, k):
        """True once the ego has reached any vehicle that was ahead in its own lane."""
        self._truth(k)
        return any(self.contact)
