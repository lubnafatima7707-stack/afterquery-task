"""
Runs a controller around the development scenarios in closed loop and prints the
same numbers the grader reports.

    python3 /app/tools/replay.py /app/controller.py
    python3 /app/tools/replay.py /app/controller.py --scenario dev_1

This is the same plant, the same line protocol and the same metric code the
grading run uses. What differs there is the scenarios and the vehicle build: the
graded run uses fourteen scenarios recorded on four other builds, whose actuator
response and radar noise are drawn from the ranges given in the task text and are
not the numbers in data/dev/scenarios.json.
"""
import argparse
import json
import math
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import plant  # noqa: E402
import scoring  # noqa: E402

DEV_PATH = os.path.join(os.path.dirname(HERE), "data", "dev", "scenarios.json")


def drive(program, spec, build, seed, timeout_s):
    proc = subprocess.Popen([sys.executable, program], stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, close_fds=True)
    sim = plant.Sim(spec, build, seed)
    deadline = time.monotonic() + timeout_s

    def read_line():
        raw = proc.stdout.readline()
        if not raw:
            raise RuntimeError("controller exited before answering a step")
        if time.monotonic() > deadline:
            raise RuntimeError("timed out after %g s" % timeout_s)
        return raw.decode("utf-8", "replace").strip()

    try:
        proc.stdin.write(("INIT %.4f %.4f %.4f %.4f %.4f\n" % (
            plant.DT, sim.v_set, plant.A_MIN, plant.A_MAX, float(spec["duration_s"]))).encode())
        for k in range(sim.n_steps):
            t, v_meas, a_meas, rows = sim.observation(k)
            out = ["STEP %.3f %.4f %.4f %d" % (t, v_meas, a_meas, len(rows))]
            for r in rows:
                out.append("T %d %.4f %.4f %.4f %.4f" % (int(r[0]), r[1], r[2], r[3], r[4]))
            out.append("GO %.3f" % t)
            proc.stdin.write(("\n".join(out) + "\n").encode())
            proc.stdin.flush()
            parts = read_line().split()
            if len(parts) != 2:
                raise RuntimeError("bad answer at t=%.3f" % t)
            ta, a_cmd = float(parts[0]), float(parts[1])
            if abs(ta - t) > 1e-3 or not math.isfinite(a_cmd):
                raise RuntimeError("bad answer at t=%.3f" % t)
            sim.step(k, a_cmd)
        proc.stdin.write(b"END\n")
        proc.stdin.flush()
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
    return sim.log


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("program")
    ap.add_argument("--scenario", default=None)
    ap.add_argument("--timeout", type=float, default=300.0)
    args = ap.parse_args()

    with open(DEV_PATH) as f:
        data = json.load(f)
    build = plant.Build(list(data["builds"].values())[0])

    per = []
    for spec in data["scenarios"]:
        if args.scenario and spec["name"] != args.scenario:
            continue
        t0 = time.time()
        log = drive(args.program, spec, build, spec["seed"], args.timeout)
        m = scoring.scenario_metrics(log, float(spec["set_speed_mps"]))
        per.append(m)
        print("%-8s %-15s min gap %6.2f m  unsafe %5.2f s  false brakes %d  "
              "jerk rms %5.2f  speed shortfall %5.2f m/s  (%.1f s)" % (
                  spec["name"], spec["kind"], m["min_gap_m"], m["unsafe_s"],
                  m["false_brake_events"], m["jerk_rms_mps3"],
                  m["deficit_sum"] / max(m["deficit_n"], 1), time.time() - t0))
    if per:
        agg = scoring.aggregate(per)
        print("\ntotals over %d scenarios: collisions %d, unsafe %.2f s, "
              "false brakes %d, worst jerk rms %.2f, speed shortfall %.3f m/s" % (
                  agg["n_scenarios"], agg["collisions"], agg["unsafe_s"],
                  agg["false_brake_events"], agg["jerk_rms_mps3"],
                  agg["speed_deficit_mps"]))


if __name__ == "__main__":
    main()
