"""Driving quality metrics shared by the verifier and the authoring evidence scripts."""
import math

import numpy as np

BRAKE_EVENT_MPS2 = -2.5
BRAKE_EVENT_MIN_STEPS = 5
HEADWAY_MIN_SPEED_MPS = 3.0
UNSAFE_GAP_A = 0.9
UNSAFE_GAP_B = 2.0
CLEAR_SPEED_TOL_MPS = 0.0


def scenario_metrics(log, v_set):
    """Per scenario summary built from the plant log of one closed loop run."""
    t = np.asarray(log["t"], dtype=float)
    v = np.asarray(log["v_ego"], dtype=float)
    a_act = np.asarray(log["a_act"], dtype=float)
    a_cmd = np.asarray(log["a_cmd"], dtype=float)
    gap = np.asarray(log["gap"], dtype=float)
    present = np.asarray(log["lead_present"], dtype=float) > 0.5
    threat = np.asarray(log["threat"], dtype=float) > 0.5
    clear = np.asarray(log["clear"], dtype=float) > 0.5
    dt = float(t[1] - t[0]) if len(t) > 1 else 0.02

    contact = np.asarray(log["contact"], dtype=float)
    collided = bool(np.any(contact > 0.5))

    min_gap = float(np.min(gap[present])) if np.any(present) else float("inf")

    # Seconds spent closer to the vehicle ahead than a safe following distance.
    # An integral is far less noisy than the single worst instant of a run.
    close = present & (gap < UNSAFE_GAP_A * v + UNSAFE_GAP_B)
    unsafe_s = float(np.count_nonzero(close) * dt)

    m = present & (v > HEADWAY_MIN_SPEED_MPS)
    if np.any(m):
        hw = gap[m] / np.maximum(v[m], 1e-6)
        min_headway = float(np.min(hw))
    else:
        min_headway = float("inf")

    # A braking command that no genuine in path object justifies. Short spikes are
    # ignored; an event is a run of at least BRAKE_EVENT_MIN_STEPS such steps.
    bad = (a_cmd < BRAKE_EVENT_MPS2) & (~threat)
    events = 0
    run = 0
    for b in bad:
        if b:
            run += 1
        else:
            if run >= BRAKE_EVENT_MIN_STEPS:
                events += 1
            run = 0
    if run >= BRAKE_EVENT_MIN_STEPS:
        events += 1

    jerk = np.diff(a_act) / dt if len(a_act) > 1 else np.zeros(1)
    jerk_sq_sum = float(np.sum(jerk ** 2))
    jerk_n = int(jerk.size)
    jerk_rms = math.sqrt(jerk_sq_sum / jerk_n) if jerk_n else 0.0

    if np.any(clear):
        deficit = np.maximum(0.0, v_set - v[clear] - CLEAR_SPEED_TOL_MPS)
        deficit_sum = float(np.sum(deficit))
        deficit_n = int(np.count_nonzero(clear))
    else:
        deficit_sum, deficit_n = 0.0, 0

    return dict(collided=collided, min_gap_m=min_gap, min_headway_s=min_headway,
                unsafe_s=unsafe_s, false_brake_events=events,
                jerk_sq_sum=jerk_sq_sum, jerk_n=jerk_n, jerk_rms_mps3=jerk_rms,
                deficit_sum=deficit_sum, deficit_n=deficit_n,
                mean_speed_mps=float(np.mean(v)), n_steps=int(len(t)))


def aggregate(per_scenario):
    """Pool the per scenario summaries into the numbers the bars are stated against."""
    if not per_scenario:
        return dict(collisions=1, min_gap_m=0.0, min_headway_s=0.0, unsafe_s=10 ** 6,
                    false_brake_events=10 ** 6,
                    jerk_rms_mps3=10 ** 6, speed_deficit_mps=10 ** 6, n_scenarios=0)
    collisions = sum(1 for s in per_scenario if s["collided"])
    finite = [s["min_headway_s"] for s in per_scenario if math.isfinite(s["min_headway_s"])]
    min_headway = float(min(finite)) if finite else float("inf")
    fg = [s["min_gap_m"] for s in per_scenario if math.isfinite(s["min_gap_m"])]
    min_gap = float(min(fg)) if fg else float("inf")
    jerk_rms = max(s["jerk_rms_mps3"] for s in per_scenario)
    d_n = sum(s["deficit_n"] for s in per_scenario)
    deficit = (sum(s["deficit_sum"] for s in per_scenario) / d_n) if d_n else 0.0
    return dict(collisions=int(collisions),
                min_gap_m=min_gap,
                unsafe_s=float(sum(s["unsafe_s"] for s in per_scenario)),
                min_headway_s=min_headway,
                false_brake_events=int(sum(s["false_brake_events"] for s in per_scenario)),
                jerk_rms_mps3=float(jerk_rms),
                speed_deficit_mps=float(deficit),
                n_scenarios=len(per_scenario))
