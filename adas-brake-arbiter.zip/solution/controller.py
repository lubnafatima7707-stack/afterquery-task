#!/usr/bin/env python3
"""
Reference longitudinal controller.

Reads the observation protocol on stdin and answers one acceleration command per
step. The keyword switches on Controller exist so the authoring evidence can drop
one piece of engineering at a time without keeping a second copy of the file.
"""
import sys

import numpy as np

IN_PATH_M = 1.7
CUTIN_PREDICT_S = 1.1
COAST_MAX_S = 0.9
TIME_GAP_S = 1.55
STANDSTILL_M = 5.5
GHOST_LIFE_S = 1.0
FULL_AUTHORITY_S = 2.1
SEEN_FAR_M = 75.0
DES_SLEW = 9.0
CMD_SLEW = 16.0

# Actuator response assumed for the lag inversion. Deliberately a middling, slightly
# slow guess rather than the development vehicle's own numbers: every vehicle this
# runs on responds differently and the command saturates in an emergency anyway, so
# a conservative constant is what stays stable across builds.
ASSUMED_TAU_S = 0.20
ASSUMED_DELAY_S = 0.12


class Track(object):
    __slots__ = ("oid", "t_first", "t_last", "n", "r", "rr", "lat", "lat_rate",
                 "q", "miss", "seen_far")

    def __init__(self, oid, t, r, rr, lat, q):
        self.oid = oid
        self.t_first = t
        self.t_last = t
        self.n = 1
        self.r = r
        self.rr = rr
        self.lat = lat
        self.lat_rate = 0.0
        self.q = q
        self.miss = 0
        self.seen_far = r > SEEN_FAR_M

    def predict(self, dt):
        self.r += self.rr * dt
        self.lat += self.lat_rate * dt

    def update(self, t, r, rr, lat, q, dt):
        innov = r - self.r
        g = 0.45 if self.n > 6 else 0.7
        self.r += g * innov
        self.rr += 0.054 * innov / max(dt, 1e-3) + 0.35 * (rr - self.rr)
        new_lat_rate = (lat - self.lat) / max(dt, 1e-3)
        self.lat_rate += 0.12 * (new_lat_rate - self.lat_rate)
        self.lat += 0.35 * (lat - self.lat)
        self.q += 0.25 * (q - self.q)
        self.t_last = t
        self.n += 1
        self.miss = 0
        if r > SEEN_FAR_M:
            self.seen_far = True

    @property
    def age(self):
        return self.t_last - self.t_first


class Controller(object):
    def __init__(self, dt, v_set, a_min, a_max,
                 graded=True, coast=True, lateral=True, lead_accel=True,
                 time_gap_s=TIME_GAP_S, full_authority_s=FULL_AUTHORITY_S,
                 coast_max_s=COAST_MAX_S, in_path_m=IN_PATH_M):
        self.dt = dt
        self.v_set = v_set
        self.a_min = a_min
        self.a_max = a_max
        self.graded = graded
        self.coast = coast
        self.lateral = lateral
        self.lead_accel = lead_accel
        self.time_gap_s = time_gap_s
        self.full_authority_s = full_authority_s
        self.coast_max_s = coast_max_s
        self.in_path_m = in_path_m

        self.tracks = {}
        self.t = 0.0
        self.v = 0.0
        self.a_est = 0.0
        self.last_cmd = 0.0
        self.a_des_prev = 0.0
        self.lead_a = 0.0
        self.prev_lead_v = None

    # ----------------------------------------------------------------- tracks
    def _update_tracks(self, rows):
        for tr in self.tracks.values():
            tr.predict(self.dt)
            tr.miss += 1
        for oid, r, rr, lat, q in rows:
            if oid in self.tracks:
                self.tracks[oid].update(self.t, r, rr, lat, q, self.dt)
            else:
                self.tracks[oid] = Track(oid, self.t, r, rr, lat, q)
        hold = self.coast_max_s if self.coast else 0.06
        dead = [k for k, tr in self.tracks.items()
                if (self.t - tr.t_last) > hold or tr.r < -3.0 or tr.r > 170.0]
        for k in dead:
            del self.tracks[k]

    def _in_path(self, tr):
        if not self.lateral:
            return True
        if abs(tr.lat) <= self.in_path_m:
            return True
        # A vehicle moving across into the lane counts before it arrives.
        future = tr.lat + tr.lat_rate * CUTIN_PREDICT_S
        return abs(future) <= self.in_path_m and tr.lat * tr.lat_rate < 0.0

    def _confidence(self, tr):
        """How much of the available braking authority this track has earned.

        A track first seen well ahead, or one that has simply been there a long
        time, is a vehicle and gets everything. Anything that turns up already
        close has to earn authority with persistence, because that is equally
        what a false track looks like at the moment it appears.
        """
        if not self.graded:
            return 1.0
        if tr.seen_far or tr.age >= self.full_authority_s:
            return 1.0
        # Deliberately still weak while a false track could plausibly be alive,
        # then opening up quickly once this one has outlived one.
        knee = GHOST_LIFE_S * (1.25 - 0.35 * float(np.clip((tr.q - 0.55) / 0.30, 0.0, 1.0)))
        if tr.age <= knee:
            c = 0.10 + 0.20 * (tr.age / max(knee, 1e-3))
        else:
            span = max(self.full_authority_s - knee, 1e-3)
            c = 0.30 + 0.70 * min(1.0, (tr.age - knee) / span)
        if tr.miss > 0:
            c -= 0.05
        return float(np.clip(c, 0.08, 1.0))

    def _select(self):
        best = None
        for tr in self.tracks.values():
            if tr.r <= 0.5 or not self._in_path(tr):
                continue
            if best is None or tr.r < best.r:
                best = tr
        return best

    # ---------------------------------------------------------------- control
    def step(self, t, v_meas, a_meas, rows):
        self.t = t
        self.v = v_meas
        self.a_est = a_meas

        self._update_tracks(rows)
        sel = self._select()

        a_cruise = 0.55 * (self.v_set - self.v)
        conf = 1.0
        if sel is None:
            self.prev_lead_v = None
            a_des = a_cruise
        else:
            lead_v = max(0.0, self.v + sel.rr)
            if self.lead_accel:
                if self.prev_lead_v is not None:
                    raw = (lead_v - self.prev_lead_v) / self.dt
                    self.lead_a += 0.06 * (float(np.clip(raw, -9.0, 4.0)) - self.lead_a)
                self.prev_lead_v = lead_v
                a_ff = float(np.clip(self.lead_a, -6.0, 1.5))
            else:
                self.prev_lead_v = lead_v
                a_ff = 0.0

            # Control on the state the vehicle will actually be in once a command bites.
            lag = ASSUMED_DELAY_S + ASSUMED_TAU_S
            v_pred = max(0.0, self.v + self.a_est * lag)
            gap_pred = sel.r + (lead_v - self.v) * lag - 0.5 * self.a_est * lag * lag

            des_gap = self.time_gap_s * v_pred + STANDSTILL_M
            a_follow = 0.38 * (gap_pred - des_gap) + 1.05 * (lead_v - v_pred) + 0.65 * a_ff

            closing = v_pred - lead_v
            room = max(gap_pred - STANDSTILL_M, 0.6)
            a_req = (-(closing * closing) / (2.0 * room) + 0.7 * a_ff) if closing > 0.2 else 0.0
            a_des = min(a_cruise, a_follow, a_req if a_req < 0.0 else a_cruise)

            conf = self._confidence(sel)
            a_des = max(a_des, self.a_min * conf)

        # One demand per step, smoothed so the achieved acceleration does not step.
        a_des = self.a_des_prev + float(np.clip(a_des - self.a_des_prev,
                                                -DES_SLEW * self.dt, DES_SLEW * self.dt))
        self.a_des_prev = a_des

        # Invert the actuator lag so the achieved acceleration tracks the demand.
        gain = ASSUMED_TAU_S / max(0.17, 0.55 * ASSUMED_DELAY_S + 0.10)
        a_cmd = self.a_est + gain * (a_des - self.a_est)
        # The authority a target has earned bounds what is actually sent, not only the
        # demand: the lag inversion above would otherwise multiply straight past it.
        a_cmd = max(a_cmd, self.a_min * conf)
        a_cmd = float(np.clip(a_cmd, self.a_min, self.a_max))
        slew = CMD_SLEW * self.dt
        a_cmd = float(np.clip(a_cmd, self.last_cmd - slew, self.last_cmd + slew))
        self.last_cmd = a_cmd
        return a_cmd


def main():
    ctl = None
    rows = []
    pend = (0.0, 0.0, 0.0)
    for raw in sys.stdin:
        line = raw.strip()
        if not line:
            continue
        head = line.split(None, 1)[0]
        if head == "INIT":
            p = line.split()
            ctl = Controller(float(p[1]), float(p[2]), float(p[3]), float(p[4]))
        elif head == "STEP":
            p = line.split()
            pend = (float(p[1]), float(p[2]), float(p[3]))
            rows = []
        elif head == "T":
            p = line.split()
            rows.append((int(p[1]), float(p[2]), float(p[3]), float(p[4]), float(p[5])))
        elif head == "GO":
            t = float(line.split()[1])
            a = ctl.step(pend[0], pend[1], pend[2], rows)
            sys.stdout.write("%.3f %.4f\n" % (t, a))
            sys.stdout.flush()
            rows = []
        elif head == "END":
            break


if __name__ == "__main__":
    main()
