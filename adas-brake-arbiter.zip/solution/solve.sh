#!/bin/bash
set -euo pipefail

cp "$(dirname "$0")/controller.py" /app/controller.py
chmod 0644 /app/controller.py
