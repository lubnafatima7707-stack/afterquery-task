"""
Drives the agent's controller around one scenario in closed loop.

The simulator lives here, not in the controller's process. Each control step the
harness writes the observation for the current state, waits for exactly one
acceleration command, applies it to the plant and advances. The controller is
started as an unprivileged user in an empty directory, while the scenarios, the
builds and the plant live under /tests readable by root only, so the program can
neither read the scenario ahead of time nor see which build it is driving.
"""
import math
import os
import pwd
import select
import shutil
import signal
import subprocess
import tempfile
import time

import plant

RUN_USER = "runner"


class ControllerFailure(Exception):
    pass


def _prepare_workdir(program_path):
    work = tempfile.mkdtemp(prefix="ctl_")
    dst = os.path.join(work, "controller.py")
    shutil.copyfile(program_path, dst)
    if os.geteuid() == 0:
        pw = pwd.getpwnam(RUN_USER)
        os.chown(work, pw.pw_uid, pw.pw_gid)
        os.chown(dst, pw.pw_uid, pw.pw_gid)
    os.chmod(work, 0o700)
    return work, dst


def run_scenario(program_path, spec, build, seed, timeout_s, stderr_path):
    if not os.path.isfile(program_path):
        raise ControllerFailure(program_path + " does not exist")
    work, dst = _prepare_workdir(program_path)
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": work,
           "PYTHONDONTWRITEBYTECODE": "1", "OMP_NUM_THREADS": "1",
           "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
    kwargs = {}
    if os.geteuid() == 0:
        kwargs["user"] = RUN_USER
        kwargs["group"] = RUN_USER
        kwargs["extra_groups"] = []
    err = open(stderr_path, "wb")
    proc = subprocess.Popen(["python3", dst], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=err, cwd=work, env=env, close_fds=True,
                            start_new_session=True, **kwargs)
    fd_in = proc.stdin.fileno()
    fd_out = proc.stdout.fileno()
    os.set_blocking(fd_in, False)
    deadline = time.monotonic() + timeout_s
    pending = bytearray()
    outbuf = bytearray()

    def remaining():
        r = deadline - time.monotonic()
        if r <= 0:
            raise ControllerFailure("timed out after %g s" % timeout_s)
        return r

    def flush():
        while pending:
            _, w, _ = select.select([], [fd_in], [], remaining())
            if not w:
                continue
            try:
                n = os.write(fd_in, bytes(pending[:65536]))
            except BlockingIOError:
                continue
            except BrokenPipeError:
                raise ControllerFailure("controller stopped reading input (exited early?)")
            del pending[:n]

    def read_line():
        while b"\n" not in outbuf:
            r, _, _ = select.select([fd_out], [], [], remaining())
            if not r:
                continue
            chunk = os.read(fd_out, 65536)
            if not chunk:
                raise ControllerFailure("controller exited before answering a step")
            outbuf.extend(chunk)
        i = outbuf.index(b"\n")
        line = bytes(outbuf[:i]).decode("utf-8", errors="replace").strip()
        del outbuf[:i + 1]
        return line

    sim = plant.Sim(spec, build, seed)
    try:
        pending.extend(("INIT %.4f %.4f %.4f %.4f %.4f\n" % (
            plant.DT, sim.v_set, plant.A_MIN, plant.A_MAX, float(spec["duration_s"]))).encode())
        for k in range(sim.n_steps):
            t, v_meas, a_meas, rows = sim.observation(k)
            pending.extend(("STEP %.3f %.4f %.4f %d\n" % (t, v_meas, a_meas, len(rows))).encode())
            for r in rows:
                pending.extend(("T %d %.4f %.4f %.4f %.4f\n" % (
                    int(r[0]), r[1], r[2], r[3], r[4])).encode())
            pending.extend(("GO %.3f\n" % t).encode())
            flush()
            resp = read_line()
            parts = resp.split()
            if len(parts) != 2:
                raise ControllerFailure("bad answer at t=%.3f: %r" % (t, resp[:120]))
            try:
                ta = float(parts[0])
                a_cmd = float(parts[1])
            except ValueError:
                raise ControllerFailure("non numeric answer at t=%.3f: %r" % (t, resp[:120]))
            if not (math.isfinite(ta) and math.isfinite(a_cmd)):
                raise ControllerFailure("non finite answer at t=%.3f" % t)
            if abs(ta - t) > 1e-3:
                raise ControllerFailure("answer time %g does not match step %.3f" % (ta, t))
            sim.step(k, a_cmd)
        pending.extend(b"END\n")
        try:
            flush()
        except ControllerFailure:
            pass
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except OSError:
            pass
        err.close()
        shutil.rmtree(work, ignore_errors=True)
    return sim.log
