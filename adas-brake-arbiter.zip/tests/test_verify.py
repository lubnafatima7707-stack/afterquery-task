"""
Sealed verifier for adas-brake-arbiter.

Drives the agent's /app/controller.py around each of the twelve hidden scenarios
in closed loop through harness.py: the simulator runs here, the controller only
ever sees one observation at a time and its command changes what it is shown
next. The scenarios come from four vehicle builds the agent never sees, and the
object trajectories that grading uses are scripted before any controller runs
(authoring/provenance), so the truth does not depend on the solver.
"""
import json
import os

import pytest

import plant
import scoring
from harness import ControllerFailure, run_scenario

PROGRAM = "/app/controller.py"
HIDDEN_PATH = "/tests/hidden/scenarios.json"
LOG_DIR = "/logs/verifier"

EXPECTED_SCENARIOS = 14
TIMEOUT_PER_SCENARIO_S = 90
MAX_COLLISIONS = 0
MAX_UNSAFE_S = 3.0
MAX_FALSE_BRAKE_EVENTS = 2
MAX_SPEED_DEFICIT_MPS = 2.0


def load_hidden():
    with open(HIDDEN_PATH) as f:
        return json.load(f)


@pytest.fixture(scope="module")
def outcome():
    data = load_hidden()
    per, failures = [], {}
    os.makedirs(LOG_DIR, exist_ok=True)
    for spec in data["scenarios"]:
        build = plant.Build(data["builds"][spec["build"]])
        name = spec["name"]
        try:
            log = run_scenario(PROGRAM, spec, build, spec["seed"],
                               TIMEOUT_PER_SCENARIO_S,
                               os.path.join(LOG_DIR, "stderr_%s.txt" % name))
            per.append(scoring.scenario_metrics(log, float(spec["set_speed_mps"])))
        except ControllerFailure as e:
            failures[name] = str(e)
    metrics = scoring.aggregate(per)
    try:
        with open(os.path.join(LOG_DIR, "metrics.json"), "w") as f:
            json.dump({"metrics": metrics, "failures": failures,
                       "n_scenarios": len(data["scenarios"])}, f, indent=2)
    except OSError:
        pass
    return metrics, failures, len(data["scenarios"])


def test_every_scenario_completed(outcome):
    metrics, failures, n = outcome
    assert n == EXPECTED_SCENARIOS, "expected %d hidden scenarios, found %d" % (
        EXPECTED_SCENARIOS, n)
    assert not failures, "the controller did not complete every scenario: %s" % failures
    assert metrics["n_scenarios"] == EXPECTED_SCENARIOS


def test_no_collision(outcome):
    metrics = outcome[0]
    assert metrics["collisions"] <= MAX_COLLISIONS, (
        "%d of %d scenarios ended with the ego reaching a vehicle in its own lane"
        % (metrics["collisions"], metrics["n_scenarios"]))


def test_safe_following_distance(outcome):
    metrics = outcome[0]
    assert metrics["unsafe_s"] <= MAX_UNSAFE_S, (
        "%.2f s spent closer to the vehicle ahead than 0.9 times the ego speed plus "
        "2.0 m, at most %.1f s allowed" % (metrics["unsafe_s"], MAX_UNSAFE_S))


def test_no_unjustified_braking(outcome):
    metrics = outcome[0]
    assert metrics["false_brake_events"] <= MAX_FALSE_BRAKE_EVENTS, (
        "%d braking events below -2.5 m/s2 with no vehicle in the ego lane to "
        "justify them, at most %d allowed"
        % (metrics["false_brake_events"], MAX_FALSE_BRAKE_EVENTS))


def test_keeps_up_with_the_set_speed(outcome):
    metrics = outcome[0]
    assert metrics["speed_deficit_mps"] <= MAX_SPEED_DEFICIT_MPS, (
        "mean shortfall against the set speed on clear road is %.3f m/s, at most "
        "%.1f m/s allowed" % (metrics["speed_deficit_mps"], MAX_SPEED_DEFICIT_MPS))
