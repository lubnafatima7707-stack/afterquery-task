# ddma-radar-targets

Write a radar processing program that turns raw ADC captures from an uncalibrated 3 TX by 4 RX DDMA automotive radar into per scan object lists (range, radial velocity, azimuth), graded on hidden scans from sensor units the agent never sees.

## Difficulty

The data is synthetic. `authoring/provenance/generate_scenes.py` (seed 20260911) draws each scan's reflector list first and only then synthesizes the raw complex ADC samples of a 77 GHz DDMA radar from it. A real drive cannot give exact per reflector range, velocity and azimuth truth without a reference sensor setup far more accurate than the radar itself.

Five sensor units of the same design are simulated, each with its own gain and phase errors, phase shifter state errors, TX to RX leakage and its own pair of corner reflector captures, the way units are calibrated at the end of a production line. The agent develops against six scans from one unit **with no truth**, and the deliverable is a program: grading runs it once per scan on 24 hidden scans from four other units. Nothing can be tuned by looking at the graded data, and calibration constants do not carry across units. Reusing the development unit's calibration scores 0.391 recall with 365 unpaired rows.

Six further pieces have to be right, each measured by removing it from an otherwise working chain (`authoring/evidence/results.md`):

1. **DDMA decoding.** Each reflector appears three times in Doppler; which copy belongs to which TX must be settled per reflector. Taking the strongest copy: 0.209 recall, 372 unpaired rows.
2. **Doppler ambiguity.** Radial velocities reach ±45 m/s while the waveform resolves about ±24.3 m/s. The reflector's range walk across the frame (about 0.25 m per ambiguity step in 5 ms) breaks the tie. Ignoring it loses all 31 fast reflectors: 0.891 recall, 33 unpaired rows.
3. **Interference excision.** Bursts reach 9 of the 24 hidden scans; leaving them buries weak reflectors: 0.914 recall.
4. **Two reflectors in one range Doppler cell.** 70 reflectors are vehicles abreast 3.5 to 8 degrees apart, inside the ~9.5 degree beamwidth, and 28 are structures at mirrored azimuths. One angle per cell: 0.801. A wide angle rule: 0.848.
5. **A model order test judged against the stronger source.** On a 50 dB reflector the one source residual is manifold mismatch, not noise, so a noise only test splits single reflectors: 36 unpaired rows.
6. **Multipath images.** Stated in the instruction, absent from the truth: reporting them costs 8 unpaired rows, pruning too eagerly costs recall.

A shortcut that avoids TX calibration by summing three receive only spectra pairs 0.619 of the reflectors with 49 unpaired rows and 0.532 degrees.

GPU: not needed. Each scan is a 128 x 4 x 256 complex cube and the reference program takes 2.8 s per scan at worst against a 20 s budget, so `gpus = 0`.

## Reference solution

`solution/radar_chain.py`, copied to `/app/radar_chain.py` by `solution/solve.sh`:

1. Calibrate on the recording unit's own captures: per channel complex gains from the boresight reflector, steering sign from the 25 degree reflector.
2. Zero fast time samples above six times the per sample index median envelope (interference bursts).
3. Hann windowed range and Doppler FFTs, power summed over RX, Doppler folded into the four DDMA sub bands so each reflector's three copies and its empty band land on one cell.
4. Local maxima more than 7 dB above a per range median noise estimate, sidelobe shadows suppressed. The weakest sub band is the empty one, which fixes TX0's Doppler bin.
5. Resolve the remaining 48.7 m/s ambiguity: measure the range on each half frame from the DTFT of all three copies, turn the difference into a range rate, pick the matching ambiguity, then correct range Doppler coupling with that velocity.
6. Azimuth by model order selection on the twelve calibrated channels: keep a second source only when the joint fit's residual drop far exceeds the noise floor **and** the weaker source is within 15 dB of the stronger.
7. Drop any detection at the azimuth and radial velocity of a much stronger reflector one to two and a half metres closer, as its multipath image.

## Verification

`tests/test_verify.py` runs the agent's program once per hidden scan through `tests/harness.py`: a fresh directory holding only the program, the recording unit's `radar_config.json` and captures, and that scan; launched as an unprivileged user pinned to one CPU in its own session with a 20 s limit, after which its process group and any process that user still owns are killed. `/logs/verifier` is made root only before pytest starts, so the reward channel is unreachable from the program.

Rows are paired one to one per scan (Hungarian assignment) within 0.5 m, 0.4 m/s and 2 degrees. All three bars must hold:

| criterion | bar |
|---|---|
| paired fraction of the 302 hidden reflectors | at least 0.95 |
| rows left unpaired | at most 6 |
| RMS azimuth error over paired reflectors | at most 0.45 deg |

A scan that crashes, times out or prints a malformed line fails the task.

| solver | recall | unpaired | az RMSE (deg) | result |
|---|---|---|---|---|
| reference | 0.993 | 2 | 0.302 | pass |
| independent correct chain | 0.977 | 4 | 0.309 | pass |
| reference, threshold 9 dB / excision 4 / excision 10 | 0.980 / 0.990 / 0.993 | 2 / 2 / 1 | 0.293 / 0.316 / 0.315 | pass |
| reference, threshold 5 dB | 0.993 | 17 | 0.302 | fail, over detection |
| no velocity disambiguation | 0.891 | 33 | 0.311 | fail |
| development unit calibration reused | 0.391 | 365 | 1.218 | fail |
| no interference excision | 0.914 | 2 | 0.378 | fail |
| no channel calibration | 0.467 | 338 | 0.752 | fail |
| strongest copy as TX0 | 0.209 | 372 | 0.325 | fail |
| one angle per cell | 0.801 | 11 | 0.469 | fail |
| wide angle pairs only | 0.848 | 11 | 0.445 | fail |
| no multipath image rejection | 0.993 | 8 | 0.302 | fail |
| noise only model order test | 0.997 | 36 | 0.303 | fail |
| receive only shortcut | 0.619 | 49 | 0.532 | fail |

Each bar sits between the weaker of the two independent correct chains and the strongest broken one. Truth is drawn by the simulator before any signal exists and lives only in `tests/hidden`; the multipath images go into the signal but never into the truth.
