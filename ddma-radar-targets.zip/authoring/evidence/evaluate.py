"""
Scores the reference chain, its weakened variants, the independent chain and
the shortcut on the 24 hidden scans with the verifier's own metric code, and
runs the reference through the verifier's own harness to record wall times.

Run from anywhere: python evaluate.py
Writes results.json next to this file.
"""
import json
import os
import sys
import tempfile
import time
from collections import OrderedDict

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, os.path.join(BUNDLE, "solution"))
sys.path.insert(0, os.path.join(BUNDLE, "tests"))
sys.path.insert(0, HERE)

import independent_chain  # noqa: E402
import radar_chain  # noqa: E402
import scoring  # noqa: E402
import shortcut_baseline  # noqa: E402
from harness import ProgramFailure, run_program  # noqa: E402

HIDDEN = os.path.join(BUNDLE, "tests", "hidden")
DEV = os.path.join(BUNDLE, "environment", "data")
TRUTH = os.path.join(HIDDEN, "truth_objects.csv")
DEV_TRUTH = os.path.join(BUNDLE, "authoring", "provenance", "dev_truth.csv")


def units():
    out = OrderedDict()
    for unit in sorted(os.listdir(HIDDEN)):
        sd = os.path.join(HIDDEN, unit, "scans")
        if os.path.isdir(sd):
            out[os.path.join(HIDDEN, unit)] = [(int(f[5:-4]), os.path.join(sd, f))
                                               for f in sorted(os.listdir(sd)) if f.endswith(".bin")]
    return out


def run_reference(calib=True, borrow_calibration_from=None, **opts):
    rows = []
    for unit_dir, scans in units().items():
        if borrow_calibration_from is not None:
            radar = radar_chain.Radar(unit_dir)
            radar.gain = borrow_calibration_from.gain.copy()
            radar.sign = borrow_calibration_from.sign
        else:
            radar = radar_chain.make_radar(unit_dir, calib=calib)
        for scan, path in scans:
            rows += [(scan,) + d for d in radar_chain.run_scan(radar, path, **opts)]
    return rows


def run_module(mod):
    rows = []
    for unit_dir, scans in units().items():
        ctx = mod.make(unit_dir)
        for scan, path in scans:
            rows += [(scan,) + tuple(d) for d in mod.run_scan(ctx, path)]
    return rows


def harness_timing():
    program = os.path.join(BUNDLE, "solution", "radar_chain.py")
    times, failures = [], []
    log = tempfile.mkdtemp()
    for unit_dir, scans in units().items():
        for scan, path in scans:
            t0 = time.monotonic()
            try:
                run_program(program, unit_dir, path, 20, os.path.join(log, f"err_{scan}.txt"))
            except ProgramFailure as e:
                failures.append((scan, str(e)))
            times.append(time.monotonic() - t0)
    return {"max_s": max(times), "mean_s": sum(times) / len(times), "failures": failures}


def main():
    truth = scoring.read_truth(TRUTH)
    dev_radar = radar_chain.make_radar(DEV)
    variants = OrderedDict([
        ("reference", lambda: run_reference()),
        ("no_velocity_disambiguation", lambda: run_reference(disambiguate=False)),
        ("dev_unit_calibration_reused", lambda: run_reference(borrow_calibration_from=dev_radar)),
        ("no_interference_excision", lambda: run_reference(mitigate=False)),
        ("no_channel_calibration", lambda: run_reference(calib=False)),
        ("no_empty_band_decode", lambda: run_reference(empty_band=False)),
        ("one_angle_per_cell", lambda: run_reference(two_objects=False)),
        ("wide_angle_pairs_only", lambda: run_reference(wide_only=True)),
        ("no_multipath_rejection", lambda: run_reference(suppress_ghosts=False)),
        ("noise_only_model_order", lambda: run_reference(rel_floor_db=None)),
        ("reference_thr_5dB", lambda: run_reference(thr_db=5.0)),
        ("reference_thr_9dB", lambda: run_reference(thr_db=9.0)),
        ("reference_excise_4x", lambda: run_reference(excise_factor=4.0)),
        ("reference_excise_10x", lambda: run_reference(excise_factor=10.0)),
        ("independent_chain", lambda: run_module(independent_chain)),
        ("shortcut_baseline", lambda: run_module(shortcut_baseline)),
    ])
    results = OrderedDict()
    for name, fn in variants.items():
        results[name] = scoring.evaluate(fn(), truth)
    # the development unit, scored against its own truth, as a representativeness check
    dev_rows = []
    for i, f in enumerate(sorted(os.listdir(os.path.join(DEV, "dev")))):
        dev_rows += [(i,) + d for d in radar_chain.run_scan(dev_radar, os.path.join(DEV, "dev", f))]
    results["reference_on_dev_unit"] = scoring.evaluate(dev_rows, scoring.read_truth(DEV_TRUTH))

    for name, m in results.items():
        print(f"{name:28s} rec {m['recall']:.3f}  weak {m['recall_weak'][0]:.2f}/{m['recall_weak'][1]}"
              f"  intf {m['recall_interfered'][0]:.2f}/{m['recall_interfered'][1]}"
              f"  pair {m['recall_pairs'][0]:.2f}/{m['recall_pairs'][1]}"
              f"  close {m['recall_close'][0]:.2f}/{m['recall_close'][1]}"
              f"  fast {m['recall_fast'][0]:.2f}/{m['recall_fast'][1]}"
              f"  unpaired {m['n_false']:3d}  rAz {m['az_rmse_deg']:.3f}")
    timing = harness_timing()
    print(f"reference through the verifier harness: max {timing['max_s']:.2f} s per scan, "
          f"mean {timing['mean_s']:.2f} s, failures {timing['failures']}")
    results["harness_timing"] = timing
    with open(os.path.join(HERE, "results.json"), "w", newline="\n") as f:
        json.dump(results, f, indent=2)
        f.write("\n")


if __name__ == "__main__":
    main()
