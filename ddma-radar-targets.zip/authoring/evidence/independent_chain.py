"""
A second, structurally different correct solver, written to calibrate the
thresholds against something other than the reference chain itself. It has the
same command line contract as the deliverable:

    python3 independent_chain.py <data_dir> <scan_file>

Differences from solution/radar_chain.py:
  interference: chirp level screening on the range spectrum floor, then sample
    level excision only inside flagged chirps
  detection: 2D cell averaging CFAR on the unfolded range Doppler map, no folding
  TX assignment: for each detection the three possible comb origins are tried
    and the one whose twelve channel vector best fits a one or two source array
    model wins (no explicit empty band test)
  estimation: range and Doppler refined by maximizing the comb power of the
    DTFT (not parabolic interpolation), virtual channels read off the DTFT
  velocity ambiguity: range fitted on four quarter frames and regressed against
    time, instead of differencing two half frames
  calibration: gain vector averaged over both reflector captures, steering sign
    taken from the documented convention
  angles: one or two sources chosen by residual energy drop and a balance test
  multipath: power ordered walk instead of a pairwise rule
"""
import json
import os
import sys

import numpy as np
from scipy.ndimage import binary_dilation, maximum_filter, uniform_filter
from scipy.optimize import minimize

V_MAX = 46.0


class Setup:
    def __init__(self, data_dir):
        with open(os.path.join(data_dir, "radar_config.json")) as f:
            cfg = json.load(f)
        self.cfg, self.dir = cfg, data_dir
        self.c0 = cfg["speed_of_light_mps"]
        self.lam = self.c0 / cfg["carrier_frequency_hz"]
        self.fc = cfg["carrier_frequency_hz"]
        self.S = cfg["chirp_slope_hz_per_s"]
        self.fs = cfg["adc_sample_rate_hz"]
        self.N = cfg["samples_per_chirp"]
        self.K = cfg["chirps_per_frame"]
        self.tc = cfg["chirp_repetition_interval_s"]
        self.ntx, self.nrx = cfg["num_tx"], cfg["num_rx"]
        self.q = self.K // 4
        self.rbin = self.c0 * self.fs / (2 * self.S * self.N)
        self.pos = (np.array(cfg["tx_positions_y_m"])[:, None] + np.array(cfg["rx_positions_y_m"])[None, :]).ravel()
        self.g = np.ones(self.ntx * self.nrx, dtype=complex)
        self.wr = np.hanning(self.N)
        self.wd = np.hanning(self.K)

    def load_file(self, path):
        a = np.fromfile(path, dtype="<i2").reshape(self.K, self.nrx, self.N, 2)
        return a[..., 0].astype(float) + 1j * a[..., 1]


def clean_bursts(st, x):
    F = np.fft.fft(x * st.wr, axis=2)
    floor = np.median(np.abs(F) ** 2, axis=2).mean(axis=1)  # per chirp
    ref = np.median(floor)
    flagged = np.nonzero(floor > 2.0 * ref)[0]
    if len(flagged) == 0:
        return x
    good = np.setdiff1d(np.arange(st.K), flagged)
    env = np.median(np.abs(x[good]), axis=0)  # (rx, n) envelope from clean chirps
    y = x.copy()
    for k in flagged:
        bad = (np.abs(x[k]) > 4.0 * env + 4.0 * np.median(env)).any(axis=0)
        bad = binary_dilation(bad, iterations=4)
        y[k][:, bad] = 0.0
    return y


def rd(st, x):
    X = np.fft.fft(x * st.wr, axis=2)
    return np.fft.fft(X * st.wd[:, None, None], axis=0)


def dtft_channels(st, x, fr, fd):
    """Complex value of each TX copy on each RX at range bin fr, TX0 Doppler bin fd (fractional)."""
    n = np.arange(st.N)
    k = np.arange(st.K)
    er = st.wr * np.exp(-2j * np.pi * fr * n / st.N)
    xr = x @ er  # (K, rx)
    out = []
    for m in range(st.ntx):
        ed = st.wd * np.exp(-2j * np.pi * (fd - st.q * m) * k / st.K)
        out.append(ed @ xr)
    return np.array(out).ravel()


def steer(st, u):
    return np.exp(-2j * np.pi * np.outer(np.atleast_1d(u), st.pos) / st.lam)


def fit(st, y, n_src, u0):
    def res(u):
        A = steer(st, np.array(u)).T
        c, *_ = np.linalg.lstsq(A, y, rcond=None)
        return float(np.sum(np.abs(y - A @ c) ** 2))
    r = minimize(res, u0, method="Nelder-Mead", options={"xatol": 1e-7, "fatol": 1e-12})
    return list(r.x), r.fun


def angle_model(st, y, sigma2):
    grid = np.linspace(-0.97, 0.97, 1941)
    spec = np.abs(steer(st, grid).conj() @ y) ** 2
    u1, r1 = fit(st, y, 1, [grid[np.argmax(spec)]])
    A = steer(st, np.array(u1)).T
    c, *_ = np.linalg.lstsq(A, y, rcond=None)
    resid = y - A @ c
    spec2 = np.abs(steer(st, grid).conj() @ resid) ** 2
    spec2[np.abs(grid - u1[0]) < 0.025] = 0
    u2, r2 = fit(st, y, 2, [u1[0], grid[np.argmax(spec2)]])
    energy = float(np.sum(np.abs(y) ** 2))
    A2 = steer(st, np.array(u2)).T
    c2, *_ = np.linalg.lstsq(A2, y, rcond=None)
    pw = np.abs(c2) ** 2
    # on a very strong reflector the one source residual is manifold mismatch, not noise, so
    # also demand the weaker source stay within 14 dB of the stronger one
    balanced = pw.min() >= pw.max() * 10 ** (-1.4)
    if (r1 - r2) > 40.0 * sigma2 and abs(u2[0] - u2[1]) > 0.02 and balanced:
        return u2, 1.0 - r2 / energy
    return u1, 1.0 - r1 / energy


def calibrate(st):
    gs = []
    for cap in st.cfg["calibration_captures"]:
        x = st.load_file(os.path.join(st.dir, cap["file"]))
        X = rd(st, x)
        P = (np.abs(X) ** 2).sum(axis=1)
        r0 = int(round(cap["range_m"] / st.rbin))
        rr = r0 - 3 + int(np.argmax(P[0, r0 - 3:r0 + 4]))
        # a static reflector sits at Doppler zero, so TX0 is at bin 0 exactly
        y = dtft_channels(st, x, rr, 0.0)
        g = y / steer(st, np.sin(np.radians(cap["azimuth_deg"])))[0]
        gs.append(g / g[0])
    st.g = np.mean(gs, axis=0)


def range_rate(st, x, fr, fd):
    """Radial speed from the reflector's range walk: range fitted on each quarter
    of the frame, then a straight line through the four points."""
    seg = st.K // 4
    w = np.hanning(seg)
    n = np.arange(st.N)
    step = 0.02
    grid = fr + np.arange(-75, 76) * step
    E = st.wr[None, :] * np.exp(-2j * np.pi * np.outer(grid, n) / st.N)
    t, rng = [], []
    for s in range(4):
        kk = np.arange(s * seg, (s + 1) * seg)
        pw = np.zeros(len(grid))
        for m in range(st.ntx):
            ed = w * np.exp(-2j * np.pi * (fd - st.q * m) * kk / st.K)
            sm = np.tensordot(ed, x[s * seg:(s + 1) * seg], axes=(0, 0))
            pw += np.sum(np.abs(sm @ E.T) ** 2, axis=0)
        i = min(max(int(np.argmax(pw)), 1), len(grid) - 2)
        a, b, c = np.log(pw[i - 1:i + 2] + 1e-30)
        off = 0.5 * (a - c) / (a - 2 * b + c) if (a - 2 * b + c) < 0 else 0.0
        t.append((s + 0.5) * seg * st.tc)
        rng.append((grid[i] + off * step) * st.rbin)
    return float(np.polyfit(t, rng, 1)[0])


def process(st, x):
    x = clean_bursts(st, x)
    X = rd(st, x)
    P = (np.abs(X) ** 2).sum(axis=1)
    big = uniform_filter(P, size=(11, 11), mode=("wrap", "nearest")) * 121
    small = uniform_filter(P, size=(5, 5), mode=("wrap", "nearest")) * 25
    noise = (big - small) / (121 - 25)
    lm = maximum_filter(P, size=(3, 3), mode=("wrap", "nearest"))
    rr = np.arange(st.N) * st.rbin
    det = (P == lm) & (P > 9.0 * noise) & (rr[None, :] >= 2.0) & (rr[None, :] <= 97.0)
    seeds = sorted(zip(*np.nonzero(det)), key=lambda dr: -P[dr])
    explained = np.zeros_like(P, dtype=bool)
    sigma2_map = noise / st.nrx
    v_period = st.lam / (2 * st.tc)
    out = []
    for d, r in seeds:
        if explained[d, r]:
            continue
        best = None
        for m in range(st.ntx):
            h = (d + st.q * m) % st.K
            y = np.array([X[(h - st.q * j) % st.K, :, r] for j in range(st.ntx)]).ravel() / st.g
            us, frac = angle_model(st, y, sigma2_map[d, r])
            if best is None or frac > best[0]:
                best = (frac, h)
        h = best[1]
        for b in range(4):
            dd = (h + st.q * b) % st.K
            explained[max(dd - 2, 0):dd + 3, max(r - 2, 0):r + 3] = True
            if dd - 2 < 0:
                explained[st.K + dd - 2:, max(r - 2, 0):r + 3] = True
            if dd + 3 > st.K:
                explained[:dd + 3 - st.K, max(r - 2, 0):r + 3] = True

        def neg_comb(p):
            return -float(np.sum(np.abs(dtft_channels(st, x, p[0], p[1])) ** 2))
        pr = minimize(neg_comb, [float(r), float(h)], method="Nelder-Mead",
                      options={"xatol": 1e-4, "fatol": 1e-9, "initial_simplex": [[r, h], [r + 0.5, h], [r, h + 0.5]]})
        fr, fd = pr.x
        y = dtft_channels(st, x, fr, fd) / st.g
        us, _ = angle_model(st, y, sigma2_map[d, r])
        fds = fd % st.K
        if fds >= st.K / 2:
            fds -= st.K
        v_dopp = fds * st.lam / (2 * st.K * st.tc)
        v_rr = range_rate(st, x, fr, fd)
        cands = [v_dopp + j * v_period for j in (-1, 0, 1) if abs(v_dopp + j * v_period) <= V_MAX] or [v_dopp]
        v = min(cands, key=lambda c: abs(c - v_rr))
        rng = fr * st.rbin - v * st.fc / st.S
        for u in us:
            if abs(u) < 0.97:
                out.append((rng, v, float(np.degrees(np.arcsin(u))), float(P[d, r])))
    return out


def reject_images(dets):
    """Sort by power and walk down: a weaker detection lying behind a much stronger
    one at the same bearing and closing rate is that reflector's bounce image."""
    order = sorted(range(len(dets)), key=lambda i: -dets[i][3])
    dropped = set()
    for i in order:
        r_i, v_i, a_i, p_i = dets[i]
        for j in order:
            if j == i or j in dropped:
                continue
            r_j, v_j, a_j, p_j = dets[j]
            if p_j >= p_i / 4.0:
                continue
            if 0.6 < (r_j - r_i) < 2.4 and abs(v_j - v_i) < 0.3 and abs(a_j - a_i) < 1.5:
                dropped.add(j)
    return [d[:3] for k, d in enumerate(dets) if k not in dropped]


def make(data_dir):
    st = Setup(data_dir)
    calibrate(st)
    return st


def run_scan(st, scan_path):
    return reject_images(process(st, st.load_file(scan_path)))


if __name__ == "__main__":
    rows = run_scan(make(sys.argv[1]), sys.argv[2])
    sys.stdout.write("".join(f"{r:.4f} {v:.4f} {a:.4f}\n" for r, v, a in rows))
