# Evidence for the ddma-radar-targets thresholds

Everything here is produced by scripts in this folder and can be rerun:

```
python authoring/provenance/generate_scenes.py   # regenerates environment/data and tests/hidden
python authoring/evidence/evaluate.py            # scores every solver below, writes results.json
```

`evaluate.py` scores each output with `tests/scoring.py`, the same code the verifier uses, and
finishes by running the reference program through `tests/harness.py`, the same sandboxed runner the
verifier uses, to record wall time per scan.

Hidden truth: 302 reflectors in 24 scans, recorded by four sensor units the agent never sees. 108
are in the 9 interfered scans, 70 are vehicles abreast 3.5 to 8 degrees apart (inside the beamwidth),
28 are structures at mirrored azimuths, 31 move faster than the DDMA span of about 24.3 m/s, and 22
are under 22 dB per channel SNR. A further 11 multipath images are present in the signal and
deliberately absent from the truth.

Bars: recall at least 0.95, at most 6 unpaired rows, azimuth RMSE at most 0.45 deg.

| solver | source | recall | close | fast | unpaired | az RMSE deg | verdict |
|---|---|---|---|---|---|---|---|
| reference | solution/radar_chain.py | 0.993 | 0.97 | 31/31 | 2 | 0.302 | pass |
| independent correct chain | independent_chain.py | 0.977 | 0.96 | 31/31 | 4 | 0.309 | pass |
| reference, detection threshold 9 dB | thr_db=9 | 0.980 | 0.97 | 31/31 | 2 | 0.293 | pass |
| reference, excision factor 4 | excise_factor=4 | 0.990 | 0.96 | 31/31 | 2 | 0.316 | pass |
| reference, excision factor 10 | excise_factor=10 | 0.993 | 0.97 | 31/31 | 1 | 0.315 | pass |
| reference, detection threshold 5 dB | thr_db=5 | 0.993 | 0.97 | 31/31 | 17 | 0.302 | fail (unpaired) |
| no velocity disambiguation | disambiguate=False | 0.891 | 0.97 | 0/31 | 33 | 0.311 | fail (recall, unpaired) |
| development unit calibration reused | borrowed gain vector | 0.391 | 0.20 | 12/31 | 365 | 1.218 | fail (all three) |
| no interference excision | mitigate=False | 0.914 | 0.87 | 27/31 | 2 | 0.378 | fail (recall) |
| no channel calibration | calib=False | 0.467 | 0.31 | 14/31 | 338 | 0.752 | fail (all three) |
| strongest copy taken as TX0 | empty_band=False | 0.209 | 0.26 | 3/31 | 372 | 0.325 | fail (recall, unpaired) |
| one angle per cell | two_objects=False | 0.801 | 0.34 | 30/31 | 11 | 0.469 | fail (all three) |
| wide angle pairs only | wide_only=True | 0.848 | 0.34 | 31/31 | 11 | 0.445 | fail (recall, unpaired) |
| no multipath image rejection | suppress_ghosts=False | 0.993 | 0.97 | 31/31 | 8 | 0.302 | fail (unpaired) |
| noise only model order test | rel_floor_db=None | 0.997 | 0.99 | 31/31 | 36 | 0.303 | fail (unpaired) |
| receive only shortcut | shortcut_baseline.py | 0.619 | 0.37 | 0/31 | 49 | 0.532 | fail (all three) |
| reference on the development unit | its own truth (71 objects) | 1.000 | 1.00 | 2/2 | 1 | 0.175 | reference only |

Each bar sits between the weaker of the two independent correct chains and the strongest broken one:
recall 0.977 correct against 0.914 broken, unpaired rows 4 correct against 8 broken, azimuth 0.309
correct against 0.445 broken.

Timing: through the verifier's harness the reference takes 2.83 s per scan at worst and 1.77 s on
average on the author's laptop, against the 20 s per scan limit stated in the instruction. No scan
failed the protocol.

Things worth stating plainly rather than burying:

- A 5 dB detection threshold fails. The reference is robust to raising the threshold and to both
  weaker and stronger excision, but not to lowering the detection threshold, where noise peaks
  become unpaired rows. The difficulty explanation does not claim otherwise.
- The development unit is slightly easier than the hidden ones (reference 1.000 recall, 0.175 deg
  there against 0.993 and 0.302 on the hidden units), so a chain tuned until it looks perfect on the
  dev scans still has margin to lose.
- The azimuth bar is the least discriminating of the three. It separates calibration failures
  (0.752 and 1.218) and the shortcut (0.532) from correct chains, but recall and unpaired rows carry
  most of the grading.

The independent chain differs from the reference at every stage: chirp level screening of the range
spectrum floor, CA-CFAR on the unfolded map, TX assignment by the fit of a one or two source array
model rather than the empty band power test, DTFT refinement of range and Doppler, the Doppler
ambiguity resolved by regressing range over four quarter frames instead of differencing two halves,
calibration averaged over both reflector captures, and a power ordered image rejection walk.

Scores are deterministic. Repeated `evaluate.py` runs give identical numbers.

## History

The first version of this task handed the agent all 24 graded scans as data and asked for one CSV. A
difficulty probe solved it 7 times out of 8; the run audit showed every agent building the four
cruxes of that version within about an hour. Three cruxes were added and it was probed again: 0 of 8,
but the audit failed it on specification completeness, because the multipath images were not
mentioned in the instruction and every failing agent had lost only on those rows while scoring better
than the reference on everything else.

This version states the images explicitly and moves the difficulty to ground that disclosure cannot
give away: the deliverable is a program, it is graded on hidden scans from unseen sensor units so
calibration and thresholds have to generalize, velocities run past what the waveform can resolve on
its own, and each scan has a fixed compute budget.
