"""
The quick attempt a reviewer might write in a few minutes: fold the Doppler
axis, find the empty band, but skip the MIMO bookkeeping by estimating
azimuth from each TX copy's four RX channels separately (RX only
calibration from the boresight reflector) and summing the three spectra
non coherently. No interference handling, no velocity disambiguation beyond
the DDMA span, no multipath handling, one global threshold, one angle per
detection. It avoids TX phase calibration entirely at the price of a 1.5
wavelength aperture instead of 5.5.
"""
import json
import os

import numpy as np


class Ctx:
    def __init__(self, data_dir):
        with open(os.path.join(data_dir, "radar_config.json")) as f:
            cfg = json.load(f)
        self.K, self.N, self.NRX = cfg["chirps_per_frame"], cfg["samples_per_chirp"], cfg["num_rx"]
        self.q = self.K // 4
        self.lam = cfg["speed_of_light_mps"] / cfg["carrier_frequency_hz"]
        self.rbin = cfg["speed_of_light_mps"] * cfg["adc_sample_rate_hz"] / (2 * cfg["chirp_slope_hz_per_s"] * self.N)
        self.vbin = self.lam / (2 * self.K * cfg["chirp_repetition_interval_s"])
        self.rxy = np.array(cfg["rx_positions_y_m"])
        cal = [c for c in cfg["calibration_captures"] if c["azimuth_deg"] == 0][0]
        Xc = self.load(os.path.join(data_dir, cal["file"]))
        r0 = int(round(cal["range_m"] / self.rbin))
        rc = r0 - 2 + int(np.argmax((np.abs(Xc[0, :, r0 - 2:r0 + 3]) ** 2).sum(axis=0)))
        self.grx = Xc[0, :, rc] / Xc[0, 0, rc]
        self.grid = np.linspace(-0.95, 0.95, 1901)
        self.A = np.exp(-2j * np.pi * np.outer(self.grid, self.rxy) / self.lam)

    def load(self, path):
        a = np.fromfile(path, dtype="<i2").reshape(self.K, self.NRX, self.N, 2)
        x = a[..., 0].astype(float) + 1j * a[..., 1]
        X = np.fft.fft(x * np.hanning(self.N), axis=2)
        return np.fft.fft(X * np.hanning(self.K)[:, None, None], axis=0)


def make(data_dir):
    return Ctx(data_dir)


def run_scan(ctx, scan_path):
    X = ctx.load(scan_path)
    P = (np.abs(X) ** 2).sum(axis=1)
    bands = P.reshape(4, ctx.q, ctx.N)
    S = bands.sum(0) - bands.min(0)
    thr = 8.0 * np.median(S)
    rows = []
    for c in range(ctx.q):
        for r in range(5, ctx.N - 8):
            v0 = S[c, r]
            if v0 < thr:
                continue
            nb = S[[(c - 1) % ctx.q, c, (c + 1) % ctx.q]][:, r - 1:r + 2]
            if v0 < nb.max():
                continue
            be = int(np.argmin(bands[:, c, r]))
            d0 = (c + ctx.q * be - ctx.q) % ctx.K
            spec = np.zeros(len(ctx.grid))
            for m in range(3):
                spec += np.abs(ctx.A.conj() @ (X[(d0 - ctx.q * m) % ctx.K, :, r] / ctx.grx)) ** 2
            u = ctx.grid[np.argmax(spec)]
            ds = d0 if d0 < ctx.K / 2 else d0 - ctx.K
            rows.append((r * ctx.rbin, ds * ctx.vbin, float(np.degrees(np.arcsin(u)))))
    return rows
