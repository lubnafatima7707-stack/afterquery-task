"""
Seeded scene and raw ADC generator for ddma-radar-targets.

Truth comes first. For every scan a list of point reflectors (range at the
frame midpoint, constant radial velocity, fixed azimuth, RCS) is drawn from the
seeded RNG, and only afterwards is the raw complex baseband ADC signal of a
3 TX / 4 RX DDMA FMCW radar synthesized from it, with the imperfections a real
front end has: per TX and per RX complex gain errors, DDMA phase shifter state
errors, TX to RX leakage, thermal noise, 16 bit quantization, bursts of mutual
interference in some scans, and multipath images of strong vehicles, which are
put into the signal but never into the truth.

Five sensor units of the same design are simulated, each with its own front end
errors and its own pair of corner reflector calibration captures. The
development unit's captures and six of its scans go to the agent, without
truth. The four other units record the 24 hidden graded scans, which live only
in tests/hidden.

Run from anywhere:  python generate_scenes.py
"""
import csv
import json
import os
import shutil

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.abspath(os.path.join(HERE, "..", ".."))
ENV_DATA = os.path.join(BUNDLE, "environment", "data")
TESTS = os.path.join(BUNDLE, "tests")
HIDDEN = os.path.join(TESTS, "hidden")

SEED = 20260911

C0 = 299792458.0
FC = 77.0e9
LAM = C0 / FC
SLOPE = 15.0e12          # Hz per second
FS = 10.0e6              # complex samples per second
NS = 256                 # samples per chirp
NCHIRP = 128             # chirps per frame
TC = 40.0e-6             # chirp repetition interval
ADC_START = 4.0e-6       # ADC start after ramp start
NTX, NRX = 3, 4
NBANDS = 4               # DDMA Doppler sub bands, one left empty
TX_Y = np.array([0.0, 2.0, 4.0]) * LAM
RX_Y = np.array([0.0, 0.5, 1.0, 1.5]) * LAM
NOISE_LSB = 4.0          # per I and per Q component
HPF_RC = 10.0            # range where the IF high pass is 3 dB down (power)
K_AMP = 1622.0           # radar equation constant in LSB * m^2 / sqrt(m^2)

N_DEV_SCANS = 6
DEV_HIGHWAY = (False, False, True, False, True, False)
DEV_INTERFERED = (False, True, False, False, True, False)
N_HIDDEN_UNITS = 4
SCANS_PER_UNIT = 6
N_HIDDEN_INTERFERED = 9
P_HIGHWAY = 0.4

V_ABS_MAX = 44.0         # highway closing speeds; the DDMA span alone covers only about +/-24.3 m/s
FAST_SPEED_MPS = 20.0    # reflectors faster than this must be strong enough for range rate to
FAST_SNR_FLOOR_DB = 20.0  # settle the Doppler ambiguity, so the truth stays decidable
SNR_FLOOR_DB = 12.0      # per virtual channel coherent SNR; weaker reflectors are not placed
CLOSE_PAIR_SEP_MIN_DEG = 3.5   # inside the 12 element array's beamwidth of about 9.5 degrees
CLOSE_PAIR_SEP_MAX_DEG = 8.0
GHOST_RANGE_MIN_M = 1.0        # bumper and road bounce images of a strong vehicle: same azimuth
GHOST_RANGE_MAX_M = 2.2        # and radial velocity, a little further out, much weaker
GHOST_ATTENUATION_DB = (10.0, 18.0)
R_MIN, R_MAX = 6.0, 92.0

T_MID = NCHIRP * TC / 2.0
V_BIN = LAM / (2.0 * NCHIRP * TC)
R_BIN = C0 * FS / (2.0 * SLOPE * NS)
CLASS_BINS = NCHIRP // NBANDS

CALIB_META = [dict(file="calib/reflector_0deg.bin", range_m=5.0, azimuth_deg=0.0),
              dict(file="calib/reflector_25deg_left.bin", range_m=6.0, azimuth_deg=25.0)]


def hpf_gain(r):
    x = (r / HPF_RC) ** 2
    return x / (1.0 + x)


def pattern(az_deg):
    return np.cos(np.radians(az_deg)) ** 1.5


def amplitude(r, az_deg, rcs_dbsm):
    return K_AMP * np.sqrt(10.0 ** (rcs_dbsm / 10.0)) / r ** 2 * pattern(az_deg) * hpf_gain(r)


def snr_db(amp):
    """Per virtual channel coherent SNR over the whole frame, no window."""
    return 10.0 * np.log10(amp ** 2 * NS * NCHIRP / (2.0 * NOISE_LSB ** 2))


def doppler_class(v):
    return (v / V_BIN) % NCHIRP % CLASS_BINS


def separated(cand, objects):
    for t in objects:
        if abs(cand["range_m"] - t["range_m"]) < 6 * R_BIN:
            dc = abs(doppler_class(cand["velocity_mps"]) - doppler_class(t["velocity_mps"]))
            dc = min(dc, CLASS_BINS - dc)
            if dc < 6.0:
                return False
    return True


def detectable(r, az, rcs, v):
    floor = FAST_SNR_FLOOR_DB if abs(v) > FAST_SPEED_MPS else SNR_FLOOR_DB
    return snr_db(amplitude(r, az, rcs)) >= floor


def draw_scene(rng, highway):
    objects = []

    def ok(r, azs, v):
        return R_MIN <= r <= R_MAX and abs(v) <= V_ABS_MAX and all(abs(a) <= 50.0 for a in azs)

    def try_add(kind, gen, tries=400):
        for _ in range(tries):
            r, az, v, rcs = gen()
            if not ok(r, [az], v) or not detectable(r, az, rcs, v):
                continue
            cand = dict(kind=kind, range_m=r, azimuth_deg=az, velocity_mps=v, rcs_dbsm=rcs)
            if separated(cand, objects):
                objects.append(cand)
                return

    def add_pair(kind, gen, tries=400):
        for _ in range(tries):
            r, az1, az2, v, rcs1, rcs2 = gen()
            if not ok(r, [az1, az2], v):
                continue
            if not (detectable(r, az1, rcs1, v) and detectable(r, az2, rcs2, v)):
                continue
            a = dict(kind=kind, range_m=r, azimuth_deg=az1, velocity_mps=v, rcs_dbsm=rcs1)
            b = dict(kind=kind, range_m=r, azimuth_deg=az2, velocity_mps=v, rcs_dbsm=rcs2)
            if separated(a, objects):
                objects.extend([a, b])
                return

    def cosd(a):
        return np.cos(np.radians(a))

    # Close pairs: two vehicles abreast, a few degrees apart, which is inside the array's
    # beamwidth. Travelling at the same speed, their radial velocities differ by far less than
    # a Doppler bin, so they share one range Doppler cell and the truth gives them one radial
    # velocity. The second vehicle is usually the weaker reflector.
    def abreast(v_gen):
        def gen():
            azc = rng.uniform(-12.0, 12.0)
            sep = rng.uniform(CLOSE_PAIR_SEP_MIN_DEG, CLOSE_PAIR_SEP_MAX_DEG)
            rcs1 = rng.uniform(8.0, 20.0)
            return (rng.uniform(25.0, 85.0), azc - sep / 2.0, azc + sep / 2.0, v_gen(azc),
                    rcs1, rcs1 + rng.uniform(-10.0, 1.0))
        return gen

    # Wide pairs: stationary structures at equal range on opposite sides, which share range and
    # radial velocity exactly because the radial velocity of a stationary point is -ego cos(az).
    def mirrored(ego):
        def gen():
            azp = rng.uniform(14.0, 32.0)
            rcs1 = rng.uniform(2.0, 12.0)
            return (rng.uniform(10.0, 60.0), azp, -azp, -ego * cosd(azp), rcs1, rcs1 + rng.uniform(-4.0, 4.0))
        return gen

    if highway:
        ego = rng.uniform(20.0, 30.0)
        for _ in range(int(rng.random() < 0.5)):
            add_pair("pair", mirrored(ego))
        for _ in range(1 + int(rng.random() < 0.5)):
            add_pair("close", abreast(lambda azc: rng.uniform(-6.0, 6.0)))

        def same_direction():
            return rng.uniform(15.0, 92.0), rng.uniform(-20.0, 20.0), rng.uniform(-8.0, 6.0), rng.uniform(10.0, 20.0)

        def oncoming():
            az = rng.uniform(6.0, 25.0)
            return rng.uniform(20.0, 92.0), az, -(ego + rng.uniform(12.0, 22.0)) * cosd(az), rng.uniform(10.0, 20.0)

        def roadside():
            az = rng.choice([-1.0, 1.0]) * rng.uniform(15.0, 45.0)
            return rng.uniform(8.0, 75.0), az, -ego * cosd(az), rng.uniform(2.0, 10.0)

        for _ in range(int(rng.integers(2, 5))):
            try_add("vehicle", same_direction)
        for _ in range(int(rng.integers(1, 4))):
            try_add("vehicle", oncoming)
        for _ in range(int(rng.integers(2, 5))):
            try_add("static", roadside)
    else:
        ego = rng.uniform(0.0, 14.0)
        for _ in range(int(rng.random() < 0.8)):
            add_pair("pair", mirrored(ego))

        def close_v(azc):
            u = rng.random()
            if u < 0.45:
                return -ego * cosd(azc) + rng.uniform(-2.0, 2.0)
            if u < 0.8:
                return rng.uniform(-18.0, -6.0)
            return rng.uniform(-5.0, 8.0)

        for _ in range(1 + int(rng.random() < 0.5)):
            add_pair("close", abreast(close_v))

        def vehicle():
            az = rng.uniform(-45.0, 45.0)
            stat = -ego * cosd(az)
            u = rng.random()
            if u < 0.4:
                v = stat - rng.uniform(4.0, 14.0)
            elif u < 0.8:
                v = rng.uniform(-7.0, 7.0)
            else:
                v = stat + rng.uniform(-3.0, 3.0)
            return rng.uniform(8.0, 92.0), az, v, rng.uniform(8.0, 20.0)

        def vru():
            az = rng.uniform(-45.0, 45.0)
            return rng.uniform(18.0, 65.0), az, -ego * cosd(az) + rng.uniform(-3.0, 3.0), rng.uniform(-10.0, -3.0)

        def static():
            az = rng.uniform(-48.0, 48.0)
            return rng.uniform(6.0, 75.0), az, -ego * cosd(az), rng.uniform(0.0, 10.0)

        for _ in range(int(rng.integers(2, 6))):
            try_add("vehicle", vehicle)
        for _ in range(int(rng.integers(2, 5))):
            try_add("vru", vru)
        for _ in range(int(rng.integers(1, 4))):
            try_add("static", static)

    # Multipath images of strong vehicles. They are fed into the signal but never written to the
    # truth list. Each sits at its parent's azimuth and radial velocity, one to two metres beyond
    # it and well below it in amplitude; no real reflector shares a Doppler class within 2.3 m of
    # another, so the pattern is unambiguous.
    ghosts = []
    strong = [t for t in objects if t["rcs_dbsm"] >= 12.0 and t["kind"] in ("vehicle", "close")]
    rng.shuffle(strong)
    for parent in strong[:int(rng.integers(0, 3))]:
        for _ in range(60):
            g = dict(kind="ghost",
                     range_m=parent["range_m"] + rng.uniform(GHOST_RANGE_MIN_M, GHOST_RANGE_MAX_M),
                     azimuth_deg=parent["azimuth_deg"] + rng.normal(0.0, 0.15),
                     velocity_mps=parent["velocity_mps"],
                     rcs_dbsm=parent["rcs_dbsm"] - rng.uniform(*GHOST_ATTENUATION_DB))
            if g["range_m"] > R_MAX:
                continue
            if snr_db(amplitude(g["range_m"], g["azimuth_deg"], g["rcs_dbsm"])) < SNR_FLOOR_DB:
                continue
            if separated(g, [t for t in objects if t is not parent]):
                ghosts.append(g)
                break
    return ego, objects, ghosts


def front_end(rng):
    g_tx = rng.uniform(0.8, 1.2, NTX) * np.exp(1j * rng.uniform(-np.pi / 3, np.pi / 3, NTX))
    g_rx = rng.uniform(0.85, 1.15, NRX) * np.exp(1j * rng.uniform(-np.pi / 3, np.pi / 3, NRX))
    ps_amp_db = rng.normal(0.0, 0.25, (NTX, NBANDS))
    ps_phase_deg = rng.normal(0.0, 4.0, (NTX, NBANDS))
    leak = 15.0 * np.exp(1j * rng.uniform(-np.pi, np.pi, (NTX, NRX)))
    return dict(g_tx=g_tx, g_rx=g_rx, ps_amp_db=ps_amp_db, ps_phase_deg=ps_phase_deg, leak=leak)


def tx_codes(fe):
    """Complex factor each TX puts on the IF samples of chirp k, shape (NTX, NCHIRP).
    The phase shifter adds 90 * m * k degrees to TX m on chirp k; the IF is
    LO times conj(received), so the programmed phase shows up negated."""
    k = np.arange(NCHIRP)
    codes = np.empty((NTX, NCHIRP), dtype=complex)
    for m in range(NTX):
        state = (m * k) % NBANDS
        amp = 10.0 ** (fe["ps_amp_db"][m, state] / 20.0)
        ph = 2.0 * np.pi * m * k / NBANDS + np.radians(fe["ps_phase_deg"][m, state])
        codes[m] = amp * np.exp(-1j * ph)
    return codes


def object_if(r_mid, v, az_deg, amp, psi, fe, codes):
    """Noise free IF cube (NCHIRP, NRX, NS) for one point reflector."""
    k = np.arange(NCHIRP)[:, None, None, None]
    m = np.arange(NTX)[None, :, None, None]
    rx = np.arange(NRX)[None, None, :, None]
    n = np.arange(NS)[None, None, None, :]
    tp = ADC_START + n / FS
    t = k * TC + tp
    rng_t = r_mid + v * (t - T_MID)
    s = np.sin(np.radians(az_deg))
    tau = 2.0 * rng_t / C0 - (TX_Y[m] + RX_Y[rx]) * s / C0
    ph = 2.0 * np.pi * (FC * tau + SLOPE * tau * tp - 0.5 * SLOPE * tau ** 2)
    gain = fe["g_tx"][m] * fe["g_rx"][rx] * codes.T[:, :, None, None]
    sig = amp * np.exp(1j * psi) * gain * np.exp(1j * ph)
    return sig.sum(axis=1)


def leakage_if(fe, codes):
    n = np.arange(NS)
    tone = np.exp(1j * 2.0 * np.pi * (2.0 * SLOPE * 0.10 / C0) * (ADC_START + n / FS))
    out = np.zeros((NCHIRP, NRX, NS), dtype=complex)
    for m in range(NTX):
        out += codes[m][:, None, None] * fe["leak"][m][None, :, None] * tone[None, None, :]
    return out


def interference_if(rng):
    """Mutual interference from another FMCW radar whose chirp slope differs
    from ours: each hit chirp gets a short, broadband, chirped burst."""
    out = np.zeros((NCHIRP, NRX, NS), dtype=complex)
    p_hit = rng.uniform(0.15, 0.35)
    az_i = rng.uniform(-40.0, 40.0)
    steer = np.exp(-1j * 2.0 * np.pi * RX_Y * np.sin(np.radians(az_i)) / LAM)
    hits = []
    n = np.arange(NS)
    for k in range(NCHIRP):
        if rng.random() >= p_hit:
            continue
        dslope = rng.choice([-1.0, 1.0]) * rng.uniform(8.0e12, 30.0e12)
        dur = 1.2 * FS / abs(dslope)
        n0 = rng.uniform(-4.0, NS + 4.0)
        a = NOISE_LSB * 10.0 ** (rng.uniform(34.0, 50.0) / 20.0)
        tt = (n - n0) / FS
        env = np.where(np.abs(tt) < dur / 2.0, np.cos(np.pi * tt / dur) ** 2, 0.0)
        f0 = rng.uniform(-FS / 2, FS / 2)
        burst = a * env * np.exp(1j * (2.0 * np.pi * f0 * tt + np.pi * dslope * tt ** 2 + rng.uniform(0, 2 * np.pi)))
        out[k] += steer[:, None] * burst[None, :]
        hits.append(k)
    return out, dict(p_hit=float(p_hit), azimuth_deg=float(az_i), hit_chirps=len(hits))


def quantize(x, rng):
    x = x + rng.normal(0.0, NOISE_LSB, x.shape) + 1j * rng.normal(0.0, NOISE_LSB, x.shape)
    q = np.empty(x.shape + (2,), dtype="<i2")
    q[..., 0] = np.clip(np.rint(x.real), -32768, 32767)
    q[..., 1] = np.clip(np.rint(x.imag), -32768, 32767)
    return q


def synth_scan(rng, fe, codes, objects, ghosts, interfered):
    x = leakage_if(fe, codes)
    for t in objects + ghosts:
        amp = amplitude(t["range_m"], t["azimuth_deg"], t["rcs_dbsm"])
        t["snr_db"] = float(snr_db(amp))
        x = x + object_if(t["range_m"], t["velocity_mps"], t["azimuth_deg"], amp,
                          rng.uniform(0, 2 * np.pi), fe, codes)
    imeta = None
    if interfered:
        xi, imeta = interference_if(rng)
        x = x + xi
    return quantize(x, rng), imeta


def config_for(unit):
    return {
        "unit": unit,
        "carrier_frequency_hz": FC,
        "speed_of_light_mps": C0,
        "chirp_slope_hz_per_s": SLOPE,
        "adc_sample_rate_hz": FS,
        "adc_start_time_s": ADC_START,
        "samples_per_chirp": NS,
        "chirps_per_frame": NCHIRP,
        "chirp_repetition_interval_s": TC,
        "num_tx": NTX,
        "num_rx": NRX,
        "tx_positions_y_m": [float(v) for v in TX_Y],
        "rx_positions_y_m": [float(v) for v in RX_Y],
        "array_axis": "all antennas lie on the y axis; boresight is +x; +y is to the left",
        "mimo_scheme": "DDMA: all TX transmit on every chirp; TX m phase shifter adds 90*m*k degrees on chirp k (k from 0); one of the four Doppler sub bands is left empty",
        "baseband_convention": "complex samples are LO times conj(received), so beat frequency is positive for a positive range",
        "sample_format": "int16 little endian, interleaved I then Q",
        "file_layout": "C order array of shape [chirp][rx][sample][iq] = [128][4][256][2]",
        "frame_reference_time": "range is reported at the midpoint of the frame, t = chirps_per_frame * chirp_repetition_interval_s / 2 after the first chirp starts",
        "calibration_captures": CALIB_META,
    }


def write_unit(rng, root, unit):
    fe = front_end(rng)
    codes = tx_codes(fe)
    os.makedirs(os.path.join(root, "calib"), exist_ok=True)
    for cap in CALIB_META:
        amp = amplitude(cap["range_m"], cap["azimuth_deg"], 15.0)
        x = object_if(cap["range_m"], 0.0, cap["azimuth_deg"], amp, rng.uniform(0, 2 * np.pi), fe, codes)
        quantize(x + leakage_if(fe, codes), rng).tofile(os.path.join(root, cap["file"]))
    with open(os.path.join(root, "radar_config.json"), "w", newline="\n") as f:
        json.dump(config_for(unit), f, indent=2)
        f.write("\n")
    record = {"unit": unit,
              "tx_gain": [[float(abs(g)), float(np.degrees(np.angle(g)))] for g in fe["g_tx"]],
              "rx_gain": [[float(abs(g)), float(np.degrees(np.angle(g)))] for g in fe["g_rx"]],
              "phase_shifter_amp_err_db": fe["ps_amp_db"].round(4).tolist(),
              "phase_shifter_phase_err_deg": fe["ps_phase_deg"].round(4).tolist()}
    return fe, codes, record


def truth_rows(unit, scan, objects, interfered):
    return [[unit, scan, f"{t['range_m']:.4f}", f"{t['velocity_mps']:.4f}", f"{t['azimuth_deg']:.4f}",
             t["kind"], f"{t['rcs_dbsm']:.2f}", f"{t['snr_db']:.2f}", int(interfered)] for t in objects]


def scan_record(unit, scan, highway, ego, objects, ghosts, imeta):
    return dict(unit=unit, scan=scan, highway=bool(highway), ego_speed_mps=round(float(ego), 4),
                n_objects=len(objects), n_multipath_ghosts=len(ghosts),
                ghosts=[{k: round(float(g[k]), 4) for k in
                         ("range_m", "azimuth_deg", "velocity_mps", "rcs_dbsm", "snr_db")} for g in ghosts],
                interference=imeta)


def write_truth(path, rows):
    with open(path, "w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["unit", "scan", "range_m", "velocity_mps", "azimuth_deg", "kind", "rcs_dbsm",
                    "snr_db", "interfered_scan"])
        w.writerows(rows)


def main():
    rng = np.random.default_rng(SEED)
    shutil.rmtree(ENV_DATA, ignore_errors=True)
    shutil.rmtree(HIDDEN, ignore_errors=True)
    stale = os.path.join(TESTS, "truth_objects.csv")
    if os.path.exists(stale):
        os.remove(stale)

    units = {}
    unit_records = []
    fe, codes, rec = write_unit(rng, ENV_DATA, "dev")
    units["dev"] = (fe, codes)
    unit_records.append(rec)
    for u in range(N_HIDDEN_UNITS):
        name = f"unit_{u + 1}"
        fe, codes, rec = write_unit(rng, os.path.join(HIDDEN, name), name)
        units[name] = (fe, codes)
        unit_records.append(rec)

    scan_records = []
    dev_rows = []
    os.makedirs(os.path.join(ENV_DATA, "dev"), exist_ok=True)
    for i in range(N_DEV_SCANS):
        ego, objects, ghosts = draw_scene(rng, DEV_HIGHWAY[i])
        q, imeta = synth_scan(rng, *units["dev"], objects, ghosts, DEV_INTERFERED[i])
        q.tofile(os.path.join(ENV_DATA, "dev", f"scan_{i:02d}.bin"))
        dev_rows += truth_rows("dev", i, objects, DEV_INTERFERED[i])
        scan_records.append(scan_record("dev", i, DEV_HIGHWAY[i], ego, objects, ghosts, imeta))

    n_hidden = N_HIDDEN_UNITS * SCANS_PER_UNIT
    interfered = set(int(i) for i in rng.choice(n_hidden, N_HIDDEN_INTERFERED, replace=False))
    hidden_rows = []
    for u in range(N_HIDDEN_UNITS):
        name = f"unit_{u + 1}"
        os.makedirs(os.path.join(HIDDEN, name, "scans"), exist_ok=True)
        for j in range(SCANS_PER_UNIT):
            scan = u * SCANS_PER_UNIT + j
            highway = bool(rng.random() < P_HIGHWAY)
            ego, objects, ghosts = draw_scene(rng, highway)
            q, imeta = synth_scan(rng, *units[name], objects, ghosts, scan in interfered)
            q.tofile(os.path.join(HIDDEN, name, "scans", f"scan_{scan:02d}.bin"))
            hidden_rows += truth_rows(name, scan, objects, scan in interfered)
            scan_records.append(scan_record(name, scan, highway, ego, objects, ghosts, imeta))

    write_truth(os.path.join(HIDDEN, "truth_objects.csv"), hidden_rows)
    write_truth(os.path.join(HERE, "dev_truth.csv"), dev_rows)
    record = {
        "seed": SEED,
        "generator": "authoring/provenance/generate_scenes.py",
        "noise_lsb_per_component": NOISE_LSB,
        "units": unit_records,
        "hidden_interfered_scans": sorted(interfered),
        "scans": scan_records,
        "n_hidden_truth_objects": len(hidden_rows),
        "n_dev_truth_objects": len(dev_rows),
    }
    with open(os.path.join(HERE, "provenance_record.json"), "w", newline="\n") as f:
        json.dump(record, f, indent=2)
        f.write("\n")
    n_fast = sum(1 for r in hidden_rows if abs(float(r[3])) > LAM / (4.0 * TC))
    n_ghost = sum(s["n_multipath_ghosts"] for s in scan_records if s["unit"] != "dev")
    print(f"dev: {N_DEV_SCANS} scans, {len(dev_rows)} objects | hidden: {n_hidden} scans, "
          f"{len(hidden_rows)} objects, {n_fast} beyond the DDMA span, {n_ghost} multipath images, "
          f"interfered {sorted(interfered)}")


if __name__ == "__main__":
    main()
