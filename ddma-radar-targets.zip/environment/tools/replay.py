"""
Runs a radar_chain.py the way grading does, on the development scans.

Each scan gets a fresh directory holding only a copy of the program,
radar_config.json, calib/ and the scan as scan.bin, and the program is launched
as `python3 radar_chain.py . scan.bin` on one CPU with a 20 s wall time limit.
Prints every scan's rows and wall time. There is no truth here, so this checks
the contract and the time budget, not accuracy.

Usage: python3 /app/tools/replay.py [program] [data_dir]
       defaults: /app/radar_chain.py /app/data
"""
import math
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time

TIMEOUT_S = 20


def one_cpu():
    if hasattr(os, "sched_setaffinity"):
        os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})


def main():
    program = sys.argv[1] if len(sys.argv) > 1 else "/app/radar_chain.py"
    data = sys.argv[2] if len(sys.argv) > 2 else "/app/data"
    scans = sorted(f for f in os.listdir(os.path.join(data, "dev")) if f.endswith(".bin"))
    ok = True
    for fn in scans:
        work = tempfile.mkdtemp(prefix="replay_")
        try:
            shutil.copyfile(program, os.path.join(work, "radar_chain.py"))
            shutil.copyfile(os.path.join(data, "radar_config.json"), os.path.join(work, "radar_config.json"))
            shutil.copytree(os.path.join(data, "calib"), os.path.join(work, "calib"))
            shutil.copyfile(os.path.join(data, "dev", fn), os.path.join(work, "scan.bin"))
            env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": work, "PYTHONDONTWRITEBYTECODE": "1",
                   "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
            t0 = time.monotonic()
            proc = subprocess.Popen([sys.executable, "radar_chain.py", ".", "scan.bin"], cwd=work, env=env,
                                    stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    start_new_session=True, preexec_fn=one_cpu)
            try:
                out, err = proc.communicate(timeout=TIMEOUT_S)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.communicate()
                print(f"{fn}: FAILED, over the {TIMEOUT_S} s limit")
                ok = False
                continue
            dt = time.monotonic() - t0
            if proc.returncode != 0:
                print(f"{fn}: FAILED, exit status {proc.returncode}\n{err.decode(errors='replace')[-2000:]}")
                ok = False
                continue
            rows, bad = [], None
            for line in out.decode(errors="replace").splitlines():
                if not line.strip():
                    continue
                parts = line.split()
                try:
                    vals = [float(p) for p in parts]
                except ValueError:
                    vals = []
                if len(vals) != 3 or not all(math.isfinite(v) for v in vals):
                    bad = line
                    break
                rows.append(vals)
            if bad is not None:
                print(f"{fn}: FAILED, bad stdout line {bad[:120]!r}")
                ok = False
                continue
            print(f"{fn}: {len(rows)} rows in {dt:.2f} s")
            for r, v, a in rows:
                print(f"    {r:9.4f} {v:9.4f} {a:9.4f}")
        finally:
            shutil.rmtree(work, ignore_errors=True)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
