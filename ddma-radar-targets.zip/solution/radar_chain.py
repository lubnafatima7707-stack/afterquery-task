"""
Reference processing chain for ddma-radar-targets.

    python3 radar_chain.py <data_dir> <scan_file>

<data_dir> holds radar_config.json and the calibration captures it lists, for
the sensor unit that recorded <scan_file>. One line per reflector goes to
stdout as "range_m velocity_mps azimuth_deg"; nothing else is printed there.
"""
import json
import os
import sys

import numpy as np
from scipy.ndimage import binary_dilation, maximum_filter, median_filter
from scipy.optimize import minimize, minimize_scalar

DEFAULTS = dict(mitigate=True, empty_band=True, two_objects=True, thr_db=7.0, excise_factor=6.0,
                wide_only=False, suppress_ghosts=True, rel_floor_db=15.0, disambiguate=True)
V_MAX = 46.0  # the scene bound is 45 m/s; a little margin for estimation error


class Radar:
    def __init__(self, data_dir):
        with open(os.path.join(data_dir, "radar_config.json")) as f:
            cfg = json.load(f)
        self.cfg = cfg
        self.data_dir = data_dir
        self.c0 = cfg["speed_of_light_mps"]
        self.fc = cfg["carrier_frequency_hz"]
        self.lam = self.c0 / self.fc
        self.slope = cfg["chirp_slope_hz_per_s"]
        self.fs = cfg["adc_sample_rate_hz"]
        self.ns = cfg["samples_per_chirp"]
        self.k = cfg["chirps_per_frame"]
        self.tc = cfg["chirp_repetition_interval_s"]
        self.ntx = cfg["num_tx"]
        self.nrx = cfg["num_rx"]
        self.nb = 4
        self.cls = self.k // self.nb
        self.r_bin = self.c0 * self.fs / (2.0 * self.slope * self.ns)
        self.v_bin = self.lam / (2.0 * self.k * self.tc)
        self.v_period = self.lam / (2.0 * self.tc)  # Doppler period left once the TX copies are decoded
        tx = np.array(cfg["tx_positions_y_m"])
        rx = np.array(cfg["rx_positions_y_m"])
        self.pos = (tx[:, None] + rx[None, :]).ravel()  # virtual channel m*nrx + rx
        self.order = np.argsort(self.pos)
        self.gain = np.ones(self.ntx * self.nrx, dtype=complex)
        self.sign = -1.0

    def load_file(self, path):
        raw = np.fromfile(path, dtype="<i2").reshape(self.k, self.nrx, self.ns, 2).astype(float)
        return raw[..., 0] + 1j * raw[..., 1]

    def load_calib(self, rel):
        return self.load_file(os.path.join(self.data_dir, rel))


def excise_interference(x, factor=6.0, dilate=3):
    """Zero the fast time samples hit by an interference burst. Reflectors are
    steady tones whose envelope barely changes chirp to chirp, so a sample far
    above the median envelope at the same sample index is a burst."""
    mag = np.abs(x)
    base = np.maximum(np.median(mag, axis=0, keepdims=True), np.median(mag))
    bad = (mag > factor * base).any(axis=1)
    if dilate:
        bad = binary_dilation(bad, structure=np.ones((1, 2 * dilate + 1), dtype=bool))
    y = x.copy()
    y[np.broadcast_to(bad[:, None, :], y.shape)] = 0.0
    return y


def range_doppler(radar, x):
    wr = np.hanning(radar.ns)
    wd = np.hanning(radar.k)
    X = np.fft.fft(x * wr[None, None, :], axis=2)
    X = np.fft.fft(X * wd[:, None, None], axis=0)
    return X  # [doppler bin][rx][range bin]


def comb_map(radar, P):
    bands = P.reshape(radar.nb, radar.cls, radar.ns)
    return bands, bands.sum(axis=0) - bands.min(axis=0)


def detect(radar, X, thr_db=7.0, r_min=2.0, r_max=97.0, sidelobe_db=22.0):
    P = (np.abs(X) ** 2).sum(axis=1)
    bands, S = comb_map(radar, P)
    noise = median_filter(np.median(S, axis=0), size=21, mode="nearest")
    local = maximum_filter(S, size=(5, 5), mode=("wrap", "nearest"))
    r_idx = np.arange(radar.ns) * radar.r_bin
    ok = (S == local) & (S > noise[None, :] * 10 ** (thr_db / 10)) & (r_idx >= r_min) & (r_idx <= r_max)
    cand = [(S[c, r], c, r) for c, r in zip(*np.nonzero(ok))]
    cand.sort(reverse=True)
    keep = []
    for p, c, r in cand:
        shadow = False
        for q, c2, r2 in keep:
            dc = min((c - c2) % radar.cls, (c2 - c) % radar.cls)
            near = (dc <= 5 and abs(r - r2) <= 1) or (dc <= 1 and abs(r - r2) <= 5)
            if near and q > p * 10 ** (sidelobe_db / 10):
                shadow = True
                break
        if not shadow:
            keep.append((p, c, r))
    return P, bands, [(c, r) for _, c, r in keep], noise


def parabolic(ym, y0, yp):
    a, b, c = np.log(ym + 1e-30), np.log(y0 + 1e-30), np.log(yp + 1e-30)
    den = a - 2 * b + c
    return 0.0 if den >= 0 else 0.5 * (a - c) / den


def decode_comb(radar, P, bands, c, r, empty_band=True):
    """TX0 Doppler bin from the empty sub band, then fractional Doppler and range."""
    if empty_band:
        be = int(np.argmin(bands[:, c, r]))
        d0 = (c + radar.cls * be - radar.cls) % radar.k
    else:
        d0 = c + radar.cls * int(np.argmax(bands[:, c, r]))
    comb = lambda d, rr: sum(P[(d - radar.cls * m) % radar.k, rr] for m in range(radar.ntx))
    dd = parabolic(comb(d0 - 1, r), comb(d0, r), comb(d0 + 1, r))
    rm, rp = max(r - 1, 0), min(r + 1, radar.ns - 1)
    dr = parabolic(comb(d0, rm), comb(d0, r), comb(d0, rp))
    d0f = d0 + dd
    ds = d0f - radar.k if d0f >= radar.k / 2 else d0f
    return d0, d0f, r + dr, ds * radar.v_bin


def half_frame_ranges(radar, x, d0f, rf):
    """Fractional range bin of a reflector measured on each half of the frame,
    from the DTFT of all three TX copies at its fractional Doppler bin."""
    half = radar.k // 2
    wd = np.hanning(half)
    n = np.arange(radar.ns)
    step = 0.02
    grid = rf + np.arange(-75, 76) * step
    E = np.hanning(radar.ns)[None, :] * np.exp(-2j * np.pi * np.outer(grid, n) / radar.ns)
    out = []
    for h in range(2):
        kk = np.arange(h * half, (h + 1) * half)
        xh = x[h * half:(h + 1) * half]
        pw = np.zeros(len(grid))
        for m in range(radar.ntx):
            ed = wd * np.exp(-2j * np.pi * (d0f - radar.cls * m) * kk / radar.k)
            s = np.tensordot(ed, xh, axes=(0, 0))  # (nrx, ns)
            pw += np.sum(np.abs(s @ E.T) ** 2, axis=0)
        i = min(max(int(np.argmax(pw)), 1), len(grid) - 2)
        out.append(grid[i] + parabolic(pw[i - 1], pw[i], pw[i + 1]) * step)
    return out


def resolve_velocity(radar, x, d0f, rf, v_dopp):
    """After DDMA decoding the Doppler velocity is still ambiguous by
    lam / (2 Tc), about 48.7 m/s. The reflector's range walk across the frame
    settles it: one ambiguity step moves it about 0.25 m in 5 ms."""
    r0, r1 = half_frame_ranges(radar, x, d0f, rf)
    v_rr = (r1 - r0) * radar.r_bin / (radar.k // 2 * radar.tc)
    cands = [v_dopp + j * radar.v_period for j in (-1, 0, 1)]
    cands = [v for v in cands if abs(v) <= V_MAX] or [v_dopp]
    return min(cands, key=lambda v: abs(v - v_rr))


def virtual_channels(radar, X, d0, r):
    y = np.array([X[(d0 - radar.cls * m) % radar.k, :, r] for m in range(radar.ntx)]).ravel()
    return y / radar.gain


def steer(radar, u):
    u = np.atleast_1d(u)
    return np.exp(radar.sign * 1j * 2 * np.pi * radar.pos[None, :] * u[:, None] / radar.lam)


def single_refine(radar, y, u0):
    f = lambda u: -np.abs(steer(radar, u)[0].conj() @ y) ** 2
    res = minimize_scalar(f, bounds=(u0 - 0.02, u0 + 0.02), method="bounded", options={"xatol": 1e-7})
    return float(res.x)


def pair_refine(radar, y, u1, u2):
    def resid(uv):
        A = steer(radar, np.array(uv)).T
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        return float(np.sum(np.abs(y - A @ coef) ** 2))
    res = minimize(resid, [u1, u2], method="Nelder-Mead", options={"xatol": 1e-7, "fatol": 1e-12})
    return [float(v) for v in res.x]


def _lsq_residual(radar, y, us):
    A = steer(radar, np.array(us)).T
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    return float(np.sum(np.abs(y - A @ coef) ** 2)), A, coef


def angles(radar, y, sigma2, two_objects=True, min_sep_u=0.02, drop_factor=45.0, wide_only=False,
           rel_floor_db=15.0):
    """One or two azimuths from the twelve virtual channels. A second source is
    accepted only when the joint fit removes far more residual energy than the
    noise floor explains, which is what lets a pair inside one beamwidth split,
    and when the weaker source clears rel_floor_db below the stronger one. The
    relative floor matters: on a 50 dB reflector the one source residual is set
    by array manifold mismatch rather than noise, so a purely noise based test
    splits single reflectors in two."""
    grid = np.linspace(-0.97, 0.97, 3881)
    taper = np.zeros(len(y))
    taper[radar.order] = np.hanning(len(y) + 2)[1:-1]
    spec = np.abs(steer(radar, grid).conj() @ (taper * y)) ** 2
    if not np.all(np.isfinite(spec)) or not spec.any():
        return []
    u1 = single_refine(radar, y, float(grid[int(np.argmax(spec))]))
    r1, A1, c1 = _lsq_residual(radar, y, [u1])
    if not two_objects:
        return [u1]
    resid = y - A1 @ c1
    spec2 = np.abs(steer(radar, grid).conj() @ (taper * resid)) ** 2
    spec2[np.abs(grid - u1) < max(min_sep_u, 0.25 if wide_only else 0.0)] = 0.0
    if not spec2.any():
        return [u1]
    u_pair = pair_refine(radar, y, u1, float(grid[int(np.argmax(spec2))]))
    r2, _, c2 = _lsq_residual(radar, y, u_pair)
    sep = abs(u_pair[0] - u_pair[1])
    amp = np.abs(c2) ** 2
    strong_enough = rel_floor_db is None or amp.min() >= amp.max() * 10 ** (-rel_floor_db / 10)
    sep_floor = 0.25 if wide_only else min_sep_u
    if ((r1 - r2) > drop_factor * sigma2 and sep > sep_floor and strong_enough
            and all(abs(u) < 0.97 for u in u_pair)):
        return u_pair
    return [u1]


def calibrate(radar):
    caps = radar.cfg["calibration_captures"]
    ref = [c for c in caps if abs(c["azimuth_deg"]) < 1e-6][0]
    X = range_doppler(radar, radar.load_calib(ref["file"]))
    P, bands, dets, _ = detect(radar, X)
    r_exp = ref["range_m"] / radar.r_bin
    c, r = min(dets, key=lambda cr: abs(cr[1] - r_exp) - 1e-12 * bands[:, cr[0], cr[1]].sum())
    d0 = decode_comb(radar, P, bands, c, r)[0]
    y = np.array([X[(d0 - radar.cls * m) % radar.k, :, r] for m in range(radar.ntx)]).ravel()
    radar.gain = y / y[0]
    # settle the steering sign with the off boresight reflector
    other = [c for c in caps if abs(c["azimuth_deg"]) > 1e-6][0]
    X2 = range_doppler(radar, radar.load_calib(other["file"]))
    P2, b2, d2, noise2 = detect(radar, X2)
    r_exp = other["range_m"] / radar.r_bin
    c2, r2 = min(d2, key=lambda cr: abs(cr[1] - r_exp))
    d02 = decode_comb(radar, P2, b2, c2, r2)[0]
    y2 = virtual_channels(radar, X2, d02, r2)
    best = None
    for s in (-1.0, 1.0):
        radar.sign = s
        u = angles(radar, y2, noise2[r2] / (radar.ntx * radar.nrx), two_objects=False)[0]
        err = abs(np.degrees(np.arcsin(u)) - other["azimuth_deg"])
        if best is None or err < best[0]:
            best = (err, s)
    radar.sign = best[1]
    return best[0]


def process_scan(radar, x, o):
    if o["mitigate"]:
        x = excise_interference(x, factor=o["excise_factor"])
    X = range_doppler(radar, x)
    P, bands, dets, noise = detect(radar, X, thr_db=o["thr_db"])
    out = []
    for c, r in dets:
        d0, d0f, rf, v_dopp = decode_comb(radar, P, bands, c, r, empty_band=o["empty_band"])
        v = resolve_velocity(radar, x, d0f, rf, v_dopp) if o["disambiguate"] else v_dopp
        rng = rf * radar.r_bin - v * radar.fc / radar.slope  # range Doppler coupling uses the true velocity
        y = virtual_channels(radar, X, d0, r)
        sigma2 = noise[r] / (radar.ntx * radar.nrx)
        power = sum(P[(d0 - radar.cls * m) % radar.k, r] for m in range(radar.ntx))
        for u in angles(radar, y, sigma2, two_objects=o["two_objects"], wide_only=o["wide_only"],
                        rel_floor_db=o["rel_floor_db"]):
            if abs(u) < 0.97:
                out.append((rng, v, float(np.degrees(np.arcsin(u))), float(power)))
    return out


def drop_multipath_ghosts(dets, az_tol=1.2, v_tol=0.25, dr_min=0.5, dr_max=2.6, att_db=8.0):
    """A bounce image sits at the azimuth and radial velocity of a much stronger
    reflector, a metre or two further out. Nothing physical is there, so drop it."""
    keep = []
    for rng_, v, az, p in dets:
        image = any(p2 > p * 10 ** (att_db / 10) and dr_min < (rng_ - rng2) < dr_max
                    and abs(v - v2) < v_tol and abs(az - az2) < az_tol
                    for rng2, v2, az2, p2 in dets)
        if not image:
            keep.append((rng_, v, az))
    return keep


def make_radar(data_dir, calib=True):
    radar = Radar(data_dir)
    if calib:
        calibrate(radar)
    return radar


def run_scan(radar, scan_path, **opts):
    o = dict(DEFAULTS)
    o.update(opts)
    dets = process_scan(radar, radar.load_file(scan_path), o)
    return drop_multipath_ghosts(dets) if o["suppress_ghosts"] else [d[:3] for d in dets]


def main(argv):
    if len(argv) != 3:
        sys.stderr.write("usage: radar_chain.py <data_dir> <scan_file>\n")
        return 2
    rows = run_scan(make_radar(argv[1]), argv[2])
    sys.stdout.write("".join(f"{r:.4f} {v:.4f} {a:.4f}\n" for r, v, a in rows))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
