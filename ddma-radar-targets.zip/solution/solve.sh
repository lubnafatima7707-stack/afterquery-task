#!/bin/bash
set -euo pipefail
cp "$(dirname "$0")/radar_chain.py" /app/radar_chain.py
