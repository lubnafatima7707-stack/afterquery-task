"""
Runs the agent's radar_chain.py on one hidden scan.

Each run gets a fresh directory holding only a copy of the program, the
radar_config.json and calibration captures of the sensor unit that recorded
the scan, and the scan itself as scan.bin. The program is launched as
`python3 radar_chain.py . scan.bin` by an unprivileged user, pinned to one CPU,
in its own session, with a wall time limit. Its whole process group and every
process the unprivileged user still owns are killed afterwards, so nothing it
starts can outlive the run. Hidden scans, truth and this file are readable by
root only.
"""
import math
import os
import shutil
import signal
import subprocess
import sys
import tempfile

RUN_USER = "runner"
MAX_STDOUT_BYTES = 2_000_000


class ProgramFailure(Exception):
    pass


def _as_root():
    return hasattr(os, "geteuid") and os.geteuid() == 0


def _kill_group(proc):
    if os.name == "posix":
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
    try:
        proc.kill()
    except OSError:
        pass


def _kill_user_processes(uid):
    if not os.path.isdir("/proc"):
        return
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            with open(f"/proc/{pid}/status") as f:
                for line in f:
                    if line.startswith("Uid:"):
                        if int(line.split()[1]) == uid:
                            os.kill(int(pid), signal.SIGKILL)
                        break
        except (OSError, ValueError):
            pass


def _one_cpu():
    if hasattr(os, "sched_setaffinity"):
        os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})


def parse_rows(text):
    rows = []
    for i, line in enumerate(text.splitlines()):
        if not line.strip():
            continue
        parts = line.split()
        if len(parts) != 3:
            raise ProgramFailure(f"stdout line {i + 1} does not have 3 fields: {line[:120]!r}")
        try:
            vals = tuple(float(p) for p in parts)
        except ValueError:
            raise ProgramFailure(f"stdout line {i + 1} is not numeric: {line[:120]!r}")
        if not all(math.isfinite(v) for v in vals):
            raise ProgramFailure(f"stdout line {i + 1} has a non finite value")
        rows.append(vals)
    return rows


def run_program(program, unit_dir, scan_path, timeout_s, stderr_path):
    if not os.path.isfile(program):
        raise ProgramFailure(f"{program} does not exist")
    work = tempfile.mkdtemp(prefix="radar_")
    uid = None
    try:
        shutil.copyfile(program, os.path.join(work, "radar_chain.py"))
        shutil.copyfile(os.path.join(unit_dir, "radar_config.json"), os.path.join(work, "radar_config.json"))
        shutil.copytree(os.path.join(unit_dir, "calib"), os.path.join(work, "calib"))
        shutil.copyfile(scan_path, os.path.join(work, "scan.bin"))
        extra = {}
        if _as_root():
            import pwd
            pw = pwd.getpwnam(RUN_USER)
            uid = pw.pw_uid
            for root, dirs, files in os.walk(work):
                os.chown(root, pw.pw_uid, pw.pw_gid)
                for fn in files:
                    os.chown(os.path.join(root, fn), pw.pw_uid, pw.pw_gid)
            extra = dict(user=pw.pw_uid, group=pw.pw_gid, extra_groups=[])
        os.chmod(work, 0o700)
        if os.name == "posix":
            extra.update(start_new_session=True, preexec_fn=_one_cpu)
        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": work, "PYTHONDONTWRITEBYTECODE": "1",
               "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
        if os.name != "posix":
            env.update({k: v for k, v in os.environ.items() if k.upper() in ("SYSTEMROOT", "PATH")})
        with open(stderr_path, "wb") as err:
            proc = subprocess.Popen([sys.executable, "radar_chain.py", ".", "scan.bin"], cwd=work, env=env,
                                    stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=err,
                                    close_fds=True, **extra)
            try:
                out, _ = proc.communicate(timeout=timeout_s)
            except subprocess.TimeoutExpired:
                _kill_group(proc)
                proc.communicate()
                raise ProgramFailure(f"exceeded the {timeout_s} s wall time limit")
            finally:
                _kill_group(proc)
                if uid is not None:
                    _kill_user_processes(uid)
        if proc.returncode != 0:
            raise ProgramFailure(f"exited with status {proc.returncode}")
        if len(out) > MAX_STDOUT_BYTES:
            raise ProgramFailure("wrote more than 2 MB to stdout")
        return parse_rows(out.decode("utf-8", errors="replace"))
    finally:
        shutil.rmtree(work, ignore_errors=True)
