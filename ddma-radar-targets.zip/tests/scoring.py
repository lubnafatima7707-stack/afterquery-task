"""Object list matching and metrics shared by the verifier and the authoring evidence scripts."""
import csv
import math

import numpy as np
from scipy.optimize import linear_sum_assignment

GATE_RANGE_M = 0.5
GATE_VEL_MPS = 0.4
GATE_AZ_DEG = 2.0


def read_truth(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        r["scan"] = int(r["scan"])
        for k in ("range_m", "velocity_mps", "azimuth_deg", "rcs_dbsm", "snr_db"):
            r[k] = float(r[k])
        r["interfered_scan"] = int(r["interfered_scan"])
    return rows


def match_scan(pred, truth):
    """pred, truth: arrays (n, 3) of range, velocity, azimuth. Returns list of (i_pred, i_truth)."""
    if len(pred) == 0 or len(truth) == 0:
        return []
    dr = np.abs(pred[:, None, 0] - truth[None, :, 0])
    dv = np.abs(pred[:, None, 1] - truth[None, :, 1])
    da = np.abs(pred[:, None, 2] - truth[None, :, 2])
    feasible = (dr <= GATE_RANGE_M) & (dv <= GATE_VEL_MPS) & (da <= GATE_AZ_DEG)
    cost = (dr / GATE_RANGE_M) ** 2 + (dv / GATE_VEL_MPS) ** 2 + (da / GATE_AZ_DEG) ** 2
    cost = np.where(feasible, cost, 1e6)
    ip, it = linear_sum_assignment(cost)
    return [(a, b) for a, b in zip(ip, it) if feasible[a, b]]


def evaluate(pred_rows, truth_rows):
    """pred_rows: list of (scan, range, velocity, azimuth). Returns a metrics dict."""
    scans = sorted({t["scan"] for t in truth_rows})
    matched_truth = []
    errs = []
    n_false = 0
    for s in scans:
        tr = [t for t in truth_rows if t["scan"] == s]
        T = np.array([[t["range_m"], t["velocity_mps"], t["azimuth_deg"]] for t in tr])
        Pd = np.array([[p[1], p[2], p[3]] for p in pred_rows if p[0] == s]).reshape(-1, 3)
        pairs = match_scan(Pd, T)
        n_false += len(Pd) - len(pairs)
        for a, b in pairs:
            matched_truth.append(tr[b])
            errs.append(Pd[a] - T[b])
    n_false += sum(1 for p in pred_rows if p[0] not in scans)
    errs = np.array(errs).reshape(-1, 3)
    hit = {id(t) for t in matched_truth}

    def recall(sel):
        sub = [t for t in truth_rows if sel(t)]
        return sum(1 for t in sub if id(t) in hit) / max(len(sub), 1), len(sub)

    rmse = lambda col: float(np.sqrt(np.mean(errs[:, col] ** 2))) if len(errs) else math.inf
    return {
        "n_truth": len(truth_rows),
        "n_pred": len(pred_rows),
        "n_matched": len(matched_truth),
        "n_false": n_false,
        "recall": recall(lambda t: True)[0],
        "recall_weak": recall(lambda t: t["snr_db"] < 22.0),
        "recall_interfered": recall(lambda t: t["interfered_scan"] == 1),
        "recall_pairs": recall(lambda t: t["kind"] == "pair"),
        "recall_close": recall(lambda t: t["kind"] == "close"),
        "recall_fast": recall(lambda t: abs(t["velocity_mps"]) > 24.33),
        "range_rmse_m": rmse(0),
        "vel_rmse_mps": rmse(1),
        "az_rmse_deg": rmse(2),
    }
