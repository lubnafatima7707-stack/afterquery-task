"""
Sealed verifier for ddma-radar-targets.

Runs the agent's /app/radar_chain.py once per hidden scan through harness.py:
a fresh directory holding only that scan, the radar_config.json of the sensor
unit that recorded it and that unit's two calibration captures, an unprivileged
user, one CPU and a wall time limit per scan. The 24 hidden scans come from
four sensor units the agent never sees; truth is the reflector list the seeded
simulator drew before synthesizing any signal (authoring/provenance).
"""
import json
import os

import pytest

import scoring
from harness import ProgramFailure, run_program

PROGRAM = "/app/radar_chain.py"
HIDDEN_DIR = "/tests/hidden"
TRUTH_PATH = "/tests/hidden/truth_objects.csv"
LOG_DIR = "/logs/verifier"

EXPECTED_SCANS = 24
TIMEOUT_PER_SCAN_S = 20
MIN_RECALL = 0.95
MAX_UNPAIRED_ROWS = 6
MAX_AZ_RMSE_DEG = 0.45


def hidden_jobs():
    jobs = []
    for unit in sorted(os.listdir(HIDDEN_DIR)):
        scans = os.path.join(HIDDEN_DIR, unit, "scans")
        if not os.path.isdir(scans):
            continue
        for fn in sorted(os.listdir(scans)):
            if fn.startswith("scan_") and fn.endswith(".bin"):
                jobs.append((int(fn[5:-4]), os.path.join(HIDDEN_DIR, unit), os.path.join(scans, fn)))
    return jobs


@pytest.fixture(scope="module")
def outcome():
    jobs = hidden_jobs()
    rows, failures = [], {}
    os.makedirs(LOG_DIR, exist_ok=True)
    for scan, unit_dir, path in jobs:
        try:
            dets = run_program(PROGRAM, unit_dir, path, TIMEOUT_PER_SCAN_S,
                               os.path.join(LOG_DIR, f"stderr_scan_{scan:02d}.txt"))
            rows += [(scan,) + d for d in dets]
        except ProgramFailure as e:
            failures[scan] = str(e)
    metrics = scoring.evaluate(rows, scoring.read_truth(TRUTH_PATH))
    try:
        with open(os.path.join(LOG_DIR, "metrics.json"), "w") as f:
            json.dump({"metrics": metrics, "failures": failures, "n_scans": len(jobs)}, f, indent=2)
    except OSError:
        pass
    return metrics, failures, len(jobs)


def test_all_hidden_scans_present(outcome):
    assert outcome[2] == EXPECTED_SCANS, f"found {outcome[2]} hidden scans, expected {EXPECTED_SCANS}"


def test_every_scan_runs(outcome):
    failures = outcome[1]
    assert not failures, "radar_chain.py failed on hidden scans: " + "; ".join(
        f"scan {k}: {v}" for k, v in sorted(failures.items()))


def test_recall(outcome):
    m = outcome[0]
    assert m["recall"] >= MIN_RECALL, (
        f"paired {m['n_matched']} of {m['n_truth']} true reflectors (recall {m['recall']:.3f}), "
        f"need at least {MIN_RECALL}")


def test_unpaired_rows(outcome):
    m = outcome[0]
    assert m["n_false"] <= MAX_UNPAIRED_ROWS, (
        f"{m['n_false']} reported rows did not pair with any true reflector, at most {MAX_UNPAIRED_ROWS} allowed")


def test_azimuth_accuracy(outcome):
    m = outcome[0]
    assert m["n_matched"] > 0, "no reported row paired with a true reflector"
    assert m["az_rmse_deg"] <= MAX_AZ_RMSE_DEG, (
        f"RMS azimuth error over paired reflectors is {m['az_rmse_deg']:.3f} deg, must be at most {MAX_AZ_RMSE_DEG}")
