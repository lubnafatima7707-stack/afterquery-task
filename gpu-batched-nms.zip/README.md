# gpu-batched-nms

## Difficulty

`environment/nms_kernel.py` is a batched CUDA non max suppression kernel
for oriented (rotated) detection boxes. One thread handles one candidate
pair: it clips box i's rotated quadrilateral against box j's with
Sutherland Hodgman and keeps a byte saying whether the resulting polygon's
area clears the IoU threshold. The polygon clipping keeps its output in a
fixed size scratch array; clipping a quadrilateral against a second
quadrilateral can add one vertex per edge of the clip polygon, so the true
worst case is eight vertices, and the starter's buffer holds six, enough
for a near axis aligned pair but not for two boxes at a generic relative
angle.

Measured directly during authoring, of 5000 near duplicate rotated box
pairs with fifteen degrees of heading jitter between them, 1436 have a
true IoU between 0.71 and 0.98 but a six vertex capped IoU between 0.30
and 0.50: comfortably over the 0.5 threshold in truth, comfortably under
it once the buffer drops the seventh and eighth vertex. `environment/data
/dev_quiet.npz` uses clusters where every proposal shares the same heading
exactly, so no overlap ever needs more than four vertices and the bug
never shows. `environment/data/dev_busy.npz` uses the same kind of scene
with heading jitter inside each cluster, which needs seven or eight
vertices most of the time.

Fixing the buffer alone is not enough. Sizing it to seven, one plausible
guess better than six, still drops the rare octagon and still fails every
busy hidden workload; only eight, the true worst case for two
quadrilaterals, is correct on all of them. Fixing correctness by moving
the pairwise clipping onto a single thread per image instead of one thread
per candidate pair is graded separately: it is correct everywhere and
still fails, because grading holds the fix to a deadline measured against
a properly parallel reference on the same hardware.

Ground truth comes from `authoring/provenance/geometry.py`, a pure numpy
polygon clip with no vertex cap at all, disjoint from both CUDA kernels.
Every pairwise IoU in the generated scenes is kept at least 0.12 away from
the 0.5 threshold using that same geometry, so grading never turns on a
floating point boundary call. The six hidden workloads vary batch size,
box count and heading jitter well past the two dev examples, with
different seeds, so passing them requires the true worst case buffer size,
not a constant that happened to work on the dev data.

## Reference solution

`solution/nms_kernel.py` widens the scratch buffer from six vertices to
eight and changes nothing else about the kernel: still one thread per
candidate pair, still the exact polygon intersection area, still a short
host side pass that walks the resulting pairwise byte matrix in score
order once it is back from the device, since deciding which candidate is
suppressed by which earlier surviving one is inherently sequential in a
way the pairwise overlap computation is not.

## Verification

`tests/harness.py` imports `/app/nms_kernel.py` and calls it against six
sealed hidden workloads (`tests/hidden/`), two quiet and four busy, none
matching the dev examples' box counts, batch sizes or seeds.

Two independent checks per workload, both required:

- **Accuracy**: every accuracy call runs in its own subprocess as the
  unprivileged `runner` user, in a private directory holding only a
  scrubbed copy of the workload (boxes, scores, thresholds, never ground
  truth), killed by process group on a timeout. The exact keep mask must
  match ground truth on every image, on every one of 7 independent calls.
- **Deadline**: the submitted kernel and the sealed reference kernel each
  run in their own persistent worker process, one per unprivileged
  account so neither the agent's account nor its process can read the
  other's files or module. The root parent, which never imports either
  kernel, alternates timed calls between the two workers and measures
  elapsed time itself around each call, using a clock that lives only in
  its own process. The submission's fastest of 9 timed calls must be at
  most 1.6x the reference's fastest call in the same run.

This design was checked against a submission that patches
`time.perf_counter` to zero at import time and then really sleeps half a
second per call: the harness still measured that call at close to its
true 500 ms cost, because the number it records is never read from
anything the submitted code touches (`authoring/evidence
/malicious_kernel_test.py`, result in `cheat_attempts.md`).

`authoring/evidence/evaluate.py` rescores the reference and two weakened
variants with the same style of scoring the verifier uses: the unmodified
starter (six vertex buffer) and a seven vertex partial fix. Both fail
every busy workload; a third variant, correct but serialized onto one
thread per image, passes accuracy everywhere and fails the deadline
everywhere. `results.md` and `cheat_attempts.md` carry the numbers and
reasons.
