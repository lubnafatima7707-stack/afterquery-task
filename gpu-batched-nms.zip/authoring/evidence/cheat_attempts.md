# Cheat attempts and calibration evidence

`evaluate.py` scores the reference solution and two weakened variants of it,
plus the starter kernel, against every dev and hidden workload, timing each
with a plain warm loop (not the verifier's isolated dual worker protocol,
since this file is meant to be re run quickly by hand; the isolation and
external timing are exercised separately, see "Anti cheat check" below).
Numbers below are from the run captured in `results.md`.

## Summary table

| candidate | dev_quiet | dev_busy | h1_quiet | h2_quiet | h3_busy | h4_busy | h5_busy | h6_busy |
|---|---|---|---|---|---|---|---|---|
| reference (oracle) | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| starter (buffer sized 6) | PASS | fail | PASS | PASS | fail | fail | fail | fail |
| partial fix (buffer sized 7) | PASS | PASS | PASS | PASS | fail | fail | fail | fail |
| slow safe serial (buffer sized 8, one thread per image) | PASS* | PASS* | PASS* | PASS* | PASS* | PASS* | PASS* | PASS* |

\* accuracy passes; every one of these workloads fails the deadline check,
see the timing table below. "PASS" in this table means accuracy only; the
deadline check is graded and reported separately because the point of this
variant is that it is correct and still fails the task.

Only the reference passes both halves everywhere. The starter and the
partial fix fail for the same underlying reason at different thresholds
(buffer too small for the true worst case), which is the point: seven is
not obviously wrong, it is wrong for exactly the same reason six is, just
less often. The slow safe serial variant fails for a completely different
reason, never touching accuracy.

## What each variant is, and why it fails

**Starter, buffer sized six** (`environment/nms_kernel.py`): the Sutherland
Hodgman clip of one rotated box's quadrilateral against another can produce
up to eight vertices, one extra vertex per edge of the clip polygon. A
scratch buffer sized for six, a plausible guess if someone tested only near
axis aligned pairs, silently drops the seventh and eighth vertex once
clipping needs them, which understates the intersection area and lets a
near duplicate box survive with an IoU just under the threshold instead of
comfortably over it. This never happens on the quiet workloads, where
cluster proposals share the same heading exactly, so every overlap stays a
simple quadrilateral. It happens on every busy workload, where proposals in
a cluster carry six to twenty degrees of heading jitter and the true
overlap needs seven or eight vertices most of the time (measured directly:
of 5000 near duplicate rotated pairs at fifteen degrees of jitter, 1436
have a true IoU between 0.71 and 0.98 but a six vertex capped IoU between
0.30 and 0.50, straddling the 0.5 threshold on the wrong side). The starter
fails accuracy on dev_busy and all four busy hidden workloads, every image,
not intermittently.

**Partial fix, buffer sized seven** (`variants/partial_fix_maxv7.py`): the
next number up from six. Still short of the true worst case of eight, so it
still drops the rare octagon and is still wrong on every busy hidden
workload. This variant exists to show that the fix has to be the actual
worst case bound from the geometry, not a larger number chosen without
working out why eight is the answer.

**Slow safe serial** (`variants/slow_safe_serial.py`): the buffer is the
correct size (eight) and the geometry is exact, so accuracy is perfect
everywhere. The pairwise clipping runs on a single thread per image instead
of one thread per candidate pair, giving up exactly the parallelism a busy
scene's deadline depends on. This is the tempting response to being told
the kernel is wrong on busy scenes: make it definitely correct by doing
everything on one thread. It passes every accuracy check and fails the
deadline on every workload, quiet and busy alike, because giving up all
pairwise parallelism costs time even on a small scene.

## Timing table (min of 5 warm calls, this machine)

| workload | reference ms | slow safe serial ms | ratio |
|---|---|---|---|
| dev_quiet | 0.56 | 1.30 | 2.3x |
| dev_busy | 0.91 | 4.86 | 5.3x |
| h1_quiet | 0.69 | 1.75 | 2.5x |
| h2_quiet | 0.57 | 2.44 | 4.3x |
| h3_busy | 0.75 | 3.32 | 4.4x |
| h4_busy | 0.75 | 8.99 | 12.0x |
| h5_busy | 0.76 | 20.28 | 26.7x |
| h6_busy | 1.17 | 5.08 | 4.3x |

Every ratio clears the 1.6x deadline margin by a wide safety factor, on
every workload including the quiet ones, so the margin is not sitting on a
knife edge against this specific wrong fix.

## Anti cheat check: the deadline measurement cannot be faked from inside

An early version of the timing harness ran the agent's module and the
sealed reference module in the same unprivileged process, using
`time.perf_counter()` calls inside that same process to time both. Any code
that runs before the timing loop starts, including whatever the agent's
module does at import time, can reach `sys.modules["time"]` and replace
`perf_counter` with a function that always returns the same value; the
reference module and the timing loop that comes after import both look up
`time.perf_counter` fresh each call, so they would have used the patched
one too, and the deadline check would have measured nothing.

`malicious_kernel_test.py` (kept alongside this file, not part of the
graded bundle) is a module that patches `time.perf_counter` at import time,
then calls the real reference kernel wrapped in a real half second
`time.sleep`. Run against the current `tests/harness.py`, which spawns the
agent's code and the reference kernel in two separate persistent worker
processes under two different unprivileged accounts and times each with a
clock that lives only in the root parent process, the result was:

```
agent_min_ms = 504.18   reference_min_ms = 1.02   deadline_pass = False
```

The reported agent time matches the real half second sleep almost exactly,
not the zero the patched clock inside that process would have reported to
itself: nothing the submitted module does inside its own process can reach
the number the parent records, because that number is measured across a
process boundary the submitted code never executes inside. The reference
kernel's source is also never copied into any directory the agent's account
can read; it lives only in the reference worker's own private directory,
owned by a second unprivileged account the agent's account has no
permission to enter.

## Calibration note: measured on a laptop GPU, not the grading H100

All numbers above come from a local NVIDIA GeForce GTX 1650 Ti (Max-Q,
30 W power cap), the only GPU available while authoring this task, reached
through the `nvidia-cuda-nvrtc-cu12` pip wheel rather than a full CUDA
Docker image (see `Local validation without Docker available` in the task
skill and the note in `README.md`). Absolute kernel times are not portable
across GPU generations, which is why the deadline check compares the
agent's measured time against a reference measured on the same grading
machine in the same run, not against a fixed constant. The 1.6x margin
itself is a number chosen from the ratios in the timing table above,
measured on this one weak, power capped mobile GPU; the pipeline's own
reference verification stage reruns the oracle on the real H100 before a
task goes further, and if that stage shows the oracle running closer to the
margin than it does here, `DEADLINE_MARGIN` in `tests/harness.py` should be
adjusted from those numbers, not these ones.

## Reproducing this

```
python authoring/provenance/build_datasets.py   # regenerate environment/data and tests/hidden
python authoring/evidence/evaluate.py           # rescore reference, starter, and both variants
```

Both require a real GPU. On Linux with a matching CUDA driver this should
run cupy directly; on Windows, cupy's `RawKernel` needs NVRTC importable and
that DLL is not part of the driver install; installing the standalone wheel
(`pip install nvidia-cuda-nvrtc-cu12==12.4.127`) and adding its `bin`
directory via `os.add_dll_directory` before importing `cupy` was enough on
this machine.
