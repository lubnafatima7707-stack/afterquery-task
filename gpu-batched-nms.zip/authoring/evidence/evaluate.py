"""Rescores the buggy starter and the fixed reference against every dev
and hidden workload, and times both. Run with the DLL directory fix on
Windows dev machines; on Linux with a normal cupy install this just works.
"""
import glob
import importlib.util
import os
import sys
import time

import numpy as np

if os.name == "nt" and hasattr(os, "add_dll_directory"):
    for p in sys.path:
        cand = os.path.join(p, "nvidia", "cuda_nvrtc", "bin")
        if os.path.isdir(cand):
            os.add_dll_directory(cand)

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "authoring", "provenance"))
import geometry  # noqa: E402


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def score_workload(fn, path):
    data = np.load(path)
    boxes, scores = data["boxes"], data["scores"]
    iou_t, score_t = float(data["iou_threshold"]), float(data["score_threshold"])
    gt = data["gt_keep"]
    nvalid = (scores >= score_t).sum(axis=1)

    pred = np.asarray(fn(boxes, scores, iou_t, score_t), dtype=bool)
    ok = True
    for b in range(pred.shape[0]):
        nv = int(nvalid[b])
        if not np.array_equal(pred[b, :nv], gt[b, :nv]):
            ok = False

    # warmup + timed min of 5
    fn(boxes, scores, iou_t, score_t)
    times = []
    for _ in range(5):
        t0 = time.perf_counter()
        fn(boxes, scores, iou_t, score_t)
        times.append((time.perf_counter() - t0) * 1000.0)
    return ok, min(times)


def main():
    variants = {
        "starter (buggy, MAXV=6)": os.path.join(ROOT, "environment", "nms_kernel.py"),
        "reference (fixed, MAXV=8)": os.path.join(ROOT, "solution", "nms_kernel.py"),
    }
    variant_dir = os.path.join(ROOT, "authoring", "evidence", "variants")
    for fn_path in sorted(glob.glob(os.path.join(variant_dir, "*.py"))):
        variants[os.path.splitext(os.path.basename(fn_path))[0]] = fn_path

    dev_files = sorted(glob.glob(os.path.join(ROOT, "environment", "data", "*.npz")))
    hidden_files = sorted(glob.glob(os.path.join(ROOT, "tests", "hidden", "*.npz")))
    all_files = dev_files + hidden_files

    lines = ["| variant | workload | accuracy | min ms |", "|---|---|---|---|"]
    for vname, vpath in variants.items():
        mod = load_module(vpath, f"mod_{abs(hash(vpath))}")
        fn = getattr(mod, "batched_nms")
        for wf in all_files:
            ok, ms = score_workload(fn, wf)
            lines.append(f"| {vname} | {os.path.basename(wf)} | {'PASS' if ok else 'FAIL'} | {ms:.2f} |")
            print(vname, os.path.basename(wf), "PASS" if ok else "FAIL", f"{ms:.2f} ms")

    with open(os.path.join(ROOT, "authoring", "evidence", "results.md"), "w", newline="\n") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
