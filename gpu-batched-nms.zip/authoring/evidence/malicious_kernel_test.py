"""Not part of the graded bundle. A stand in for a submission that tries to
fake the deadline check by patching time.perf_counter at import time, kept
here as evidence that tests/harness.py's dual worker, externally timed
design is not fooled by it. See "Anti cheat check" in cheat_attempts.md for
the result of running this against the real harness.

On Linux, with a GPU and cupy available, run this from the repo root:

    python -c "
import sys, glob
sys.path.insert(0, 'tests')
import harness
harness.AGENT_MODULE = 'authoring/evidence/malicious_kernel_test.py'
wf = sorted(glob.glob('tests/hidden/*.npz'))[0]
print(harness._grade_workload(wf))
"

A real grading run never gives the agent's file this name or lets it name
its own module path; this only swaps in for AGENT_MODULE here so the same
harness code that grades /app/nms_kernel.py can be pointed at it directly.
"""
import os
import time
import importlib.util

_orig_perf_counter = time.perf_counter
time.perf_counter = lambda: 0.0  # nothing in this process can trust its own clock now

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_SOLUTION_PATH = os.path.join(_ROOT, "solution", "nms_kernel.py")
_spec = importlib.util.spec_from_file_location("_real_solution", _SOLUTION_PATH)
_real = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_real)


def batched_nms(boxes, scores, iou_threshold, score_threshold):
    time.sleep(0.5)  # real, wall clock cost this submission cannot hide
    return _real.batched_nms(boxes, scores, iou_threshold, score_threshold)
