| variant | workload | accuracy | min ms |
|---|---|---|---|
| starter (buggy, MAXV=6) | dev_busy.npz | FAIL | 0.78 |
| starter (buggy, MAXV=6) | dev_quiet.npz | PASS | 0.55 |
| starter (buggy, MAXV=6) | h1_quiet.npz | PASS | 0.68 |
| starter (buggy, MAXV=6) | h2_quiet.npz | PASS | 0.57 |
| starter (buggy, MAXV=6) | h3_busy.npz | FAIL | 0.87 |
| starter (buggy, MAXV=6) | h4_busy.npz | FAIL | 0.86 |
| starter (buggy, MAXV=6) | h5_busy.npz | FAIL | 1.02 |
| starter (buggy, MAXV=6) | h6_busy.npz | FAIL | 1.31 |
| reference (fixed, MAXV=8) | dev_busy.npz | PASS | 0.65 |
| reference (fixed, MAXV=8) | dev_quiet.npz | PASS | 0.76 |
| reference (fixed, MAXV=8) | h1_quiet.npz | PASS | 0.62 |
| reference (fixed, MAXV=8) | h2_quiet.npz | PASS | 0.52 |
| reference (fixed, MAXV=8) | h3_busy.npz | PASS | 0.69 |
| reference (fixed, MAXV=8) | h4_busy.npz | PASS | 0.69 |
| reference (fixed, MAXV=8) | h5_busy.npz | PASS | 0.72 |
| reference (fixed, MAXV=8) | h6_busy.npz | PASS | 1.08 |
| partial_fix_maxv7 | dev_busy.npz | PASS | 0.65 |
| partial_fix_maxv7 | dev_quiet.npz | PASS | 0.52 |
| partial_fix_maxv7 | h1_quiet.npz | PASS | 0.67 |
| partial_fix_maxv7 | h2_quiet.npz | PASS | 0.55 |
| partial_fix_maxv7 | h3_busy.npz | FAIL | 0.75 |
| partial_fix_maxv7 | h4_busy.npz | FAIL | 0.72 |
| partial_fix_maxv7 | h5_busy.npz | FAIL | 0.77 |
| partial_fix_maxv7 | h6_busy.npz | FAIL | 1.14 |
| slow_safe_serial | dev_busy.npz | PASS | 4.82 |
| slow_safe_serial | dev_quiet.npz | PASS | 1.23 |
| slow_safe_serial | h1_quiet.npz | PASS | 1.82 |
| slow_safe_serial | h2_quiet.npz | PASS | 2.41 |
| slow_safe_serial | h3_busy.npz | PASS | 3.25 |
| slow_safe_serial | h4_busy.npz | PASS | 9.01 |
| slow_safe_serial | h5_busy.npz | PASS | 12.28 |
| slow_safe_serial | h6_busy.npz | PASS | 4.91 |
