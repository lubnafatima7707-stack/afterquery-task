"""Builds the two dev workloads and the six sealed hidden workloads from
generate_scenes.py. Run from this directory: python build_datasets.py
Regenerating with the same seeds reproduces every committed .npz byte for
byte (checked separately, since npz timestamps do not round trip; compare
array contents).
"""
import os

import numpy as np

import generate_scenes as gs

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DEV_DIR = os.path.join(ROOT, "environment", "data")
HIDDEN_DIR = os.path.join(ROOT, "tests", "hidden")


def _save(path, boxes, scores, gt_keep):
    np.savez(path, boxes=boxes, scores=scores, gt_keep=gt_keep,
              iou_threshold=np.float64(gs.IOU_THRESHOLD),
              score_threshold=np.float64(gs.SCORE_THRESHOLD))
    print(f"wrote {path}: boxes {boxes.shape}")


def main():
    os.makedirs(DEV_DIR, exist_ok=True)
    os.makedirs(HIDDEN_DIR, exist_ok=True)

    # dev_quiet: no rotation jitter inside clusters, so no pair ever needs
    # more than four clip vertices.
    boxes, scores, gt = gs.generate_batch(
        seed=1001, batch_size=6, n_clusters=5, cluster_size_range=(2, 3),
        n_singletons=10, cluster_dtheta_deg=0.0, npad=40)
    _save(os.path.join(DEV_DIR, "dev_quiet.npz"), boxes, scores, gt)

    # dev_busy: realistic heading jitter inside clusters, which routinely
    # needs seven or eight clip vertices.
    boxes, scores, gt = gs.generate_batch(
        seed=1002, batch_size=6, n_clusters=12, cluster_size_range=(3, 5),
        n_singletons=10, cluster_dtheta_deg=15.0, npad=90)
    _save(os.path.join(DEV_DIR, "dev_busy.npz"), boxes, scores, gt)

    hidden_specs = [
        ("h1_quiet.npz", dict(seed=2001, batch_size=8, n_clusters=6, cluster_size_range=(2, 3),
                               n_singletons=14, cluster_dtheta_deg=0.0, npad=45)),
        ("h2_quiet.npz", dict(seed=2002, batch_size=4, n_clusters=3, cluster_size_range=(2, 4),
                               n_singletons=30, cluster_dtheta_deg=0.0, npad=60)),
        ("h3_busy.npz", dict(seed=2003, batch_size=8, n_clusters=10, cluster_size_range=(3, 4),
                              n_singletons=12, cluster_dtheta_deg=6.0, npad=80)),
        ("h4_busy.npz", dict(seed=2004, batch_size=6, n_clusters=16, cluster_size_range=(3, 6),
                              n_singletons=8, cluster_dtheta_deg=12.0, npad=130)),
        ("h5_busy.npz", dict(seed=2005, batch_size=4, n_clusters=24, cluster_size_range=(4, 6),
                              n_singletons=10, cluster_dtheta_deg=20.0, npad=180)),
        ("h6_busy.npz", dict(seed=2006, batch_size=10, n_clusters=14, cluster_size_range=(3, 5),
                              n_singletons=16, cluster_dtheta_deg=15.0, npad=110)),
    ]
    for name, kwargs in hidden_specs:
        boxes, scores, gt = gs.generate_batch(**kwargs)
        _save(os.path.join(HIDDEN_DIR, name), boxes, scores, gt)


if __name__ == "__main__":
    main()
