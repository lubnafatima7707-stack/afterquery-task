"""Synthetic rotated detection scene generator for batched NMS stress
testing.

Each image is built from clusters (multiple near duplicate rotated
proposals around one true object, each proposal jittered a little in
position and, most importantly, in heading) and singletons (isolated
boxes, well separated from everything else). A fixed margin around the
IoU threshold is enforced on every pair using the independent geometry in
geometry.py, so grading never depends on a floating point boundary call.
Ground truth comes from running the same module's plain greedy NMS over
the finished image, not from a shortcut label.

Regenerating from a seed reproduces the committed data exactly.
"""
import numpy as np

import geometry

IOU_THRESHOLD = 0.5
SCORE_THRESHOLD = 0.3
MARGIN = 0.12  # keep every pair's true IoU at least this far from IOU_THRESHOLD
SCENE_SIZE = 2000.0
BASE_SIZE_RANGE = (30.0, 90.0)


def _far_enough(box, placed):
    for p in placed:
        if geometry.rotated_iou(box, p) > IOU_THRESHOLD - MARGIN:
            return False
    return True


def _make_cluster(rng, center, base_w, base_h, base_theta, n_proposals, top_score, dtheta_deg):
    boxes, scores = [], []
    dtheta_rad = dtheta_deg * np.pi / 180.0
    for k in range(n_proposals):
        scale = 1.0 + rng.uniform(-0.05, 0.05)
        dx = rng.uniform(-0.03, 0.03) * base_w
        dy = rng.uniform(-0.03, 0.03) * base_h
        dtheta = rng.uniform(-dtheta_rad, dtheta_rad) if dtheta_rad > 0 else 0.0
        cx, cy = center[0] + dx, center[1] + dy
        box = (cx, cy, base_w * scale, base_h * scale, base_theta + dtheta)
        boxes.append(box)
        scores.append(top_score - 0.02 * k - rng.uniform(0, 0.01))
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            v = geometry.rotated_iou(boxes[i], boxes[j])
            if v <= IOU_THRESHOLD + MARGIN:
                return None, None
    return boxes, scores


def generate_image(rng, n_clusters, cluster_size_range, n_singletons, cluster_dtheta_deg,
                    scene_size=SCENE_SIZE, base_size_range=BASE_SIZE_RANGE):
    boxes, scores = [], []
    attempts = 0
    max_attempts = (n_clusters + n_singletons) * 80
    placed_clusters = 0
    placed_singletons = 0
    while (placed_clusters < n_clusters or placed_singletons < n_singletons) and attempts < max_attempts:
        attempts += 1
        want_cluster = placed_clusters < n_clusters and (
            placed_singletons >= n_singletons or rng.random() < 0.6)
        base_w = rng.uniform(*base_size_range)
        base_h = rng.uniform(*base_size_range)
        margin_px = max(base_w, base_h) * 1.6
        center = (rng.uniform(margin_px, scene_size - margin_px),
                  rng.uniform(margin_px, scene_size - margin_px))
        base_theta = rng.uniform(0, np.pi)
        top_score = rng.uniform(0.55, 0.95)

        if want_cluster:
            k = int(rng.integers(cluster_size_range[0], cluster_size_range[1] + 1))
            cbox, cscore = _make_cluster(rng, center, base_w, base_h, base_theta, k,
                                          top_score, cluster_dtheta_deg)
            if cbox is None:
                continue
            if not all(_far_enough(b, boxes) for b in cbox):
                continue
            boxes.extend(cbox)
            scores.extend(cscore)
            placed_clusters += 1
        else:
            box = (center[0], center[1], base_w, base_h, base_theta)
            if not _far_enough(box, boxes):
                continue
            boxes.append(box)
            scores.append(top_score)
            placed_singletons += 1

    boxes = np.array(boxes, dtype=np.float32)
    scores = np.array(scores, dtype=np.float32)
    keep = geometry.greedy_nms_image(boxes, scores, IOU_THRESHOLD, SCORE_THRESHOLD)
    return boxes, scores, keep


def generate_batch(seed, batch_size, n_clusters, cluster_size_range, n_singletons,
                    cluster_dtheta_deg, npad=None):
    rng = np.random.default_rng(seed)
    images = [generate_image(rng, n_clusters, cluster_size_range, n_singletons, cluster_dtheta_deg)
              for _ in range(batch_size)]
    n = npad if npad is not None else max(len(ib) for ib, _, _ in images)
    boxes = np.zeros((batch_size, n, 5), dtype=np.float32)
    scores = np.full((batch_size, n), -1.0, dtype=np.float32)
    gt_keep = np.zeros((batch_size, n), dtype=bool)
    for b, (ib, isc, ik) in enumerate(images):
        m = min(len(ib), n)
        boxes[b, :m] = ib[:m]
        scores[b, :m] = isc[:m]
        gt_keep[b, :m] = ik[:m]
    return boxes, scores, gt_keep
