"""Pure numpy rotated box geometry, written independently of the CUDA
kernels in environment/ and solution/: no fixed size scratch buffer, no
early cutoff on vertex count, used only to build ground truth and to check
the margin the generator promises around the IoU threshold."""
import numpy as np


def corners(cx, cy, w, h, theta):
    lx = np.array([-w/2, w/2, w/2, -w/2])
    ly = np.array([-h/2, -h/2, h/2, h/2])
    c, s = np.cos(theta), np.sin(theta)
    x = cx + lx*c - ly*s
    y = cy + lx*s + ly*c
    return list(zip(x.tolist(), y.tolist()))


def _cross(o, a, b):
    return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])


def _isect(a, b, p, q):
    x1, y1 = a; x2, y2 = b; x3, y3 = p; x4, y4 = q
    d = (x1-x2)*(y3-y4) - (y1-y2)*(x3-x4)
    if abs(d) < 1e-12:
        return p
    t = ((x1-x3)*(y3-y4) - (y1-y3)*(x3-x4)) / d
    return (x1 + t*(x2-x1), y1 + t*(y2-y1))


def clip_polygon(subject, clip):
    """Sutherland Hodgman: clip a convex subject polygon by a convex clip
    polygon given in counter clockwise order. No cap on output size."""
    output = subject
    cn = len(clip)
    for k in range(cn):
        if not output:
            break
        a, b = clip[k], clip[(k+1) % cn]
        inp = output
        output = []
        n = len(inp)
        for i in range(n):
            p, q = inp[i], inp[(i+1) % n]
            cp1 = _cross(a, b, p)
            cp2 = _cross(a, b, q)
            if cp1 >= 0:
                output.append(p)
                if cp2 < 0:
                    output.append(_isect(a, b, p, q))
            elif cp2 >= 0:
                output.append(_isect(a, b, p, q))
    return output


def polygon_area(poly):
    if len(poly) < 3:
        return 0.0
    s = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i+1) % n]
        s += x1*y2 - x2*y1
    return abs(s) * 0.5


def rotated_iou(box_a, box_b):
    """box_a, box_b: (cx, cy, w, h, theta)."""
    a = corners(*box_a)
    b = corners(*box_b)
    inter = polygon_area(clip_polygon(a, b))
    area_a = box_a[2] * box_a[3]
    area_b = box_b[2] * box_b[3]
    return inter / (area_a + area_b - inter + 1e-9)


def greedy_nms_image(boxes, scores, iou_threshold, score_threshold):
    """boxes: [N, 5] (cx, cy, w, h, theta). scores: [N]. Returns bool [N]."""
    n = len(scores)
    keep = np.zeros(n, dtype=bool)
    valid = np.where(scores >= score_threshold)[0]
    order = valid[np.argsort(-scores[valid], kind="stable")]
    suppressed = np.zeros(len(order), dtype=bool)
    for a in range(len(order)):
        if suppressed[a]:
            continue
        ia = order[a]
        keep[ia] = True
        for c in range(a+1, len(order)):
            if suppressed[c]:
                continue
            jc = order[c]
            if rotated_iou(boxes[ia], boxes[jc]) > iou_threshold:
                suppressed[c] = True
    return keep


def greedy_nms_batch(boxes, scores, iou_threshold, score_threshold):
    B = boxes.shape[0]
    out = np.zeros((B, boxes.shape[1]), dtype=bool)
    for b in range(B):
        out[b] = greedy_nms_image(boxes[b], scores[b], iou_threshold, score_threshold)
    return out
