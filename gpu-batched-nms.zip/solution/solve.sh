#!/bin/bash
set -euo pipefail
cp "$(dirname "$0")/nms_kernel.py" /app/nms_kernel.py
