"""
Sealed reference implementation, used by the verifier only, to compute a
live timing baseline on whatever hardware the grading run lands on: kernel
time is not portable across GPU generations, so the deadline check compares
the agent's own measured time against this, not a fixed constant. Identical
kernel to solution/nms_kernel.py; ground truth for the accuracy check comes
from tests/hidden, never from running this module.

Batched greedy non max suppression on the GPU, for oriented (rotated)
detection boxes.

Each box is (cx, cy, w, h, theta), theta in radians, the box being an
axis aligned w by h rectangle rotated counter clockwise by theta about its
own center. Overlap between two such boxes is not a simple rectangle
intersection: it is computed by clipping one box's quadrilateral against
the other with the Sutherland Hodgman algorithm and taking the area of
whatever convex polygon comes out.

Clipping a quadrilateral against a second quadrilateral can add at most
one new vertex per edge of the clip polygon, so the result can have as
many as four plus four, eight, vertices; a scratch buffer sized for a
hexagon drops the extra one or two vertices on exactly the pairs where the
true overlap is largest, which understates the intersection area and lets
a near duplicate box survive that should have been suppressed. The scratch
buffer here is sized for the true worst case.

The clipping step for one pair of boxes runs independently of every other
pair, which is what makes it worth putting on the GPU: a batch of busy
scenes can have hundreds of candidates per image, and every pair needs its
own polygon clip. One CUDA thread handles one candidate pair (i, j) with
i before j in score order; the kernel writes a byte per pair saying whether
box i's overlap with box j clears the IoU threshold. The greedy walk that
turns those pairwise bytes into a keep or suppress decision per box is
inherently sequential (box j can only be judged once every higher scoring
box has already been resolved), so that part runs on the host once the
pairwise bytes are back from the device.
"""
import os

import numpy as np
import cupy as cp

_KERNEL_SRC = r"""
extern "C" __global__
void pairwise_suppress_kernel(const float* boxes,
                               const int* n_valid,
                               int npad,
                               float iou_thresh,
                               unsigned char* cand)
{
    int b = blockIdx.z;
    int i = blockIdx.y * blockDim.y + threadIdx.y;
    int j = blockIdx.x * blockDim.x + threadIdx.x;
    int nv = n_valid[b];
    if (i >= nv || j >= nv || j <= i) return;

    const float* bx = boxes + (size_t)b * npad * 5;
    float icx = bx[i*5+0], icy = bx[i*5+1], iw = bx[i*5+2], ih = bx[i*5+3], ith = bx[i*5+4];
    float jcx = bx[j*5+0], jcy = bx[j*5+1], jw = bx[j*5+2], jh = bx[j*5+3], jth = bx[j*5+4];

    float pax[4], pay[4], pbx[4], pby[4];
    {
        float lx[4] = {-iw/2, iw/2, iw/2, -iw/2};
        float ly[4] = {-ih/2, -ih/2, ih/2, ih/2};
        float c = cosf(ith), s = sinf(ith);
        for (int k = 0; k < 4; k++) {
            pax[k] = icx + lx[k]*c - ly[k]*s;
            pay[k] = icy + lx[k]*s + ly[k]*c;
        }
    }
    {
        float lx[4] = {-jw/2, jw/2, jw/2, -jw/2};
        float ly[4] = {-jh/2, -jh/2, jh/2, jh/2};
        float c = cosf(jth), s = sinf(jth);
        for (int k = 0; k < 4; k++) {
            pbx[k] = jcx + lx[k]*c - ly[k]*s;
            pby[k] = jcy + lx[k]*s + ly[k]*c;
        }
    }

    // Sutherland-Hodgman: clip quadrilateral A by convex quadrilateral B.
    // Two quadrilaterals can intersect in up to eight vertices (one extra
    // vertex per edge of the clip polygon), so the scratch buffer has to
    // hold eight, not a number that only covers the near axis aligned case.
    const int MAXV = 8;
    float outx[MAXV], outy[MAXV];
    int outn = 4;
    for (int k = 0; k < 4; k++) { outx[k] = pax[k]; outy[k] = pay[k]; }

    for (int e = 0; e < 4 && outn > 0; e++) {
        float ax = pbx[e], ay = pby[e];
        float bxp = pbx[(e+1)%4], byp = pby[(e+1)%4];
        float inx[MAXV], iny[MAXV];
        int inn = outn;
        for (int k = 0; k < inn; k++) { inx[k] = outx[k]; iny[k] = outy[k]; }
        outn = 0;
        for (int k = 0; k < inn; k++) {
            float px = inx[k], py = iny[k];
            float qx = inx[(k+1)%inn], qy = iny[(k+1)%inn];
            float cp1 = (bxp-ax)*(py-ay) - (byp-ay)*(px-ax);
            float cp2 = (bxp-ax)*(qy-ay) - (byp-ay)*(qx-ax);
            if (cp1 >= 0.0f) {
                if (outn < MAXV) { outx[outn] = px; outy[outn] = py; outn++; }
                if (cp2 < 0.0f) {
                    float d = (ax-bxp)*(py-qy) - (ay-byp)*(px-qx);
                    if (fabsf(d) > 1e-12f) {
                        float t = ((ax-px)*(py-qy) - (ay-py)*(px-qx)) / d;
                        if (outn < MAXV) { outx[outn] = ax + t*(bxp-ax); outy[outn] = ay + t*(byp-ay); outn++; }
                    }
                }
            } else if (cp2 >= 0.0f) {
                float d = (ax-bxp)*(py-qy) - (ay-byp)*(px-qx);
                if (fabsf(d) > 1e-12f) {
                    float t = ((ax-px)*(py-qy) - (ay-py)*(px-qx)) / d;
                    if (outn < MAXV) { outx[outn] = ax + t*(bxp-ax); outy[outn] = ay + t*(byp-ay); outn++; }
                }
            }
        }
    }

    float inter = 0.0f;
    if (outn >= 3) {
        float s = 0.0f;
        for (int k = 0; k < outn; k++) {
            int k2 = (k+1) % outn;
            s += outx[k]*outy[k2] - outx[k2]*outy[k];
        }
        inter = fabsf(s) * 0.5f;
    }

    float area_a = iw * ih;
    float area_b = jw * jh;
    float iou = inter / (area_a + area_b - inter + 1e-9f);

    cand[(size_t)b*npad*npad + (size_t)i*npad + j] = (iou > iou_thresh) ? 1 : 0;
}
"""

_kernel = None


def _nvrtc_include_opts():
    # cupy's pip wheel install does not bundle complete CUDA 12.2+ headers
    # and has no automatic discovery for the sibling nvidia-cuda-runtime-cu12
    # wheel the way a conda install does (cupy/cupy#8466); point nvrtc at
    # its include directory directly. Falls back to no extra flag if that
    # package is not present, in case the runtime already resolves headers
    # some other way (a conda based cupy install, for one).
    try:
        import nvidia.cuda_runtime
        include_dir = os.path.join(os.path.dirname(nvidia.cuda_runtime.__file__), "include")
        return (f"-I{include_dir}",)
    except ImportError:
        return ()


def _get_kernel():
    global _kernel
    if _kernel is None:
        _kernel = cp.RawKernel(_KERNEL_SRC, "pairwise_suppress_kernel", options=_nvrtc_include_opts())
    return _kernel


def reference_batched_nms(boxes, scores, iou_threshold, score_threshold):
    """
    boxes: np.ndarray, shape [B, N, 5] float32, rows are (cx, cy, w, h, theta)
           with theta in radians
    scores: np.ndarray, shape [B, N] float32
    iou_threshold: float
    score_threshold: float, candidates scoring below this are ignored

    returns: np.ndarray, shape [B, N] bool, True where the box is kept
    """
    boxes = np.asarray(boxes, dtype=np.float32)
    scores = np.asarray(scores, dtype=np.float32)
    B, N, _ = boxes.shape
    npad = N
    keep_out = np.zeros((B, N), dtype=bool)

    orders = []
    n_valid_list = []
    padded = np.zeros((B, npad, 5), dtype=np.float32)
    for b in range(B):
        valid_idx = np.where(scores[b] >= score_threshold)[0]
        order = valid_idx[np.argsort(-scores[b][valid_idx], kind="stable")]
        nv = len(order)
        orders.append(order)
        n_valid_list.append(nv)
        if nv:
            padded[b, :nv] = boxes[b][order]

    d_boxes = cp.asarray(padded)
    d_nvalid = cp.asarray(np.array(n_valid_list, dtype=np.int32))
    d_cand = cp.zeros((B, npad, npad), dtype=cp.uint8)

    if npad > 0:
        kernel = _get_kernel()
        block = (16, 16, 1)
        grid = ((npad + 15)//16, (npad + 15)//16, B)
        kernel(grid, block, (d_boxes, d_nvalid, np.int32(npad), np.float32(iou_threshold), d_cand))

    cand_host = cp.asnumpy(d_cand)
    for b in range(B):
        nv = n_valid_list[b]
        if nv == 0:
            continue
        suppressed = np.zeros(nv, dtype=bool)
        kept_local = np.zeros(nv, dtype=bool)
        cb = cand_host[b, :nv, :nv]
        for i in range(nv):
            if suppressed[i]:
                continue
            kept_local[i] = True
            if i + 1 < nv:
                suppressed[i+1:] |= cb[i, i+1:].astype(bool)
        keep_out[b, orders[b][kept_local]] = True

    return keep_out
