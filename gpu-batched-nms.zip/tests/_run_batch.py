"""Runs repeated accuracy calls to one kernel implementation inside a
single process, so CUDA context setup and kernel compilation are paid once,
the same way any real caller would amortize them, rather than once per
call.

The harness still isolates this whole process with a wall clock timeout and
kills its process group if it hangs, so hostile or broken submitted code
cannot block the verifier; it just cannot corrupt the timing measurement by
forcing a cold start on every repeat. This module only ever times itself
for the caller's information; the deadline check does not use this file at
all, see _timing_worker.py for that.

argv: module_path function_name workload_npz_path repeats out_path
  runs `repeats` calls, saves every keep mask
"""
import importlib.util
import sys

import numpy as np


def _load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _load_workload(path):
    data = np.load(path)
    return data["boxes"], data["scores"], float(data["iou_threshold"]), float(data["score_threshold"])


def main():
    module_path, fn_name, workload_path, repeats, out_path = sys.argv[1:6]
    repeats = int(repeats)
    mod = _load_module(module_path, "submitted_kernel")
    fn = getattr(mod, fn_name)
    boxes, scores, iou_threshold, score_threshold = _load_workload(workload_path)

    keeps = []
    for _ in range(repeats):
        keep = np.asarray(fn(boxes, scores, iou_threshold, score_threshold), dtype=bool)
        keeps.append(keep)
    np.savez(out_path, keeps=np.stack(keeps, axis=0))


if __name__ == "__main__":
    main()
