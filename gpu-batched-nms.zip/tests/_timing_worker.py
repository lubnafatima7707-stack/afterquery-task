"""Persistent single kernel timing worker. Loads exactly one implementation
(the agent's or the sealed reference, never both in the same process) and
then answers a line based RUN protocol on stdin/stdout: each RUN call makes
one call to the loaded function and replies once it returns, so cupy's
context setup and kernel compile happen once and every later call inside
this process is warm, the way a real caller would run it.

This worker never measures or reports its own elapsed time. The trusted
parent (tests/harness.py, running as root, never importing either kernel
itself) times each call from the outside by taking its own timestamp right
before writing RUN and right after the reply line comes back. A process
cannot patch a clock that lives in a different process's address space, so
nothing this worker imports, including whatever /app/nms_kernel.py does at
import time, can touch the number the parent records. Interleaving agent
calls and reference calls is done by the parent alternating which of two
such workers it messages, which keeps the same real time cancellation the
single process design used to rely on without ever letting the two
implementations, or their processes, see each other.
"""
import importlib.util
import sys

import numpy as np


def _load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    module_path, fn_name, workload_path = sys.argv[1], sys.argv[2], sys.argv[3]
    mod = _load_module(module_path, "worker_kernel")
    fn = getattr(mod, fn_name)

    data = np.load(workload_path)
    boxes, scores = data["boxes"], data["scores"]
    iou_threshold = float(data["iou_threshold"])
    score_threshold = float(data["score_threshold"])

    sys.stdout.write("READY\n")
    sys.stdout.flush()

    for line in sys.stdin:
        cmd = line.strip()
        if cmd == "RUN":
            try:
                keep = np.asarray(fn(boxes, scores, iou_threshold, score_threshold), dtype=bool)
                sys.stdout.write(f"OK {int(keep.sum())}\n")
            except Exception as e:  # noqa: BLE001 - reported to parent, not swallowed
                sys.stdout.write(f"ERR {type(e).__name__}: {e}\n")
            sys.stdout.flush()
        elif cmd == "QUIT":
            break
        else:
            sys.stdout.write(f"ERR unknown command {cmd!r}\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
