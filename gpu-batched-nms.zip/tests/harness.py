"""Grades /app/nms_kernel.py against every sealed hidden workload.

Each workload must pass two independent checks:
  accuracy: the exact keep mask, on every image, matches ground truth, on
            every one of ACCURACY_REPEATS independent calls (a kernel that
            still races will not pass every repeat even if it wins some)
  deadline: the fastest of TIMING_REPEATS timed calls is at most MARGIN times
            the fastest timing of the sealed reference kernel. Both are
            timed in the same real time window, alternating agent and
            reference calls, because two separate timing runs launched back
            to back are not a fair comparison on a busy shared machine:
            whichever one happens to land during a load spike looks
            arbitrarily slower than the other, which produced a spurious
            1.5-2x split between two runs of the identical kernel during
            authoring. The minimum, not the mean or median, isolates true
            kernel cost from one sided scheduling noise, which only ever
            adds delay, never removes it.

Unlike the accuracy check, the deadline check never lets the agent's code
and the reference kernel's code run inside the same process, or even the
same unprivileged account. Each side gets its own persistent worker
process, started as its own unprivileged user in its own private
directory holding only that side's module and a scrubbed copy of the
workload; the reference kernel's source is never copied anywhere the
agent's account can read. Elapsed time is measured entirely by this
module, running as root, which imports neither kernel and never lets
either worker report its own timing: this process's own clock is the
only one whose reading anything the agent submits could ever be in a
position to touch. A single worker process handling every timed repeat
still pays CUDA context setup and kernel compilation exactly once, the
same amortization a persistent design always intended, without the
agent's import time code ever sharing an address space, a Python `time`
module, or a compiled kernel handle with the reference implementation.

This module runs as root (test.sh only elevates permissions here). It is
the only thing that ever opens a file under hidden/, and it strips ground
truth out before anything reaches the submitted kernel: every child process
that ever imports /app/nms_kernel.py runs as the unprivileged `runner`
user, in its own session, on a scrubbed copy holding only boxes, scores and
the two thresholds, in a private directory that user owns. The reference
kernel runs under a second unprivileged account, `refrunner`, whose private
directory `runner` has no permission to enter. The parent kills the whole
process group of anything it starts on a timeout or any other failure, so a
hang or a fork bomb in submitted code cannot block grading or outlive the
call.
"""
import glob
import os
import pwd
import select
import shutil
import signal
import subprocess
import sys
import tempfile
import time

import numpy as np

import scoring

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
HIDDEN_DIR = os.path.join(TESTS_DIR, "hidden")
REFERENCE_MODULE = os.path.join(TESTS_DIR, "_reference_kernel.py")
RUN_BATCH_SCRIPT = os.path.join(TESTS_DIR, "_run_batch.py")
TIMING_WORKER_SCRIPT = os.path.join(TESTS_DIR, "_timing_worker.py")
AGENT_MODULE = "/app/nms_kernel.py"
AGENT_RUN_USER = "runner"
REFERENCE_RUN_USER = "refrunner"

ACCURACY_REPEATS = 7
TIMING_REPEATS = 9
DEADLINE_MARGIN = 1.6
PER_PROCESS_TIMEOUT_SEC = 60
WORKER_READY_TIMEOUT_SEC = 60
WORKER_CALL_TIMEOUT_SEC = 60


def _scrub_workload(workload_path, dst_path):
    """Writes an inputs-only copy (no gt_keep) that the unprivileged child
    is allowed to read."""
    data = np.load(workload_path)
    np.savez(dst_path, boxes=data["boxes"], scores=data["scores"],
              iou_threshold=data["iou_threshold"], score_threshold=data["score_threshold"])


def _prepare_work_dir(run_user, module_path, workload_path):
    """Builds a private directory for one unprivileged account holding only
    that account's own copy of one kernel module and a scrubbed workload;
    nothing else ever gets chowned to that account, so it never gains read
    access to any other account's directory even if it discovers the path."""
    work = tempfile.mkdtemp(prefix="nms_run_")
    scrubbed_workload = os.path.join(work, "workload.npz")
    _scrub_workload(workload_path, scrubbed_workload)
    module_copy = os.path.join(work, "kernel_module.py")
    shutil.copyfile(module_path, module_copy)

    chown_targets = [work, scrubbed_workload, module_copy]
    kwargs = {}
    if os.geteuid() == 0:
        pw = pwd.getpwnam(run_user)
        for p in chown_targets:
            os.chown(p, pw.pw_uid, pw.pw_gid)
        kwargs["user"] = run_user
        kwargs["group"] = run_user
    os.chmod(work, 0o700)
    return work, module_copy, scrubbed_workload, kwargs


def _run_isolated_accuracy(module_path, fn_name, workload_path, repeats):
    """Single shot subprocess for the accuracy channel: no timing is
    measured here, so there is nothing for the agent's own process to gain
    by tampering with anything in it beyond computing the wrong answer,
    which the exact match check below already catches."""
    work, module_copy, scrubbed_workload, kwargs = _prepare_work_dir(
        AGENT_RUN_USER, module_path, workload_path)
    try:
        out_path = os.path.join(work, "out.npz")
        run_batch_copy = os.path.join(work, "_run_batch.py")
        shutil.copyfile(RUN_BATCH_SCRIPT, run_batch_copy)
        if os.geteuid() == 0:
            pw = pwd.getpwnam(AGENT_RUN_USER)
            os.chown(run_batch_copy, pw.pw_uid, pw.pw_gid)

        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": work,
               "PYTHONDONTWRITEBYTECODE": "1",
               "LD_LIBRARY_PATH": os.environ.get("LD_LIBRARY_PATH", "")}
        cmd = [sys.executable, run_batch_copy, module_copy, fn_name, scrubbed_workload,
               str(repeats), out_path]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 cwd=work, env=env, close_fds=True,
                                 start_new_session=True, **kwargs)
        try:
            stdout, stderr = proc.communicate(timeout=PER_PROCESS_TIMEOUT_SEC)
        except subprocess.TimeoutExpired:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            proc.communicate()
            return None, "timeout"
        finally:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                pass
        if proc.returncode != 0 or not os.path.exists(out_path):
            return None, f"exit_code={proc.returncode} stderr={stderr.decode(errors='replace')[-2000:]}"
        return dict(np.load(out_path)), None
    finally:
        shutil.rmtree(work, ignore_errors=True)


class _TimingWorker:
    """One persistent, single kernel timing process plus the plumbing to
    time it externally without trusting anything it reports about itself."""

    def __init__(self, run_user, module_path, fn_name, workload_path):
        self.work, module_copy, scrubbed_workload, kwargs = _prepare_work_dir(
            run_user, module_path, workload_path)
        worker_copy = os.path.join(self.work, "_timing_worker.py")
        shutil.copyfile(TIMING_WORKER_SCRIPT, worker_copy)
        if os.geteuid() == 0:
            pw = pwd.getpwnam(run_user)
            os.chown(worker_copy, pw.pw_uid, pw.pw_gid)

        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": self.work,
               "PYTHONDONTWRITEBYTECODE": "1",
               "LD_LIBRARY_PATH": os.environ.get("LD_LIBRARY_PATH", "")}
        cmd = [sys.executable, worker_copy, module_copy, fn_name, scrubbed_workload]
        self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                      stderr=subprocess.PIPE, cwd=self.work, env=env,
                                      close_fds=True, start_new_session=True,
                                      text=True, bufsize=1, **kwargs)
        line = self._readline(WORKER_READY_TIMEOUT_SEC)
        if line != "READY":
            self.kill()
            raise RuntimeError(f"worker failed to start: {line!r}, "
                                f"stderr={self._drain_stderr()}")

    def _readline(self, timeout_sec):
        ready, _, _ = select.select([self.proc.stdout], [], [], timeout_sec)
        if not ready:
            return None
        line = self.proc.stdout.readline()
        return line.strip() if line else None

    def _drain_stderr(self):
        try:
            ready, _, _ = select.select([self.proc.stderr], [], [], 0.2)
            if ready:
                return self.proc.stderr.read()
        except Exception:  # noqa: BLE001 - best effort diagnostics only
            pass
        return ""

    def timed_call(self):
        """Sends one RUN command and returns elapsed milliseconds measured
        by this (trusted, root) process's own clock around the full round
        trip. Raises on any failure or timeout; the caller treats that as a
        deadline failure."""
        t0 = time.perf_counter()
        self.proc.stdin.write("RUN\n")
        self.proc.stdin.flush()
        line = self._readline(WORKER_CALL_TIMEOUT_SEC)
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        if line is None:
            raise RuntimeError(f"worker timed out or died, stderr={self._drain_stderr()}")
        if not line.startswith("OK"):
            raise RuntimeError(f"worker call failed: {line}")
        return elapsed_ms

    def kill(self):
        try:
            os.killpg(os.getpgid(self.proc.pid), signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
        try:
            self.proc.wait(timeout=5)
        except Exception:  # noqa: BLE001 - best effort cleanup
            pass
        shutil.rmtree(self.work, ignore_errors=True)


def _run_timing_pair(module_a, fn_a, module_b, fn_b, workload_path, repeats):
    """Alternates timed calls between two independent worker processes
    (agent, then reference, then agent, ...), so both sides answer the same
    question about the same moment on a busy shared machine, without ever
    letting one side's process see the other's code, module, or clock."""
    worker_a = worker_b = None
    try:
        worker_a = _TimingWorker(AGENT_RUN_USER, module_a, fn_a, workload_path)
        worker_b = _TimingWorker(REFERENCE_RUN_USER, module_b, fn_b, workload_path)

        # one warmup call each, discarded, so context setup and kernel
        # compilation on both sides happen before any timed call
        worker_a.timed_call()
        worker_b.timed_call()

        times_a, times_b = [], []
        for _ in range(repeats):
            times_a.append(worker_a.timed_call())
            times_b.append(worker_b.timed_call())
        return {"elapsed_ms_a": np.array(times_a, dtype=np.float64),
                "elapsed_ms_b": np.array(times_b, dtype=np.float64)}, None
    except Exception as e:  # noqa: BLE001 - reported as a graded failure, not raised
        return None, str(e)
    finally:
        if worker_a is not None:
            worker_a.kill()
        if worker_b is not None:
            worker_b.kill()


def _run_accuracy(module_path, fn_name, workload_path, repeats):
    return _run_isolated_accuracy(module_path, fn_name, workload_path, repeats)


def _grade_workload(workload_path):
    data = np.load(workload_path)
    gt_keep = data["gt_keep"]
    scores_arr = data["scores"]
    score_threshold = float(data["score_threshold"])
    nvalid = scoring.n_valid_per_image(scores_arr, score_threshold)

    detail = {"file": os.path.basename(workload_path)}

    acc_result, acc_err = _run_accuracy(AGENT_MODULE, "batched_nms", workload_path, ACCURACY_REPEATS)
    if acc_result is None:
        detail["accuracy_pass"] = False
        detail["accuracy_error"] = acc_err
    else:
        keeps = acc_result["keeps"]  # [R, B, N]
        all_ok = all(scoring.all_images_exact_match(keeps[r], gt_keep, nvalid)
                     for r in range(keeps.shape[0]))
        detail["accuracy_pass"] = bool(all_ok)

    pair_result, pair_err = _run_timing_pair(AGENT_MODULE, "batched_nms",
                                              REFERENCE_MODULE, "reference_batched_nms",
                                              workload_path, TIMING_REPEATS)
    if pair_result is None:
        detail["deadline_pass"] = False
        detail["timing_error"] = pair_err
    else:
        agent_ms = float(np.min(pair_result["elapsed_ms_a"]))
        ref_ms = float(np.min(pair_result["elapsed_ms_b"]))
        detail["agent_min_ms"] = agent_ms
        detail["reference_min_ms"] = ref_ms
        detail["deadline_pass"] = scoring.deadline_ok(agent_ms, ref_ms, DEADLINE_MARGIN)

    detail["workload_pass"] = bool(detail.get("accuracy_pass") and detail.get("deadline_pass"))
    return detail


def _prime_gpu(workload_files):
    """Whichever side runs first against an idle GPU pays a one time clock
    ramp up tax the other side does not. Spend that tax once, on both
    implementations together, before any timed comparison starts."""
    if not workload_files:
        return
    _run_timing_pair(AGENT_MODULE, "batched_nms", REFERENCE_MODULE, "reference_batched_nms",
                      workload_files[0], 1)


def run_all():
    if not os.path.exists(AGENT_MODULE):
        return False, [{"file": "*", "workload_pass": False, "error": "missing /app/nms_kernel.py"}]

    workload_files = sorted(glob.glob(os.path.join(HIDDEN_DIR, "*.npz")))
    _prime_gpu(workload_files)
    reports = [_grade_workload(p) for p in workload_files]
    overall = bool(reports) and all(r["workload_pass"] for r in reports)
    return overall, reports


if __name__ == "__main__":
    passed, reports = run_all()
    for r in reports:
        print(r)
    print("OVERALL PASS:", passed)
