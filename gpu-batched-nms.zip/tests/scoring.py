"""Shared grading logic, imported by both test_verify.py and the authoring
evidence scripts so the evidence is scored by the verifier's own code."""
import numpy as np


def n_valid_per_image(scores, score_threshold):
    return (scores >= score_threshold).sum(axis=1)


def all_images_exact_match(pred_keep, gt_keep, n_valid):
    """pred_keep, gt_keep: [B, N] bool. n_valid: [B] int, only the first
    n_valid[b] entries of image b are graded (the rest is padding)."""
    B = pred_keep.shape[0]
    for b in range(B):
        nv = int(n_valid[b])
        if not np.array_equal(pred_keep[b, :nv], gt_keep[b, :nv]):
            return False
    return True


def deadline_ok(agent_ms, reference_ms, margin):
    return agent_ms <= reference_ms * margin
