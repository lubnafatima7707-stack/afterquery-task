import json
import os

import harness


def test_all_hidden_workloads_pass():
    passed, reports = harness.run_all()
    report_path = "/logs/verifier/grading_detail.json"
    try:
        os.makedirs(os.path.dirname(report_path), exist_ok=True)
        with open(report_path, "w") as f:
            json.dump(reports, f, indent=2, default=str)
    except OSError:
        pass  # best effort; the assertion below is what determines the reward
    assert passed, f"one or more hidden workloads failed: {reports}"
