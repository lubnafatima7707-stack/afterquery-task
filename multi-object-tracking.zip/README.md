# multi-object-tracking

The agent turns the forward radar detections of a car that is driving and turning, whose own motion is not given, into `/app/output/tracks.csv`: sensor frame positions and consistent ids for the moving road users only. The verifier grades MOTA, identity switches and how many objects are mostly tracked.

## Difficulty

All data is synthetic and this is disclosed. `authoring/provenance/generate_scene.py` integrates a car driving 60 s along a winding road (7 to 21 m/s, yaw rates up to 0.15 rad/s), lays 809 static bodies along the route (guardrail posts, curb reflectors, poles, parked cars) and 17 moving road users (5 lead cars, 2 lane changers, 6 oncoming cars, 4 crossing pedestrians), and only then derives detections from a forward radar mounted 3.0 m ahead of the car's turning centre: 0.15 m position noise, 0.1 m/s Doppler noise, detection probability 0.9 falling to 0.15 in two occlusion windows, several detections per vehicle at short range, and Poisson clutter. Ground truth is written from the simulated bodies before any noise, and the generator refuses to write a scene in which two moving objects come within the 3 m scoring gate.

This is the tracking layer an automotive radar perception engineer builds between detection and planning. The car's own motion has to come out of the data before anything else means something, and then several separate judgements all have to hold. Each claimed piece fails the bars when removed from either of two structurally different correct solvers (`authoring/evidence/results.json`):

| Removed piece | Reference MOTA / switches / mostly tracked | Independent MOTA / switches / mostly tracked |
|---|---|---|
| Nothing | 0.7480 / 6 / 1.0000 | 0.7222 / 1 / 0.8824 |
| Ego motion estimate | -14.9066 / 76 / 0.9412 | -17.9710 / 37 / 0.7647 |
| Robust ego fit (plain least squares) | -13.1449 / 102 / 0.4118 | -16.9694 / 105 / 0.1765 |
| Temporal smoothing of the ego estimate | 0.5958 / 4 / 0.8824 | 0.6425 / 6 / 0.8824 |
| Grouping of one vehicle's detections | 0.5982 / 46 / 1.0000 | -0.1079 / 9 / 0.8235 |
| Separate grouping radius for movers and static | -0.4863 / 8 / 0.7647 | 0.4380 / 5 / 0.7059 |
| Displacement channel (Doppler only) | 0.7641 / 5 / 0.7647 | 0.7375 / 1 / 0.6471 |
| Doppler channel (displacement only) | 0.6522 / 4 / 0.5882 | 0.7069 / 1 / 0.7647 |

Deciding what moves needs both channels: Doppler cannot see a pedestrian crossing the line of sight, and ego compensated displacement is slow and its noise floor grows with range, so a flat speed bar reports distant posts. The reference also fails without ego compensation of its tracks (-2.7021, 0.1176 mostly tracked) and when every confirmed track is reported (-18.3494). A SORT style tracker run on the raw detections scores -24.2432 with 93 switches and 31162 false rows (`authoring/evidence/shortcut_baseline.py`). Coasting through the occlusions is not claimed: shortening it to 2 frames still passes (0.7246 / 4 / 0.8824).

CPU only: a sequential per frame association over 600 frames of a few dozen detections has nothing for a GPU to parallelize.

## Reference solution

`solution/tracker.py`:

- **Ego motion.** Per frame RANSAC fit of `vr = -(vsx x + vsy y) / r`, refit on the inliers, smoothed over nine frames; yaw rate is `vsx / 3.0 m`.
- **Grouping.** Detections split by their Doppler residual against the static world; movers grouped at 3.5 m, the static set at 1.2 m.
- **Association.** Hungarian assignment gated in position and, from a track's third hit, in predicted Doppler. Tracks are carried into each new frame through the ego rotation and translation with their position history, so a least squares fit gives each body's own velocity; a new mover's velocity is seeded from its Doppler residual.
- **Moving test.** Three frames of motion on either channel: Doppler residual above 1 m/s, or compensated speed above 1.0 + 0.02 r m/s.
- **Lifecycle.** 3 of 5 confirmation, 12 frames alive without detection but at most 2 reported and never outside the field of view, id handover to a track confirming beside one that just lost its body, and a merge of two moving tracks on one spot moving alike.

## Verification

`tests/scoring.py` pairs rows to truth frame by frame: a track id that held an object last frame keeps it while within 3 m, the rest are paired by a minimum total distance Hungarian assignment gated at 3 m, and a changed pairing is an identity switch. `tests/test_verify.py` requires:

- MOTA (one minus misses, false rows and switches over 1242 true object frames) of at least 0.65
- at most 20 identity switches
- at least 0.85 of the 17 moving objects paired in 70 percent or more of their frames in view

**How the bars were set.** The reference (0.7480 / 6 / 17 of 17) and the independent tracker (0.7222 / 1 / 15 of 17; IRLS ego fit, world frame integration, grid grouping, constant velocity Kalman filter) both pass; every ablation above fails; removing the reference's id handover gives 36 switches, the case only the switch bar catches. The narrowest broken margin is the independent tracker without ego smoothing at 0.6425. Seven of eight perturbations of the reference's own knobs by 20 to 50 percent pass (MOTA 0.6618 to 0.7609, at most 18 switches, at least 0.8824 mostly tracked); the one that fails shrinks the range scaled speed bar by 30 percent and reports distant static posts (MOTA 0.5990).

**Cheat attempts** (`authoring/evidence/cheat_attempts.md`): the truth is not in the agent's container, and a missing, header only or non finite output, the shortcut and an unfiltered track dump all score 0.

**Re-running the numbers.** `authoring/evidence/evaluate.py` reproduces every number above into `results.json` and `results.md`. Regenerating from the seed reproduces the shipped data byte for byte.
