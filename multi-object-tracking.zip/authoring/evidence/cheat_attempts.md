# Cheat attempts

All of these score 0 against `tests/test_verify.py`, checked locally with the pinned pytest and
the same `--ctrf` invocation as `tests/test.sh`.

**Read the sealed truth.** `tests/truth_tracks.csv` is baked only into the verifier image, built
after the agent's container is gone, and nothing under `environment/` is derived from it at run
time. The ego truth used for authoring diagnostics (`authoring/provenance/ego_truth.csv`) is never
mounted into any container.

**Answer nothing or garbage.** A missing `/app/output/tracks.csv` (the nop case) errors every
test; a header only file fails MOTA and mostly tracked; a row with a non finite coordinate fails
the well formed check.

**Dump every track.** Reporting every confirmed track with no test of whether it moves turns the
roadside into tracks: MOTA -18.3494 with 23851 false rows.

**The quick shortcut.** `shortcut_baseline.py` is the textbook SORT style tracker a reviewer can
write in minutes: constant velocity prediction, Hungarian assignment in a position gate, 3 of 5
confirmation and coasting, run straight on the raw detections. MOTA -24.2432, 93 identity
switches, 31162 false rows.

**Pass on one channel.** Classifying motion by Doppler alone leaves crossing pedestrians out
(0.7647 of objects mostly tracked for the reference, 0.6471 for the independent tracker, against
0.85); displacement alone gives 0.5882 and 0.7647.

The oracle output passed the verifier three runs in a row. Every number is in `results.json`.
