"""
Scores every solver shipped in this bundle against the sealed truth with the
verifier's own metric code (tests/scoring.py) and writes results.json and
results.md. This is the script behind every number quoted in README.md and
task.toml; run it again to reproduce them.

What it runs:
  the reference, and one ablation of it per claimed crux
  perturbations of the reference's own knobs, which must still pass
  the independent tracker, and the same crux ablations applied to it,
    because a crux only counts if removing it breaks every correct solver
  the SORT style shortcut a reviewer would write in a few minutes
"""
import csv
import json
import os
import shutil
import sys
import tempfile
from concurrent.futures import ProcessPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(ROOT, "solution"))
sys.path.insert(0, os.path.join(ROOT, "tests"))
sys.path.insert(0, HERE)

DET_PATH = os.path.join(ROOT, "environment", "data", "detections.csv")
TRUTH_PATH = os.path.join(ROOT, "tests", "truth_tracks.csv")

REFERENCE_RUNS = [
    ("reference", {}, {}),
    ("ref_no_ego_motion", {"ego_motion": False}, {}),
    ("ref_nonrobust_ego_fit", {"robust_fit": False}, {}),
    ("ref_no_ego_smoothing", {"smooth_ego": False}, {}),
    ("ref_no_ego_compensation", {"ego_compensate": False}, {}),
    ("ref_no_clustering", {"cluster": False}, {}),
    ("ref_single_radius_cluster", {"split_cluster": False}, {}),
    ("ref_doppler_only_classify", {"flow_classify": False}, {}),
    ("ref_flow_only_classify", {"doppler_classify": False}, {}),
    ("ref_no_classification", {"classify": False}, {}),
    ("ref_short_coast", {}, {"MAX_COAST": 1 / 6}),
    ("ref_no_handover", {"handover": False}, {}),
    ("tune_coast_report_x0.5", {}, {"MAX_COAST_REPORT": 0.5}),
    ("tune_coast_report_x1.5", {}, {"MAX_COAST_REPORT": 1.5}),
    ("tune_gate_pos_x0.7", {}, {"GATE_POS_M": 0.7}),
    ("tune_gate_pos_x1.3", {}, {"GATE_POS_M": 1.3}),
    ("tune_mover_eps_x0.8", {}, {"MOVER_EPS_M": 0.8}),
    ("tune_mover_eps_x1.2", {}, {"MOVER_EPS_M": 1.2}),
    ("tune_speed_per_m_x0.7", {}, {"MOVING_SPEED_PER_M": 0.7}),
    ("tune_speed_per_m_x1.3", {}, {"MOVING_SPEED_PER_M": 1.3}),
]

INDEPENDENT_RUNS = [
    ("independent", {}),
    ("ind_no_ego_motion", {"ego_motion": False}),
    ("ind_nonrobust_ego_fit", {"robust": False}),
    ("ind_no_ego_smoothing", {"smooth": False}),
    ("ind_single_radius_cluster", {"split": False}),
    ("ind_no_clustering", {"cluster": False}),
    ("ind_doppler_only_classify", {"flow_classify": False}),
    ("ind_flow_only_classify", {"doppler_classify": False}),
]


def _load(path):
    with open(path, newline="") as f:
        return [{"frame": int(r["frame"]), "track_id": r["track_id"],
                 "x": float(r["x"]), "y": float(r["y"])} for r in csv.DictReader(f)]


def _job(args):
    solver, name, kwargs, scale, out_dir = args
    import scoring
    out = os.path.join(out_dir, name + ".csv")
    if solver == "reference":
        import tracker
        for key, factor in scale.items():
            setattr(tracker, key, getattr(tracker, key) * factor)
        tracker.run(DET_PATH, out, **kwargs)
    elif solver == "independent":
        import independent_tracker
        independent_tracker.run(DET_PATH, out, **kwargs)
    else:
        import shortcut_baseline
        shortcut_baseline.run(DET_PATH, out)
    return name, scoring.evaluate(_load(out), scoring.read_truth_csv(TRUTH_PATH))


def main():
    out_dir = tempfile.mkdtemp(prefix="mot_eval_")
    jobs = [("reference", n, kw, sc, out_dir) for n, kw, sc in REFERENCE_RUNS]
    jobs += [("independent", n, kw, {}, out_dir) for n, kw in INDEPENDENT_RUNS]
    jobs.append(("shortcut", "shortcut_baseline", {}, {}, out_dir))
    try:
        with ProcessPoolExecutor(max_workers=min(8, os.cpu_count() or 1)) as pool:
            results = dict(pool.map(_job, jobs))
    finally:
        shutil.rmtree(out_dir, ignore_errors=True)

    order = [j[1] for j in jobs]
    results = {name: results[name] for name in order}
    with open(os.path.join(HERE, "results.json"), "w", newline="\n") as f:
        json.dump(results, f, indent=2)
        f.write("\n")

    lines = ["| Run | MOTA | ID switches | Mostly tracked | False rows | Misses |",
             "|---|---|---|---|---|---|"]
    for name, m in results.items():
        lines.append(f"| {name} | {m['mota']:.4f} | {m['num_switches']} | "
                     f"{m['mostly_tracked_fraction']:.4f} | {m['total_fp']} | {m['total_fn']} |")
    with open(os.path.join(HERE, "results.md"), "w", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
