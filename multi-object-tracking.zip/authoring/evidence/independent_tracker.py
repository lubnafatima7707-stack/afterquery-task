"""
Independent second tracker for multi-object-tracking, written end to end
with a different structure from solution/tracker.py so the pass bars can be
checked against more than one correct method.

Differences from the reference, piece by piece:
  ego motion   iteratively reweighted least squares (Tukey weights) instead
               of RANSAC, smoothed forward and backward with an exponential
               filter instead of a moving average
  frame        the ego pose is integrated into a world frame and every
               detection is moved there; tracking happens in that fixed
               frame, and positions are mapped back to the sensor frame only
               when written out, instead of carrying tracks through the ego
               transform frame by frame
  grouping     grid based density grouping in the world frame on position
               and Doppler residual together, instead of separate union find
               passes for movers and static points
  filter       constant velocity Kalman filter per track instead of a least
               squares fit over a position history
  lifecycle    4 of 6 confirmation and 5 coasted frames instead of 3 of 5
               and 6

Switches (ego_motion, robust, doppler_classify, flow_classify, cluster) let
authoring/evidence/evaluate.py ablate this solver as well as the reference.
"""
import csv
import math
import sys

import numpy as np
from scipy.optimize import linear_sum_assignment

DT = 0.1
N_FRAMES = 600
MOUNT_AHEAD_M = 3.0

IRLS_ITERS = 8
TUKEY_C = 1.0
EGO_ALPHA = 0.35

RES_MOVING = 1.0
GROUP_M = 3.2
GROUP_RES = 1.5

GATE_M = 3.5
CONFIRM_HITS = 4
CONFIRM_WINDOW = 6
MAX_COAST = 5
MOVE_SPEED = 1.0
MOVE_PER_M = 0.025

Q_ACC = 3.0
R_POS = 0.8


def read_detections(path):
    frames = {}
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            frames.setdefault(int(row["frame"]), []).append(
                (float(row["x"]), float(row["y"]), float(row["vr"])))
    return frames


def fit_sensor_velocity(dets, robust=True):
    D = np.asarray(dets, dtype=float)
    r = np.maximum(np.hypot(D[:, 0], D[:, 1]), 1e-6)
    A = np.stack([-D[:, 0] / r, -D[:, 1] / r], axis=1)
    b = D[:, 2]
    # start from the median forward speed implied by near boresight points,
    # which the static world dominates
    fwd = np.abs(D[:, 0]) < 0.3 * D[:, 1]
    v0 = np.array([0.0, float(np.median(-b[fwd] * r[fwd] / D[fwd, 1]))]) if fwd.any() else np.zeros(2)
    sol = v0
    if not robust:
        sol, *_ = np.linalg.lstsq(A, b, rcond=None)
        return sol
    for _ in range(IRLS_ITERS):
        e = A @ sol - b
        u = e / TUKEY_C
        w = np.where(np.abs(u) < 1.0, (1.0 - u ** 2) ** 2, 0.0)
        if w.sum() < 3:
            break
        Aw = A * w[:, None]
        sol = np.linalg.solve(Aw.T @ A + 1e-9 * np.eye(2), Aw.T @ b)
    return sol


def ego_track(frames, robust=True, enabled=True, smooth=True):
    raw = np.zeros((N_FRAMES, 2))
    if not enabled:
        return raw
    for k in range(N_FRAMES):
        d = frames.get(k, [])
        raw[k] = fit_sensor_velocity(d, robust) if len(d) >= 3 else (raw[k - 1] if k else 0.0)
    if not smooth:
        return raw
    fwd = raw.copy()
    for k in range(1, N_FRAMES):
        fwd[k] = EGO_ALPHA * raw[k] + (1 - EGO_ALPHA) * fwd[k - 1]
    bwd = raw.copy()
    for k in range(N_FRAMES - 2, -1, -1):
        bwd[k] = EGO_ALPHA * raw[k] + (1 - EGO_ALPHA) * bwd[k + 1]
    return 0.5 * (fwd + bwd)


def integrate_pose(vs):
    """World pose of the sensor per frame from its own velocity profile."""
    pos = np.zeros((N_FRAMES, 2))
    head = np.zeros(N_FRAMES)
    x = y = h = 0.0
    for k in range(N_FRAMES):
        pos[k] = (x, y)
        head[k] = h
        vsx, vsy = vs[k]
        # sensor axes: x left, y forward; heading measured from world y
        fx, fy = -math.sin(h), math.cos(h)
        lx, ly = -math.cos(h), -math.sin(h)
        x += (vsy * fx + vsx * lx) * DT
        y += (vsy * fy + vsx * ly) * DT
        h += (vsx / MOUNT_AHEAD_M) * DT
    return pos, head


def to_world(p, pos, h):
    fx, fy = -math.sin(h), math.cos(h)
    lx, ly = -math.cos(h), -math.sin(h)
    return np.array([pos[0] + p[0] * lx + p[1] * fx, pos[1] + p[0] * ly + p[1] * fy])


def to_sensor(w, pos, h):
    d = w - pos
    fx, fy = -math.sin(h), math.cos(h)
    lx, ly = -math.cos(h), -math.sin(h)
    return np.array([d[0] * lx + d[1] * ly, d[0] * fx + d[1] * fy])


def in_view(p):
    r = math.hypot(p[0], p[1])
    return 1.5 <= r <= 80.0 and p[1] > 0.0 and abs(math.degrees(math.atan2(p[0], p[1]))) <= 75.0


def group(points, res, enabled=True, split=True):
    n = len(points)
    if not enabled:
        return [[i] for i in range(n)]
    cells = {}
    for i, (x, y) in enumerate(points):
        cells.setdefault((int(math.floor(x / GROUP_M)), int(math.floor(y / GROUP_M))), []).append(i)
    label = [-1] * n
    cur = 0
    for i in range(n):
        if label[i] >= 0:
            continue
        label[i] = cur
        stack = [i]
        while stack:
            a = stack.pop()
            cx, cy = int(math.floor(points[a][0] / GROUP_M)), int(math.floor(points[a][1] / GROUP_M))
            radius = GROUP_M if (not split or abs(res[a]) > RES_MOVING) else 1.2
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    for b in cells.get((cx + dx, cy + dy), []):
                        if label[b] >= 0:
                            continue
                        if split and (abs(res[a]) > RES_MOVING) != (abs(res[b]) > RES_MOVING):
                            continue
                        if abs(res[a] - res[b]) > GROUP_RES:
                            continue
                        if math.hypot(points[a][0] - points[b][0], points[a][1] - points[b][1]) <= radius:
                            label[b] = cur
                            stack.append(b)
        cur += 1
    out = {}
    for i, l in enumerate(label):
        out.setdefault(l, []).append(i)
    return list(out.values())


class KF:
    F = np.array([[1, 0, DT, 0], [0, 1, 0, DT], [0, 0, 1, 0], [0, 0, 0, 1]], dtype=float)
    H = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], dtype=float)

    def __init__(self, tid, z, res):
        self.id = tid
        self.x = np.array([z[0], z[1], 0.0, 0.0])
        self.P = np.diag([R_POS, R_POS, 100.0, 100.0])
        self.hits, self.window, self.coast = 1, 1, 0
        self.confirmed = False
        self.res = res
        self.evidence = 0

    def predict(self):
        q = Q_ACC
        G = np.array([[DT ** 2 / 2, 0], [0, DT ** 2 / 2], [DT, 0], [0, DT]])
        self.x = self.F @ self.x
        self.P = self.F @ self.P @ self.F.T + G @ (q * np.eye(2)) @ G.T

    def update(self, z, res):
        S = self.H @ self.P @ self.H.T + R_POS * np.eye(2)
        K = self.P @ self.H.T @ np.linalg.inv(S)
        self.x = self.x + K @ (np.asarray(z) - self.H @ self.x)
        self.P = (np.eye(4) - K @ self.H) @ self.P
        self.res = res


def run(det_path, out_path, ego_motion=True, robust=True, doppler_classify=True,
        flow_classify=True, cluster=True, smooth=True, split=True):
    frames = read_detections(det_path)
    vs = ego_track(frames, robust=robust, enabled=ego_motion, smooth=smooth)
    pos, head = integrate_pose(vs)
    tracks, next_id, rows = [], 1, []

    for k in range(N_FRAMES):
        dets = frames.get(k, [])
        world, res = [], []
        for x, y, vr in dets:
            r = max(math.hypot(x, y), 1e-6)
            res.append(vr + (vs[k][0] * x + vs[k][1] * y) / r)
            world.append(to_world((x, y), pos[k], head[k]))
        groups = group(world, res, enabled=cluster, split=split)
        meas = [(np.mean([world[i] for i in g], axis=0), float(np.mean([res[i] for i in g])))
                for g in groups]

        for t in tracks:
            t.predict()
        pairs = []
        if tracks and meas:
            C = np.full((len(tracks), len(meas)), 1e6)
            for i, t in enumerate(tracks):
                for j, (z, _) in enumerate(meas):
                    d = float(np.hypot(*(t.x[:2] - z)))
                    if d <= GATE_M:
                        C[i, j] = d
            ri, ci = linear_sum_assignment(C)
            pairs = [(i, j) for i, j in zip(ri, ci) if C[i, j] < 1e6]
        mt = {i for i, _ in pairs}
        mm = {j for _, j in pairs}
        for i, j in pairs:
            t = tracks[i]
            t.update(meas[j][0], meas[j][1])
            t.hits += 1
            t.window += 1
            t.coast = 0
            if t.hits >= CONFIRM_HITS:
                t.confirmed = True
        keep = []
        for i, t in enumerate(tracks):
            if i in mt:
                keep.append(t)
                continue
            t.window += 1
            if t.confirmed:
                t.coast += 1
                if t.coast <= MAX_COAST:
                    keep.append(t)
            elif t.window < CONFIRM_WINDOW:
                keep.append(t)
        tracks = keep
        for j, (z, r) in enumerate(meas):
            if j not in mm:
                tracks.append(KF(next_id, z, r))
                next_id += 1

        for t in tracks:
            p = to_sensor(t.x[:2], pos[k], head[k])
            rng_m = math.hypot(p[0], p[1])
            moving = (doppler_classify and abs(t.res) > RES_MOVING) or (
                flow_classify and t.hits >= 5
                and math.hypot(t.x[2], t.x[3]) >= MOVE_SPEED + MOVE_PER_M * rng_m)
            t.evidence = min(t.evidence + 1, 10) if moving else max(t.evidence - 1, 0)
            if t.confirmed and t.evidence >= 3 and in_view(p):
                rows.append((k, t.id, float(p[0]), float(p[1])))

    with open(out_path, "w", newline="\n") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["frame", "track_id", "x", "y"])
        for row in rows:
            w.writerow([row[0], row[1], f"{row[2]:.4f}", f"{row[3]:.4f}"])
    return rows


if __name__ == "__main__":
    run(sys.argv[1], sys.argv[2])
