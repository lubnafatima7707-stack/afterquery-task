"""
The quick baseline a reviewer might write in a few minutes: a textbook
SORT style tracker run straight on the sensor frame detections. Constant
velocity prediction, Hungarian assignment inside a position gate, 3 of 5
confirmation, 6 coasted frames, every confirmed track reported. No ego
motion estimate, no grouping of detections from one body, and no test of
whether a track is moving. Used to check that the standard recipe does not
clear the pass bars on this data.
"""
import csv
import math
import sys

import numpy as np
from scipy.optimize import linear_sum_assignment

DT = 0.1
N_FRAMES = 600
GATE_M = 3.5


def run(det_path, out_path):
    frames = {}
    with open(det_path, newline="") as f:
        for row in csv.DictReader(f):
            frames.setdefault(int(row["frame"]), []).append((float(row["x"]), float(row["y"])))

    tracks, next_id, rows = [], 1, []
    for k in range(N_FRAMES):
        dets = frames.get(k, [])
        for t in tracks:
            t["x"] += t["vx"] * DT
            t["y"] += t["vy"] * DT
        pairs = []
        if tracks and dets:
            C = np.full((len(tracks), len(dets)), 1e6)
            for i, t in enumerate(tracks):
                for j, (x, y) in enumerate(dets):
                    d = math.hypot(t["x"] - x, t["y"] - y)
                    if d <= GATE_M:
                        C[i, j] = d
            ri, ci = linear_sum_assignment(C)
            pairs = [(i, j) for i, j in zip(ri, ci) if C[i, j] < 1e6]
        mt = {i for i, _ in pairs}
        md = {j for _, j in pairs}
        for i, j in pairs:
            t = tracks[i]
            x, y = dets[j]
            t["vx"] = 0.6 * t["vx"] + 0.4 * (x - t["x"]) / DT + 0.4 * t["vx"] * 0
            t["vy"] = 0.6 * t["vy"] + 0.4 * (y - t["y"]) / DT
            t["x"], t["y"] = x, y
            t["hits"] += 1
            t["window"] += 1
            t["coast"] = 0
            if t["hits"] >= 3:
                t["confirmed"] = True
        keep = []
        for i, t in enumerate(tracks):
            if i in mt:
                keep.append(t)
                continue
            t["window"] += 1
            if t["confirmed"]:
                t["coast"] += 1
                if t["coast"] <= 6:
                    keep.append(t)
            elif t["window"] < 5:
                keep.append(t)
        tracks = keep
        for j, (x, y) in enumerate(dets):
            if j not in md:
                tracks.append(dict(id=next_id, x=x, y=y, vx=0.0, vy=0.0, hits=1,
                                   window=1, coast=0, confirmed=False))
                next_id += 1
        for t in tracks:
            if t["confirmed"]:
                rows.append((k, t["id"], t["x"], t["y"]))

    with open(out_path, "w", newline="\n") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["frame", "track_id", "x", "y"])
        for row in rows:
            w.writerow([row[0], row[1], f"{row[2]:.4f}", f"{row[3]:.4f}"])
    return rows


if __name__ == "__main__":
    run(sys.argv[1], sys.argv[2])
