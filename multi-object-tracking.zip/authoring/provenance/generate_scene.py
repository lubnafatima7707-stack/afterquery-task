"""
Seeded generator for the multi-object-tracking task.

The sensor rides on a moving, turning ego vehicle, mounted ahead of the
rotation center, so its own velocity has a lateral component proportional
to yaw rate. Everything is drawn in a world frame first (ego trajectory,
static roadside infrastructure, moving objects), then projected into the
sensor frame per frame and turned into detections. Ground truth is the
moving objects' sensor frame centroids, written before any detection
noise, clutter or miss is applied, so it is independent of any tracker.

For a detection on a body with world velocity V at sensor frame position
p (range r, unit vector u = p / r), the measured radial velocity is
    vr = (V - V_sensor) . u
so for the static world it collapses to
    vr = -(vsx * x + vsy * y) / r
with (vsx, vsy) the sensor's own velocity in the sensor frame, which is
(d * yaw_rate, speed). That cosine signature over the static detections is
what makes the ego motion observable from a single sensor.

Regenerating from SEED must reproduce environment/data/detections.csv and
tests/truth_tracks.csv byte for byte.
"""
import csv
import json
import math
import os

import numpy as np

SEED = 20260912

DT = 0.1
N_FRAMES = 600
EXTRA_ROAD_FRAMES = 400   # road geometry continues past the ego's own run

# sensor mounting and field of view
MOUNT_AHEAD_M = 3.0          # sensor sits this far ahead of the rotation center
MAX_RANGE_M = 80.0
MIN_RANGE_M = 1.5
MAX_AZIMUTH_DEG = 75.0

# measurement model
POS_NOISE_STD_M = 0.15
DOPPLER_NOISE_STD_MPS = 0.1
P_DETECT_NOMINAL = 0.9
P_DETECT_OCCLUDED = 0.15
CLUTTER_RATE = 2.0
CLUTTER_VR_RANGE = (-30.0, 30.0)

# extended object model: mean detections per body, falling off with range
EXTENT_REF_M = 45.0
EXTENT_MAX_DETS = 6

MOVING_SPEED_THRESHOLD = 1.0  # world speed above this counts as a moving object

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
DET_PATH = os.path.join(ROOT, "environment", "data", "detections.csv")
SPEC_PATH = os.path.join(ROOT, "environment", "data", "sensor_spec.json")
TRUTH_PATH = os.path.join(ROOT, "tests", "truth_tracks.csv")
EGO_PATH = os.path.join(HERE, "ego_truth.csv")


def _ramp(t, t0, t1, value):
    """Raised cosine ramp up and down, so yaw rate is continuous."""
    if t <= t0 or t >= t1:
        return 0.0
    span = t1 - t0
    return value * 0.5 * (1.0 - math.cos(2.0 * math.pi * (t - t0) / span))


def ego_trajectory(n_frames=N_FRAMES):
    """Integrate the ego pose. Returns arrays of position, heading, speed,
    yaw rate, one entry per frame. Integrating past N_FRAMES gives the road
    geometry ahead of where the ego itself gets to."""
    pos = np.zeros((n_frames, 2))
    psi = np.zeros(n_frames)
    speed = np.zeros(n_frames)
    yaw = np.zeros(n_frames)

    x, y, heading = 0.0, 0.0, math.pi / 2.0  # start heading north
    for k in range(n_frames):
        t = k * DT
        v = 14.0 + 5.0 * math.sin(2.0 * math.pi * t / 37.0) + 2.0 * math.sin(2.0 * math.pi * t / 11.0)
        w = 0.0
        w += _ramp(t, 8.0, 14.0, 0.12)     # sweeping right hand bend
        w += _ramp(t, 22.0, 27.0, -0.15)   # tighter left
        w += _ramp(t, 38.0, 44.0, 0.10)
        w += _ramp(t, 50.0, 56.0, -0.13)
        w += _ramp(t, 17.0, 19.0, 0.04)    # lane change wobbles
        w += _ramp(t, 33.0, 35.0, -0.05)

        pos[k] = (x, y)
        psi[k] = heading
        speed[k] = v
        yaw[k] = w

        x += v * math.cos(heading) * DT
        y += v * math.sin(heading) * DT
        heading += w * DT
    return pos, psi, speed, yaw


def path_frame(pos, psi, k):
    """Forward and left unit vectors of the ego at frame k."""
    f = np.array([math.cos(psi[k]), math.sin(psi[k])])
    l = np.array([-math.sin(psi[k]), math.cos(psi[k])])
    return f, l


class Road:
    """Arc length parameterization of the route, so other traffic follows
    the same curves the ego does instead of driving straight through the
    bends."""

    def __init__(self, pos, psi):
        self.pos = pos
        self.psi = np.unwrap(psi)
        step = np.linalg.norm(np.diff(pos, axis=0), axis=1)
        self.s = np.concatenate([[0.0], np.cumsum(step)])

    def point(self, s, lateral=0.0):
        idx = np.interp(s, self.s, np.arange(len(self.s)))
        i0 = int(np.clip(math.floor(idx), 0, len(self.s) - 2))
        frac = float(np.clip(idx - i0, 0.0, 1.0))
        base = self.pos[i0] * (1.0 - frac) + self.pos[i0 + 1] * frac
        heading = self.psi[i0] * (1.0 - frac) + self.psi[i0 + 1] * frac
        left = np.array([-math.sin(heading), math.cos(heading)])
        return base + left * lateral, heading

    def arc_of_frame(self, k):
        return float(self.s[k])


def place_along_path(pos, psi, frame_idx, lateral, ahead=0.0):
    """A world point at a lateral offset from the ego path at frame_idx."""
    f, l = path_frame(pos, psi, frame_idx)
    return pos[frame_idx] + f * ahead + l * lateral


def build_static_world(pos, psi, rng, n_frames):
    """Guardrail posts, poles and parked cars laid out along the route."""
    bodies = []
    # guardrail posts every 5 m of travel on both shoulders
    travelled = 0.0
    last = pos[0]
    for k in range(n_frames):
        travelled += float(np.linalg.norm(pos[k] - last))
        last = pos[k]
        if travelled >= 6.0:
            travelled = 0.0
            for side in (-1.0, 1.0):
                jitter = rng.normal(0.0, 0.15)
                p = place_along_path(pos, psi, k, side * (8.5 + jitter))
                bodies.append(dict(kind="post", center=p, velocity=np.zeros(2),
                                   length=0.3, width=0.3, heading=psi[k]))
    # curb reflectors closer to the lane, seen at wide azimuth as they pass
    travelled = 0.0
    last = pos[0]
    for k in range(n_frames):
        travelled += float(np.linalg.norm(pos[k] - last))
        last = pos[k]
        if travelled >= 8.0:
            travelled = 0.0
            for side in (-1.0, 1.0):
                p = place_along_path(pos, psi, k, side * (5.4 + rng.normal(0.0, 0.1)))
                bodies.append(dict(kind="curb", center=p, velocity=np.zeros(2),
                                   length=0.25, width=0.25, heading=psi[k]))

    # light poles further out, sparser
    for k in range(0, n_frames, 40):
        for side in (-1.0, 1.0):
            p = place_along_path(pos, psi, k, side * 12.5, ahead=rng.uniform(-4, 4))
            bodies.append(dict(kind="pole", center=p, velocity=np.zeros(2),
                               length=0.4, width=0.4, heading=psi[k]))
    # parked cars on the right shoulder
    for k in range(30, n_frames, 95):
        p = place_along_path(pos, psi, k, 6.2, ahead=rng.uniform(-3, 3))
        bodies.append(dict(kind="parked", center=p, velocity=np.zeros(2),
                           length=4.6, width=1.9, heading=psi[k]))
    return bodies


def build_moving_objects(road, speed, rng):
    """Moving bodies. Vehicles are parameterized along the road, so they
    hold their lane through the bends; pedestrians cross in a straight line.

    Lead vehicles hold close to the ego's own speed, so their radial
    velocity sits near zero while the static world's sits near minus the
    ego speed: filtering on raw Doppler keeps exactly the wrong set.
    """
    objs = []

    def add_road(oid, birth, lateral, ahead, rel_speed, lateral_speed=0.0,
                 length=4.5, width=1.9, occl=None):
        objs.append(dict(id=oid, kind="road", birth=birth,
                         s0=road.arc_of_frame(birth) + ahead,
                         lateral0=lateral, lateral_speed=lateral_speed,
                         along_speed=speed[birth] + rel_speed,
                         length=length, width=width, occl=occl))

    # lead vehicles, same direction, small speed difference
    add_road("lead_01", 0, 0.2, 42.0, -1.5)
    add_road("lead_02", 120, -0.1, 55.0, 1.2, occl=(30, 45))
    add_road("lead_03", 250, 3.4, 30.0, 2.5)
    add_road("lead_04", 380, -0.2, 48.0, -2.0, occl=(35, 52))
    add_road("lead_05", 470, 0.1, 62.0, 1.8)

    # oncoming traffic in the opposite lane, closing fast
    for i, birth in enumerate((40, 150, 210, 300, 410, 520)):
        objs.append(dict(id=f"onc_{i + 1:02d}", kind="road", birth=birth,
                         s0=road.arc_of_frame(birth) + rng.uniform(85.0, 98.0),
                         lateral0=-3.6 + rng.normal(0, 0.2), lateral_speed=0.0,
                         along_speed=-rng.uniform(12.0, 18.0),
                         length=4.5, width=1.9, occl=None))

    # crossing pedestrians, point sized, slow, far enough ahead to stay in
    # view for a useful stretch as the ego closes on them
    for i, (birth, lateral, ahead, lat_speed) in enumerate((
            (70, -13.0, 70.0, 2.8),
            (210, 14.0, 66.0, -2.6),
            (330, -12.0, 72.0, 3.0),
            (545, -13.0, 55.0, 2.7))):
        base, heading = road.point(road.arc_of_frame(birth) + ahead, lateral)
        left = np.array([-math.sin(heading), math.cos(heading)])
        objs.append(dict(id=f"ped_{i + 1:02d}", kind="straight", birth=birth,
                         center0=base, velocity=left * lat_speed,
                         length=0.5, width=0.5, heading=heading, occl=None))

    # merging vehicles that change lane across the ego's path
    add_road("merge_01", 180, -3.5, 30.0, 3.0, lateral_speed=1.1)
    add_road("merge_02", 430, 6.5, 26.0, 4.0, lateral_speed=-1.3)

    return objs


def moving_state(obj, road, k):
    """World position, velocity and heading of a moving object at frame k."""
    t = (k - obj["birth"]) * DT
    if obj["kind"] == "straight":
        center = obj["center0"] + obj["velocity"] * t
        return center, obj["velocity"], obj["heading"]
    s = obj["s0"] + obj["along_speed"] * t
    lateral = obj["lateral0"] + obj["lateral_speed"] * t
    center, heading = road.point(s, lateral)
    # differentiate the same parameterization to get an exact velocity
    h = 0.01
    ahead, _ = road.point(s + obj["along_speed"] * h,
                          lateral + obj["lateral_speed"] * h)
    behind, _ = road.point(s - obj["along_speed"] * h,
                           lateral - obj["lateral_speed"] * h)
    vel = (ahead - behind) / (2.0 * h)
    if obj["along_speed"] < 0:
        heading += math.pi
    return center, vel, heading


def to_sensor_frame(world_pts, sensor_pos, f, l):
    rel = np.atleast_2d(world_pts) - sensor_pos
    xs = rel @ l
    ys = rel @ f
    return np.stack([xs, ys], axis=1)


def in_fov(p):
    r = math.hypot(p[0], p[1])
    if r < MIN_RANGE_M or r > MAX_RANGE_M:
        return False
    if p[1] <= 0.0:
        return False
    az = math.degrees(math.atan2(p[0], p[1]))
    return abs(az) <= MAX_AZIMUTH_DEG


def body_detection_points(center_s, heading_rel, length, width, rng):
    """Scatter detections over a body's footprint in the sensor frame. The
    mean count falls off with range, so nearby vehicles resolve into
    several detections and far ones collapse to a single point."""
    r = math.hypot(center_s[0], center_s[1])
    mean_n = np.clip(EXTENT_REF_M / max(r, 1.0), 1.0, EXTENT_MAX_DETS)
    n = max(1, int(rng.poisson(mean_n)))
    n = min(n, EXTENT_MAX_DETS)
    if length <= 0.8 and width <= 0.8:
        n = 1
    c, s = math.cos(heading_rel), math.sin(heading_rel)
    pts = []
    for _ in range(n):
        a = rng.uniform(-0.5, 0.5) * length
        b = rng.uniform(-0.5, 0.5) * width
        dx = b * c - a * s
        dy = b * s + a * c
        pts.append((center_s[0] + dx, center_s[1] + dy))
    return pts


MIN_GAP_M = 3.0


def separation_violations(truth_rows):
    """Two bodies cannot share a spot, and two graded objects closer than
    the 3 m scoring gate make the truth ambiguous, so any frame where two
    moving objects come that close is a generator bug, not a hard case.
    Vehicles passing in adjacent lanes stay 3.2 m or more apart."""
    by_frame = {}
    for f, oid, x, y in truth_rows:
        by_frame.setdefault(f, []).append((oid, x, y))
    bad = []
    for f, objs in sorted(by_frame.items()):
        for i in range(len(objs)):
            for j in range(i + 1, len(objs)):
                a, b = objs[i], objs[j]
                d = math.hypot(a[1] - b[1], a[2] - b[2])
                if d < MIN_GAP_M:
                    bad.append((f, a[0], b[0], round(d, 2)))
    return bad


def build():
    rng = np.random.default_rng(SEED)
    pos_ext, psi_ext, speed_ext, yaw_ext = ego_trajectory(N_FRAMES + EXTRA_ROAD_FRAMES)
    pos, psi, speed, yaw = (pos_ext[:N_FRAMES], psi_ext[:N_FRAMES],
                            speed_ext[:N_FRAMES], yaw_ext[:N_FRAMES])
    road = Road(pos_ext, psi_ext)

    static_bodies = build_static_world(pos_ext, psi_ext, rng, N_FRAMES + EXTRA_ROAD_FRAMES)
    moving_objects = build_moving_objects(road, speed, rng)

    det_rows = []
    truth_rows = []

    for k in range(N_FRAMES):
        f_vec, l_vec = path_frame(pos, psi, k)
        sensor_pos = pos[k] + f_vec * MOUNT_AHEAD_M
        # sensor velocity in world, including the lever arm term
        v_sensor_world = f_vec * speed[k] + l_vec * (MOUNT_AHEAD_M * yaw[k])

        frame_dets = []

        def emit(body_center_world, body_vel_world, length, width, heading,
                 p_detect, is_point):
            center_s = to_sensor_frame(body_center_world, sensor_pos, f_vec, l_vec)[0]
            if not in_fov(center_s):
                return None
            heading_rel = heading - psi[k]
            pts = ([tuple(center_s)] if is_point
                   else body_detection_points(center_s, heading_rel, length, width, rng))
            for px, py in pts:
                if rng.random() >= p_detect:
                    continue
                r = math.hypot(px, py)
                if r < 1e-6:
                    continue
                u = np.array([px, py]) / r
                # velocities expressed in the sensor frame
                v_obj_s = np.array([float(body_vel_world @ l_vec), float(body_vel_world @ f_vec)])
                v_sen_s = np.array([float(v_sensor_world @ l_vec), float(v_sensor_world @ f_vec)])
                vr = float((v_obj_s - v_sen_s) @ u)
                frame_dets.append((
                    px + rng.normal(0, POS_NOISE_STD_M),
                    py + rng.normal(0, POS_NOISE_STD_M),
                    vr + rng.normal(0, DOPPLER_NOISE_STD_MPS),
                ))
            return center_s

        for body in static_bodies:
            emit(body["center"], body["velocity"], body["length"], body["width"],
                 body["heading"], P_DETECT_NOMINAL,
                 is_point=body["kind"] in ("post", "pole", "curb"))

        for obj in moving_objects:
            if k < obj["birth"]:
                continue
            center_world, obj_vel, obj_heading = moving_state(obj, road, k)
            p_detect = P_DETECT_NOMINAL
            if obj["occl"] is not None:
                # occlusion window in frames after birth, so it falls inside
                # the stretch the object is actually in view
                lo, hi = obj["occl"]
                if obj["birth"] + lo <= k <= obj["birth"] + hi:
                    p_detect = P_DETECT_OCCLUDED
            is_point = obj["length"] <= 0.8 and obj["width"] <= 0.8
            center_s = emit(center_world, obj_vel, obj["length"], obj["width"],
                            obj_heading, p_detect, is_point)
            if center_s is not None and float(np.linalg.norm(obj_vel)) > MOVING_SPEED_THRESHOLD:
                truth_rows.append((k, obj["id"], float(center_s[0]), float(center_s[1])))

        n_clutter = rng.poisson(CLUTTER_RATE)
        for _ in range(n_clutter):
            while True:
                cx = rng.uniform(-MAX_RANGE_M, MAX_RANGE_M)
                cy = rng.uniform(0.0, MAX_RANGE_M)
                if in_fov((cx, cy)):
                    break
            frame_dets.append((cx, cy, rng.uniform(*CLUTTER_VR_RANGE)))

        rng.shuffle(frame_dets)
        for j, (x, y, vr) in enumerate(frame_dets):
            det_rows.append((k, j, x, y, vr))

    violations = separation_violations(truth_rows)
    if violations:
        for v in violations[:10]:
            print("separation violation:", v)
        raise SystemExit(f"{len(violations)} object pairs closer than {MIN_GAP_M} m, nothing written")

    os.makedirs(os.path.dirname(DET_PATH), exist_ok=True)
    with open(DET_PATH, "w", newline="\n") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["frame", "det_id", "x", "y", "vr"])
        for row in det_rows:
            w.writerow([row[0], row[1], f"{row[2]:.4f}", f"{row[3]:.4f}", f"{row[4]:.4f}"])

    os.makedirs(os.path.dirname(TRUTH_PATH), exist_ok=True)
    with open(TRUTH_PATH, "w", newline="\n") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["frame", "object_id", "x", "y"])
        for row in sorted(truth_rows, key=lambda r: (r[0], r[1])):
            w.writerow([row[0], row[1], f"{row[2]:.4f}", f"{row[3]:.4f}"])

    with open(EGO_PATH, "w", newline="\n") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["frame", "speed_mps", "yaw_rate_rps", "vsx_mps", "vsy_mps"])
        for k in range(N_FRAMES):
            w.writerow([k, f"{speed[k]:.4f}", f"{yaw[k]:.4f}",
                        f"{MOUNT_AHEAD_M * yaw[k]:.4f}", f"{speed[k]:.4f}"])

    spec = {
        "frame_rate_hz": 1.0 / DT,
        "max_range_m": MAX_RANGE_M,
        "max_azimuth_deg": MAX_AZIMUTH_DEG,
        "mount_ahead_of_rotation_center_m": MOUNT_AHEAD_M,
        "position_noise_std_m": POS_NOISE_STD_M,
        "doppler_noise_std_mps": DOPPLER_NOISE_STD_MPS,
        "nominal_detection_probability": P_DETECT_NOMINAL,
        "moving_speed_threshold_mps": MOVING_SPEED_THRESHOLD,
        "notes": (
            "Coordinates are in the sensor frame: x to the left, y ahead, "
            "meters, origin at the sensor. vr is radial velocity in meters "
            "per second, positive when the range is opening, measured "
            "relative to the sensor, which is itself moving. A body larger "
            "than a point can produce more than one detection in a frame, "
            "more of them at short range. False alarms and missed "
            "detections are present, and detection probability can fall "
            "well below nominal in some frames."
        ),
    }
    with open(SPEC_PATH, "w", newline="\n") as fh:
        json.dump(spec, fh, indent=2)
        fh.write("\n")

    n_moving = len({r[1] for r in truth_rows})
    print(f"static_bodies={len(static_bodies)} moving_objects={len(moving_objects)} "
          f"graded_objects={n_moving} truth_rows={len(truth_rows)} "
          f"detection_rows={len(det_rows)} frames={N_FRAMES}")


if __name__ == "__main__":
    build()
