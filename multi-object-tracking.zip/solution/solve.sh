#!/bin/bash
set -euo pipefail
mkdir -p /app/output
python3 "$(dirname "$0")/tracker.py" /app/data/detections.csv /app/output/tracks.csv --spec /app/data/sensor_spec.json
