"""
Reference tracker for multi-object-tracking.

The sensor rides on a moving, turning vehicle, so nothing in the raw
detection stream means anything until the sensor's own motion is known.
The chain first estimates the sensor velocity in every frame from the
static world's Doppler signature and smooths that profile along time. Each
frame it then splits detections by how far their Doppler departs from the
static world, groups the ones that belong to one body (wide for movers,
which are vehicles several meters long, tight for the static set, which is
mostly point structure a few meters apart), associates them into tracks
while predicting through the ego motion between frames, and reports a
track only once it has shown motion on either of two channels: Doppler
that does not match the static world, or ego compensated displacement.
Doppler alone cannot see motion across the line of sight at all, and
displacement alone is slow and noisy at range, so each covers the other.

Built as switches so authoring/evidence can score weakened variants of this
exact code rather than forks that drift out of sync.
"""
import argparse
import csv
import json
import math
import os

import numpy as np
from scipy.optimize import linear_sum_assignment

DT = 0.1
N_FRAMES = 600

# ego motion fit
RANSAC_ITERS = 120
RANSAC_TOL_MPS = 0.6
MIN_STATIC_FRACTION = 0.25
EGO_SMOOTH_HALFWIDTH = 4

# Doppler residual above which a detection does not belong to the static world
MOVING_RESIDUAL_MPS = 1.0

# grouping detections that belong to one body
MOVER_EPS_M = 3.5
MOVER_EPS_VR = 1.5
STATIC_EPS_M = 1.2

# association
GATE_POS_M = 3.5
GATE_VR_MPS = 4.0
HISTORY = 10
CONFIRM_WINDOW = 5
CONFIRM_HITS = 3
# a confirmed track stays alive long enough to be picked up again after an
# occlusion, but is reported for only a couple of frames with no detection
MAX_COAST = 12
MAX_COAST_REPORT = 2
# a fresh track confirming next to one that has just lost its body is that
# body picked up again, so it takes over the older id
HANDOVER_M = 6.0
HANDOVER_VR_MPS = 3.0
DUPLICATE_M = 3.0
# confirmed tracks this close with the same Doppler are one body tracked
# twice; tighter than DUPLICATE_M so neighbouring lanes are never merged
MERGE_M = 2.0
MERGE_DV_MPS = 2.0

# track level moving decision. The compensated speed of a static track
# grows with range, because a small yaw error swings a distant point
# sideways, so the bar grows with range too
MOVING_SPEED_MPS = 1.0
MOVING_SPEED_PER_M = 0.02
MOVING_EVIDENCE_FRAMES = 3

# field of view, as in sensor_spec.json
MAX_RANGE_M = 80.0
MIN_RANGE_M = 1.5
MAX_AZIMUTH_DEG = 75.0


def rot(angle):
    c, s = math.cos(angle), math.sin(angle)
    return np.array([[c, -s], [s, c]])


def in_fov(x, y):
    r = math.hypot(x, y)
    if r < MIN_RANGE_M or r > MAX_RANGE_M or y <= 0.0:
        return False
    return abs(math.degrees(math.atan2(x, y))) <= MAX_AZIMUTH_DEG


def read_detections(path):
    frames = {}
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            frames.setdefault(int(row["frame"]), []).append(
                (float(row["x"]), float(row["y"]), float(row["vr"])))
    return frames


def static_vr(x, y, v_sensor):
    """Radial velocity a stationary point at (x, y) shows to the sensor."""
    r = max(math.hypot(x, y), 1e-6)
    return -(v_sensor[0] * x + v_sensor[1] * y) / r


def estimate_sensor_velocity(dets, robust=True):
    """Fit vr = -(vsx * x + vsy * y) / r over the detections.

    Only the stationary world obeys that relation, so the movers are
    outliers and the fit has to be robust; a plain least squares over
    everything is dragged off by them.
    """
    if len(dets) < 3:
        return np.zeros(2)
    D = np.asarray(dets, dtype=float)
    x, y, vr = D[:, 0], D[:, 1], D[:, 2]
    r = np.hypot(x, y)
    r = np.where(r < 1e-6, 1e-6, r)
    A = np.stack([-x / r, -y / r], axis=1)

    if not robust:
        sol, *_ = np.linalg.lstsq(A, vr, rcond=None)
        return sol

    rng = np.random.default_rng(12345)
    best_sol, best_count = np.zeros(2), -1
    n = len(D)
    for _ in range(RANSAC_ITERS):
        i, j = rng.choice(n, 2, replace=False)
        M = A[[i, j]]
        if abs(np.linalg.det(M)) < 1e-6:
            continue
        sol = np.linalg.solve(M, vr[[i, j]])
        count = int(np.count_nonzero(np.abs(A @ sol - vr) <= RANSAC_TOL_MPS))
        if count > best_count:
            best_count, best_sol = count, sol

    inliers = np.abs(A @ best_sol - vr) <= RANSAC_TOL_MPS
    if inliers.sum() >= max(3, MIN_STATIC_FRACTION * n):
        best_sol, *_ = np.linalg.lstsq(A[inliers], vr[inliers], rcond=None)
    return best_sol


def ego_profile(frames, n_frames, robust=True, smooth=True):
    """Sensor velocity in every frame, smoothed along time. A single frame's
    fit carries enough angular noise to rotate a track at 80 m by meters;
    the real motion varies over seconds, so smoothing costs nothing."""
    raw = np.zeros((n_frames, 2))
    for f in range(n_frames):
        dets = frames.get(f, [])
        if dets:
            raw[f] = estimate_sensor_velocity(dets, robust=robust)
        elif f:
            raw[f] = raw[f - 1]
    if not smooth:
        return raw
    out = np.zeros_like(raw)
    h = EGO_SMOOTH_HALFWIDTH
    for f in range(n_frames):
        lo, hi = max(0, f - h), min(n_frames, f + h + 1)
        out[f] = raw[lo:hi].mean(axis=0)
    return out


def _link(P, V, idx, eps_m, eps_vr):
    parent = {i: i for i in idx}

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for a_pos, i in enumerate(idx):
        for j in idx[a_pos + 1:]:
            if eps_vr is not None and abs(V[i] - V[j]) > eps_vr:
                continue
            if math.hypot(P[i, 0] - P[j, 0], P[i, 1] - P[j, 1]) <= eps_m:
                ri, rj = find(i), find(j)
                if ri != rj:
                    parent[rj] = ri
    groups = {}
    for i in idx:
        groups.setdefault(find(i), []).append(i)
    return list(groups.values())


def cluster_detections(dets, v_sensor, enabled=True, split=True):
    """Group detections that plausibly come from one body.

    Returns (x, y, mean vr, count, mean Doppler residual). A vehicle at
    short range throws several detections over its length, so one to one
    assignment on raw detections is wrong. The radius that holds a vehicle
    together would also chain neighbouring roadside posts, so movers and the
    static set are grouped separately, each with its own radius.
    """
    if not dets:
        return []
    D = np.asarray(dets, dtype=float)
    P, V = D[:, :2], D[:, 2]
    res = np.array([v - static_vr(x, y, v_sensor) for x, y, v in dets])

    if not enabled:
        groups = [[i] for i in range(len(dets))]
    elif split:
        mov = [i for i in range(len(dets)) if abs(res[i]) > MOVING_RESIDUAL_MPS]
        sta = [i for i in range(len(dets)) if abs(res[i]) <= MOVING_RESIDUAL_MPS]
        groups = _link(P, V, mov, MOVER_EPS_M, MOVER_EPS_VR) + _link(P, V, sta, STATIC_EPS_M, None)
    else:
        groups = _link(P, V, list(range(len(dets))), MOVER_EPS_M, MOVER_EPS_VR)

    out = []
    for g in groups:
        out.append((float(P[g, 0].mean()), float(P[g, 1].mean()),
                    float(V[g].mean()), len(g), float(res[g].mean())))
    return out


class Track:
    """State lives in the current frame's sensor axes. Every frame the
    stored position and the whole position history are carried into the new
    frame by the ego transform, so the velocity fitted over that history is
    the body's own velocity in the world rather than its apparent motion
    past a moving sensor."""

    __slots__ = ("id", "x", "y", "vx", "vy", "hist", "confirmed", "hits",
                 "window", "coast", "moving_evidence", "residual")

    def __init__(self, tid, x, y, frame, residual, vx0=0.0, vy0=0.0):
        self.id = tid
        self.x, self.y = x, y
        self.vx, self.vy = vx0, vy0
        self.hist = [(frame, x, y)]
        self.confirmed = False
        self.hits = 1
        self.window = 1
        self.coast = 0
        self.moving_evidence = 0
        self.residual = residual

    def carry(self, v_sensor, yaw_rate, compensate=True):
        """Map state and history into the next frame's axes, then advance
        the position by the body's own velocity. A world fixed point maps as
        p' = R(dpsi) (p - delta), delta the sensor's own displacement."""
        p = np.array([self.x, self.y])
        u = np.array([self.vx, self.vy])
        if compensate:
            R = rot(yaw_rate * DT)
            delta = v_sensor * DT
            p = R @ (p - delta)
            u = R @ u
            self.hist = [(f, *(R @ (np.array([hx, hy]) - delta)))
                         for f, hx, hy in self.hist]
        p = p + u * DT
        self.x, self.y = float(p[0]), float(p[1])
        self.vx, self.vy = float(u[0]), float(u[1])

    def update(self, x, y, frame, residual):
        self.residual = residual
        self.x, self.y = x, y
        self.hist.append((frame, x, y))
        self.hist = self.hist[-HISTORY:]
        # a two point difference of a body's jittery centroid is off by many
        # meters per second, so the Doppler seeded velocity stands until
        # there are enough points to fit
        if len(self.hist) >= 3:
            t = np.array([h[0] for h in self.hist], dtype=float) * DT
            xs = np.array([h[1] for h in self.hist])
            ys = np.array([h[2] for h in self.hist])
            t_now = frame * DT - t.mean()
            t = t - t.mean()
            denom = float(np.sum(t * t))
            if denom > 1e-9:
                self.vx = float(np.sum(t * (xs - xs.mean())) / denom)
                self.vy = float(np.sum(t * (ys - ys.mean())) / denom)
                # the centroid of a body spread over several detections
                # jumps around, so report the fitted trajectory at this
                # instant rather than the raw centroid
                self.x = float(xs.mean() + self.vx * t_now)
                self.y = float(ys.mean() + self.vy * t_now)

    def speed(self):
        return math.hypot(self.vx, self.vy)

    def predicted_vr(self, v_sensor):
        """Radial velocity this body would show to a sensor that is itself
        moving."""
        r = max(math.hypot(self.x, self.y), 1e-6)
        rel = np.array([self.vx - v_sensor[0], self.vy - v_sensor[1]])
        return float(rel @ np.array([self.x, self.y]) / r)


def handover_donor(new, tracks, matched_idx):
    """The confirmed track, coasting and unmatched this frame, that a newly
    confirmed track most plausibly continues."""
    best, best_d = None, HANDOVER_M
    for i, old in enumerate(tracks):
        if old is new or i in matched_idx or not old.confirmed:
            continue
        if old.coast < 1 or old.coast > MAX_COAST:
            continue
        if abs(old.residual - new.residual) > HANDOVER_VR_MPS:
            continue
        d = math.hypot(old.x - new.x, old.y - new.y)
        if d <= best_d:
            best, best_d = old, d
    return best


def run(det_path, out_path, n_frames=N_FRAMES, mount_ahead_m=3.0,
        ego_motion=True, robust_fit=True, smooth_ego=True, ego_compensate=True,
        cluster=True, split_cluster=True, doppler_classify=True,
        flow_classify=True, classify=True, handover=True, dedup=True):
    frames = read_detections(det_path)
    tracks = []
    next_id = 1
    out_rows = []
    compensate = ego_compensate and ego_motion

    if ego_motion:
        ego = ego_profile(frames, n_frames, robust=robust_fit, smooth=smooth_ego)
    else:
        ego = np.zeros((n_frames, 2))

    for f in range(n_frames):
        dets = frames.get(f, [])
        v_sensor = ego[f]
        yaw_rate = float(v_sensor[0] / mount_ahead_m)

        for tr in tracks:
            tr.carry(v_sensor, yaw_rate, compensate=compensate)

        meas = cluster_detections(dets, v_sensor, enabled=cluster, split=split_cluster)

        n_t, n_m = len(tracks), len(meas)
        matched_t, matched_m, pairs = set(), set(), []
        if n_t and n_m:
            cost = np.full((n_t, n_m), 1e6)
            feas = np.zeros((n_t, n_m), dtype=bool)
            for i, tr in enumerate(tracks):
                pvr = tr.predicted_vr(v_sensor)
                vr_ready = tr.hits >= 3
                for j, (mx, my, mvr, _, _) in enumerate(meas):
                    d = math.hypot(tr.x - mx, tr.y - my)
                    if d > GATE_POS_M:
                        continue
                    dvr = abs(pvr - mvr)
                    if vr_ready and dvr > GATE_VR_MPS:
                        continue
                    feas[i, j] = True
                    cost[i, j] = (d / GATE_POS_M) ** 2
                    if vr_ready:
                        cost[i, j] += (dvr / GATE_VR_MPS) ** 2
            ri, ci = linear_sum_assignment(cost)
            pairs = [(i, j) for i, j in zip(ri, ci) if feas[i, j]]

        matched_idx = {i for i, _ in pairs}
        for i, j in pairs:
            matched_t.add(i)
            matched_m.add(j)
            tr = tracks[i]
            tr.update(meas[j][0], meas[j][1], f, meas[j][4])
            tr.hits += 1
            tr.window += 1
            tr.coast = 0
            if not tr.confirmed and tr.hits >= CONFIRM_HITS:
                tr.confirmed = True
                donor = handover_donor(tr, tracks, matched_idx) if handover else None
                if donor is not None:
                    tr.id = donor.id
                    tr.moving_evidence = max(tr.moving_evidence, donor.moving_evidence)
                    donor.coast = MAX_COAST + 1  # retired in the pass below

        alive = []
        for i, tr in enumerate(tracks):
            if i in matched_t:
                alive.append(tr)
                continue
            tr.window += 1
            if tr.confirmed:
                tr.coast += 1
                if tr.coast <= MAX_COAST:
                    alive.append(tr)
            elif tr.window < CONFIRM_WINDOW:
                alive.append(tr)
        tracks = alive

        if dedup:
            # suppressing a duplicate only at report time leaves both alive,
            # and the pair then trades the report back and forth, which is an
            # identity switch every time; retire the younger one instead
            tracks.sort(key=lambda t: -t.hits)
            merged = []
            for tr in tracks:
                # a pedestrian walking past a curb reflector shows the same
                # near zero Doppler as the curb, so only two tracks that are
                # both moving, and moving alike, count as one body
                if (tr.confirmed and tr.moving_evidence >= MOVING_EVIDENCE_FRAMES and any(
                        k.confirmed and k.moving_evidence >= MOVING_EVIDENCE_FRAMES
                        and math.hypot(tr.x - k.x, tr.y - k.y) <= MERGE_M
                        and math.hypot(tr.vx - k.vx, tr.vy - k.vy) <= MERGE_DV_MPS
                        and abs(tr.residual - k.residual) <= HANDOVER_VR_MPS for k in merged)):
                    continue
                merged.append(tr)
            tracks = merged

        for j, m in enumerate(meas):
            if j not in matched_m:
                # the Doppler residual of a mover is its own radial speed in
                # the world, which seeds the velocity along the line of sight
                vx0 = vy0 = 0.0
                if abs(m[4]) > MOVING_RESIDUAL_MPS:
                    r = max(math.hypot(m[0], m[1]), 1e-6)
                    vx0, vy0 = m[4] * m[0] / r, m[4] * m[1] / r
                tracks.append(Track(next_id, m[0], m[1], f, m[4], vx0, vy0))
                next_id += 1

        for tr in tracks:
            by_doppler = doppler_classify and abs(tr.residual) > MOVING_RESIDUAL_MPS
            by_flow = (flow_classify and tr.hits >= 4 and tr.speed() >=
                       MOVING_SPEED_MPS + MOVING_SPEED_PER_M * math.hypot(tr.x, tr.y))
            if by_doppler or by_flow:
                tr.moving_evidence = min(tr.moving_evidence + 1, 10)
            else:
                tr.moving_evidence = max(tr.moving_evidence - 1, 0)
        report = []
        for tr in tracks:
            if not tr.confirmed or tr.coast > MAX_COAST_REPORT:
                continue
            if classify and tr.moving_evidence < MOVING_EVIDENCE_FRAMES:
                continue
            # a coasted track predicted past the edge of the field of view
            # is an object that has left, not one that was missed
            if not in_fov(tr.x, tr.y):
                continue
            report.append(tr)
        if dedup:
            # two reported tracks on one spot are one body seen twice; the
            # longer established one speaks for it
            report.sort(key=lambda t: -t.hits)
            kept = []
            for tr in report:
                if all(math.hypot(tr.x - k.x, tr.y - k.y) > DUPLICATE_M for k in kept):
                    kept.append(tr)
            report = kept
        for tr in report:
            out_rows.append((f, tr.id, tr.x, tr.y))

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    with open(out_path, "w", newline="\n") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["frame", "track_id", "x", "y"])
        for row in out_rows:
            w.writerow([row[0], row[1], f"{row[2]:.4f}", f"{row[3]:.4f}"])
    return out_rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("det_path")
    ap.add_argument("out_path")
    ap.add_argument("--spec", default=None)
    args = ap.parse_args()
    mount = 3.0
    if args.spec and os.path.exists(args.spec):
        with open(args.spec) as f:
            mount = float(json.load(f)["mount_ahead_of_rotation_center_m"])
    run(args.det_path, args.out_path, mount_ahead_m=mount)


if __name__ == "__main__":
    main()
