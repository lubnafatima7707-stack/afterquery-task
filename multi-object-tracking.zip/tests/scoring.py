"""
CLEAR MOT style scoring shared by the verifier and the authoring evidence
scripts. Pairs predicted track rows to ground truth objects frame by frame,
preferring to keep each truth object's previous match alive when it is
still a valid pairing (this is what makes an ID switch mean something),
and falling back to an optimal Hungarian assignment among the rest.
"""
from collections import defaultdict

import numpy as np
from scipy.optimize import linear_sum_assignment

GATE_DIST_M = 3.0
MOSTLY_TRACKED_FRACTION = 0.7


def _by_frame(rows, id_key):
    out = defaultdict(dict)
    for r in rows:
        out[r["frame"]][r[id_key]] = (r["x"], r["y"])
    return out


def evaluate(pred_rows, truth_rows):
    """pred_rows: list of dict(frame, track_id, x, y).
    truth_rows: list of dict(frame, object_id, x, y).
    Returns a metrics dict.
    """
    truth_by_frame = _by_frame(truth_rows, "object_id")
    pred_by_frame = _by_frame(pred_rows, "track_id")
    frames = sorted(set(truth_by_frame) | set(pred_by_frame))

    prev_match = {}  # object_id -> track_id, from the previous frame it held
    hit_frames = defaultdict(int)   # object_id -> number of frames matched
    life_frames = defaultdict(int)  # object_id -> number of frames alive
    switch_frames = defaultdict(set)  # object_id -> frames where it switched

    total_truth = 0
    total_matched = 0
    total_fp = 0
    total_fn = 0
    total_switches = 0
    matched_dists = []

    for f in frames:
        truth = truth_by_frame.get(f, {})
        pred = pred_by_frame.get(f, {})
        for oid in truth:
            life_frames[oid] += 1
        total_truth += len(truth)

        matches = {}  # object_id -> track_id
        used_tracks = set()

        # keep a previous correspondence alive if it is still a valid pair
        for oid, tid in prev_match.items():
            if oid in truth and tid in pred and tid not in used_tracks:
                ox, oy = truth[oid]
                px, py = pred[tid]
                d = ((ox - px) ** 2 + (oy - py) ** 2) ** 0.5
                if d <= GATE_DIST_M:
                    matches[oid] = tid
                    used_tracks.add(tid)

        remaining_truth = [oid for oid in truth if oid not in matches]
        remaining_pred = [tid for tid in pred if tid not in used_tracks]
        if remaining_truth and remaining_pred:
            cost = np.zeros((len(remaining_truth), len(remaining_pred)))
            for i, oid in enumerate(remaining_truth):
                ox, oy = truth[oid]
                for j, tid in enumerate(remaining_pred):
                    px, py = pred[tid]
                    cost[i, j] = ((ox - px) ** 2 + (oy - py) ** 2) ** 0.5
            feasible = cost <= GATE_DIST_M
            big_cost = np.where(feasible, cost, 1e6)
            ri, ci = linear_sum_assignment(big_cost)
            for i, j in zip(ri, ci):
                if feasible[i, j]:
                    matches[remaining_truth[i]] = remaining_pred[j]

        for oid, tid in matches.items():
            ox, oy = truth[oid]
            px, py = pred[tid]
            matched_dists.append(((ox - px) ** 2 + (oy - py) ** 2) ** 0.5)
            hit_frames[oid] += 1
            if oid in prev_match and prev_match[oid] != tid:
                total_switches += 1
                switch_frames[oid].add(f)

        total_matched += len(matches)
        total_fp += len(pred) - len(matches)
        total_fn += len(truth) - len(matches)

        # an object with no valid match this frame has no correspondence
        # to carry forward; a fresh match may be made to any free track
        # next frame without that counting as a switch from nothing
        new_prev = {}
        for oid in truth:
            if oid in matches:
                new_prev[oid] = matches[oid]
        prev_match = new_prev

    mota = 1.0 - (total_fn + total_fp + total_switches) / max(total_truth, 1)
    motp = float(np.mean(matched_dists)) if matched_dists else float("inf")

    mostly_tracked = sum(
        1 for oid in life_frames
        if hit_frames[oid] / life_frames[oid] >= MOSTLY_TRACKED_FRACTION
    )
    n_objects = len(life_frames)

    return {
        "n_objects": n_objects,
        "total_truth_frames": total_truth,
        "total_matched": total_matched,
        "total_fp": total_fp,
        "total_fn": total_fn,
        "num_switches": total_switches,
        "mota": mota,
        "motp_m": motp,
        "mostly_tracked_fraction": mostly_tracked / max(n_objects, 1),
    }


def read_truth_csv(path):
    import csv
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    return [
        {"frame": int(r["frame"]), "object_id": r["object_id"],
         "x": float(r["x"]), "y": float(r["y"])}
        for r in rows
    ]
