#!/bin/bash
set -uo pipefail

mkdir -p /logs/verifier

cd /tests
python -m pytest -q -p no:cacheprovider --ctrf /logs/verifier/ctrf.json test_verify.py > /logs/verifier/pytest.log 2>&1
code=$?

if [ "$code" -eq 0 ]; then
  printf "1" > /logs/verifier/reward.txt
else
  printf "0" > /logs/verifier/reward.txt
fi

cat /logs/verifier/pytest.log
exit 0
