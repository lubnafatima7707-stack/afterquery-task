"""
Sealed verifier for multi-object-tracking. truth_tracks.csv is written by
the seeded generator in authoring/provenance before any detection noise or
clutter is added, and is baked into the verifier image only, never shipped
to the agent.
"""
import csv
import math

import pytest

import scoring

PRED_PATH = "/app/output/tracks.csv"
TRUTH_PATH = "/tests/truth_tracks.csv"

COLUMNS = ["frame", "track_id", "x", "y"]
N_FRAMES = 600

MIN_MOTA = 0.65
MAX_SWITCHES = 20
MIN_MOSTLY_TRACKED = 0.85


@pytest.fixture(scope="module")
def truth():
    return scoring.read_truth_csv(TRUTH_PATH)


@pytest.fixture(scope="module")
def pred():
    try:
        with open(PRED_PATH, newline="") as f:
            reader = csv.DictReader(f)
            header = reader.fieldnames or []
            rows = list(reader)
    except Exception as e:
        pytest.fail(f"could not read {PRED_PATH}: {e}")
    missing = [c for c in COLUMNS if c not in header]
    if missing:
        pytest.fail(f"tracks.csv is missing columns {missing}, header was {header}")
    out = []
    for i, r in enumerate(rows):
        try:
            frame = float(r["frame"])
            x = float(r["x"])
            y = float(r["y"])
        except (TypeError, ValueError):
            pytest.fail(f"row {i + 2} of tracks.csv is not numeric: {r}")
        if not (frame.is_integer() and 0 <= frame < N_FRAMES):
            pytest.fail(f"row {i + 2} has frame {r['frame']!r}, expected an integer 0 to {N_FRAMES - 1}")
        if not (math.isfinite(x) and math.isfinite(y)):
            pytest.fail(f"row {i + 2} has a non finite x or y: {r}")
        if r["track_id"] == "":
            pytest.fail(f"row {i + 2} has an empty track_id")
        out.append({"frame": int(frame), "track_id": r["track_id"], "x": x, "y": y})
    return out


@pytest.fixture(scope="module")
def metrics(pred, truth):
    return scoring.evaluate(pred, truth)


def test_output_is_well_formed(pred):
    assert len(pred) > 0, "tracks.csv has no rows"


def test_mota(metrics):
    assert metrics["mota"] >= MIN_MOTA, (
        f"MOTA is {metrics['mota']:.4f} (matched {metrics['total_matched']}, "
        f"false positives {metrics['total_fp']}, missed {metrics['total_fn']}, "
        f"switches {metrics['num_switches']}, out of {metrics['total_truth_frames']} "
        f"true object frames), need at least {MIN_MOTA}"
    )


def test_id_switches(metrics):
    assert metrics["num_switches"] <= MAX_SWITCHES, (
        f"{metrics['num_switches']} identity switches, at most {MAX_SWITCHES} allowed"
    )


def test_mostly_tracked(metrics):
    assert metrics["mostly_tracked_fraction"] >= MIN_MOSTLY_TRACKED, (
        f"only {metrics['mostly_tracked_fraction']:.4f} of true objects were tracked "
        f"for at least 70 percent of their own visible frames, need at least {MIN_MOSTLY_TRACKED}"
    )
