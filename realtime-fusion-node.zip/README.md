# realtime-fusion-node

A CUDA accelerated real time sensor fusion node ships with three concurrency defects. The
agent has to find and repair them so the node publishes a correct moving object list and holds
its 20 Hz deadline when the sensor drivers deliver frames in bursts.

## Difficulty

The perception is already written and works. What is broken is the plumbing, in three places
that produce no crash, no assertion, no CUDA error and no compiler warning, and that are all
invisible on the quiet development recording:

1. **Staging slot lifetime.** `StagingRing` in `src/staging.h` hands slots out on a bare
   rotation of two. During a delivery burst the ingest thread runs ahead of the worker, so the
   host memcpy of a later frame races the still pending upload of an earlier one, and the
   device buffer is overwritten before the kernels that read it have run. A whole frame of
   detections lands at positions the world never held.
2. **Pose at the wrong time.** `EgoSource` in `src/ego.h` offers only the newest pose, and the
   front ends use it to move measurements into the world frame. The error is the transport and
   queueing delay multiplied by the vehicle speed: a few tenths of a metre when the pipeline is
   idle, several metres once frames arrive in clumps. The visible result is that the roadside
   starts moving and the object list fills with things that are not there.
3. **Lock held across a batch.** The worker in `src/pipeline.cpp` takes the tracker mutex once
   and holds it for the whole drained batch, device synchronisations included, so the publisher
   is blocked exactly when the backlog is deepest and misses its slot.

The three interact. How deep the backlog gets sets how stale the pose is and how far the
producer runs ahead of the consumer, so repairing two of the three still fails, which the table
below shows. The data is synthetic and seeded: `authoring/provenance/gen_scene.py` draws the
ego path, the traffic and the roadside structure, then ray casts the lidar range image and
synthesises the radar detections from that scene, so truth comes from the simulator state and
never from a solver.

Neither image ships the recordings. Both regenerate them from their seeds at build time with
`make_workloads.py`, which compares every file against the hashes in its manifest and fails the
build on a mismatch. That keeps each Docker build context down to source code, and it means the
hashes in `environment/data/gen/manifest.json` and `tests/gen/manifest.json` are the record of
exactly which data the thresholds were calibrated on. To reproduce the evidence locally,
regenerate into a directory and point `authoring/evidence/evaluate.py` at it.

A GPU is genuinely required. The front ends are CUDA kernels, the sweep of 2048 candidate
ground planes walks the whole cloud, two of the three defects are host to device staging and
stream ordering defects that do not exist without a device, and the verifier compiles and runs
the agent's own CUDA sources.

## Reference solution

`solution/solve.sh` copies five files from `solution/fixed` over `/app/src` and rebuilds. Each
repair sits in the file that owns the concern:

- `staging.h`: a slot returns to the producer only through a free list the consumer pushes to
  once every copy and kernel reading it has retired on its stream. A producer that finds
  nothing free drops the frame instead of overwriting one still in flight, which is the right
  real time choice because blocking there only moves the backlog upstream.
- `ego.h`: the single latest pose becomes a short history published with release ordering, and
  the front ends ask for the pose at the frame's own capture stamp, interpolating between the
  two samples that bracket it.
- `pipeline.cpp`: every queued frame is still folded in, in order, but the tracker mutex is
  taken around each update instead of around the whole batch.

`solution/fixed/pipeline.{h,cpp}` are generated from the shipped sources by
`authoring/provenance/make_fixed.py` rather than maintained as a second copy, so the two cannot
drift. The three repairs sit behind guards that default to on, which is how the ablations below
are compiled.

## Verification

`tests/test_verify.py` rebuilds `/app/src` and `/app/CMakeLists.txt` with cmake inside the
verifier container, with no network, then replays each of six hidden recordings once through
the resulting binary. Those six are built into the verifier image from the seeds in
`tests/gen/manifest.json` and exist nowhere the agent can reach. It reads the child's stdout line by line and stamps each line with its own
monotonic clock, so publication lateness is measured outside the process and the node cannot
report its own timing. `/logs/verifier` is made root owned and mode 700 before pytest starts,
and the node is launched in its own session with its process group killed in a `finally` block,
because the verifier is compiling and running the agent's code.

Reported objects are paired to truth one to one per frame by Hungarian assignment on the
clearance between the reported point and the object footprint, zero anywhere on or inside the
body, inside a 2.0 m gate. A run passes only if all six recordings publish exactly one frame
per 20 Hz grid point and clear every bar.

| bar | value |
| --- | --- |
| recall | at least 0.68 |
| position error | at most 0.38 m |
| false objects per frame | at most 7.50 |
| lateness, 99th percentile | at most 0.050 s |
| lateness, worst frame | at most 0.300 s |

The 99th percentile is what separates a node that holds its cycle from one that does not: the
two correct builds never exceed 0.028 s over 18 runs each and the build with the lock repair
removed reaches 0.107 s. The worst single frame is kept only as a guard against a gross stall
and is set well clear of correct behaviour, because the independent repair produced one 0.134 s
outlier in 18 runs and one scheduling outlier in 480 frames is not evidence of anything.

Velocity error is measured and recorded in `metrics.json` but is deliberately not a bar. It
separates exactly the builds that position error and the false alarm rate already separate, and
its spread across recordings is wide enough (1.9 to 7.0 m/s for the reference) that any bar
tight enough to catch a broken build would also be close to a coin flip for a correct one.

Worst case over the six hidden recordings, every row produced by `tests/scoring.py` and
reproducible with `authoring/evidence/evaluate.py`. Both correct builds were additionally run
three times against each recording and each passed 18 of 18: the reference at worst 0.774
recall, 0.261 m, 5.41 false objects per frame and 0.028 s, the independent repair at worst
0.804, 0.326 m, 6.45 and 0.026 s:

| build | recall | position m | velocity m/s | false/frame | p99 s | max s | passed |
| --- | --- | --- | --- | --- | --- | --- | --- |
| reference | 0.801 | 0.236 | 6.505 | 5.42 | 0.022 | 0.041 | 6 of 6 |
| independent repair | 0.804 | 0.326 | 6.938 | 6.36 | 0.025 | 0.038 | 6 of 6 |
| as shipped | 0.727 | 0.487 | 10.709 | 19.34 | 1.221 | 1.460 | 0 of 6 |
| slot repair removed | 0.721 | 0.424 | 8.282 | 12.25 | 0.029 | 0.057 | 2 of 6 |
| pose repair removed | 0.669 | 0.574 | 11.205 | 24.86 | 0.053 | 0.091 | 0 of 6 |
| lock repair removed | 0.830 | 0.212 | 6.446 | 5.41 | 0.107 | 0.147 | 0 of 6 |
| shortcut baseline | 0.770 | 0.494 | 10.164 | 15.68 | 1.408 | 1.647 | 0 of 6 |

Every bar sits between the weaker of the two correct builds and the strongest broken one. The
independent repair is a second correct solution written differently end to end: slots come back
through a CUDA event recorded by the consumer rather than a free list, the pose lookup indexes a
table by timestamp rather than walking a ring, and the tracker is never locked at all because it
belongs to the worker thread, which publishes finished snapshots into a rotation the publisher
reads without taking anything. It is there so that no bar can be passed only by matching the
reference's tuning, and it earned its keep: widening the position bar from 0.32 m to 0.38 m was
the direct result of measuring it. A build that fails any recording fails the task, so the
removed slot repair clearing two of six is still a failure.

The shortcut baseline is the five minute fix, a `cudaStreamSynchronize` after every upload. It
does remove the torn frames and it still fails, because it leaves the pose lookup and the
publisher contention untouched and pays for the synchronisation in cycle time.
`authoring/evidence/cheat_attempts.md` records that and the other attempts the harness rejects.
