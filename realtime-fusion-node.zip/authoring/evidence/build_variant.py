"""Compose and compile one variant of the pipeline.

The shipped sources live in environment/data/app/src.  The reference repair lives
in solution/fixed and is copied over them.  Each of the three changes is behind a
guard, so any subset can be compiled and scored:

    python build_variant.py --fixes 111 --out build/ref        # the reference
    python build_variant.py --fixes 000 --out build/shipped    # as shipped
    python build_variant.py --fixes 011 --out build/no_slot     # D1 ablated
"""
import argparse
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
SHIPPED = os.path.join(ROOT, "environment", "data", "app", "src")
FIXED = os.path.join(ROOT, "solution", "fixed")
SOURCES = ["main.cpp", "pipeline.cpp", "tracker.cpp", "workload.cpp", "kernels.cu"]

VCVARS = r"C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat"


def compose(fixes, work, overlay=None):
    if os.path.isdir(work):
        shutil.rmtree(work)
    os.makedirs(work)
    for name in os.listdir(SHIPPED):
        shutil.copy2(os.path.join(SHIPPED, name), os.path.join(work, name))
    for name in os.listdir(FIXED):
        shutil.copy2(os.path.join(FIXED, name), os.path.join(work, name))
    if overlay:
        for name in os.listdir(overlay):
            shutil.copy2(os.path.join(overlay, name), os.path.join(work, name))
    return work


def build(work, fixes, out, arch):
    defs = ["-DFIX_SLOT_LIFETIME=%s" % fixes[0],
            "-DFIX_POSE_AT_CAPTURE=%s" % fixes[1],
            "-DFIX_DRAIN_POLICY=%s" % fixes[2]]
    srcs = [os.path.join(work, s) for s in SOURCES]
    if os.name == "nt":
        opt = ["-Xcompiler", "/O2"]
        exe = out + ".exe"
    else:
        opt = ["-Xcompiler", "-O2"]
        exe = out
    os.makedirs(os.path.dirname(os.path.abspath(exe)) or ".", exist_ok=True)
    cmd = ["nvcc", "-std=c++17", "-arch=%s" % arch] + opt + defs + \
          ["-I", work] + srcs + ["-o", exe]
    if os.name == "nt":
        joined = " ".join('"%s"' % c if " " in c else c for c in cmd)
        bat = os.path.join(work, "_build.bat")
        with open(bat, "w") as f:
            f.write('@echo off\r\ncall "%s" >nul 2>&1\r\n%s\r\n' % (VCVARS, joined))
        r = subprocess.run(["cmd", "/c", bat], capture_output=True, text=True)
    else:
        r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.stderr.write(r.stdout + "\n" + r.stderr + "\n")
        raise SystemExit("build failed for fixes=%s" % fixes)
    return exe


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fixes", default="111",
                    help="three digits: slot lifetime, pose at capture, drain policy")
    ap.add_argument("--out", required=True)
    ap.add_argument("--arch", default=os.environ.get("RTF_ARCH", "sm_75"))
    ap.add_argument("--work", default="")
    ap.add_argument("--overlay", default="", help="extra source layer copied last")
    args = ap.parse_args()
    if len(args.fixes) != 3 or any(c not in "01" for c in args.fixes):
        raise SystemExit("--fixes must be three characters from 01")
    tag = args.fixes + ("_" + os.path.basename(args.overlay.rstrip("/\\")) if args.overlay else "")
    work = args.work or os.path.join(HERE, "_work_" + tag)
    compose(args.fixes, work, args.overlay or None)
    exe = build(work, args.fixes, args.out, args.arch)
    print("built", exe, "fixes=" + args.fixes)


if __name__ == "__main__":
    main()
