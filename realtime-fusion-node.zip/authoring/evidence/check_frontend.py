"""Score the two sensor front ends on their own, before any tracking.

Takes the detection dump the node writes with --dump-detections and asks, per
frame, how many truth objects have a detection on or near their footprint and how
many detections sit on nothing.  A tracking problem and a detection problem look
identical in the published stream, so they are separated here.
"""
import argparse
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "tests"))
import scoring  # noqa: E402


def read_dump(path):
    frames = []
    cur = None
    for line in open(path):
        if line.startswith(("L ", "R ")):
            parts = line.split()
            cur = {"kind": parts[0], "t": float(parts[1]), "n": int(parts[2]),
                   "ego": (float(parts[3]), float(parts[4]), float(parts[5])),
                   "d": []}
            frames.append(cur)
        elif line.startswith("  ") and cur is not None:
            a = line.split()
            cur["d"].append((float(a[0]), float(a[1]), float(a[2]), float(a[3])))
    return frames


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dump", required=True)
    ap.add_argument("--workload", required=True)
    ap.add_argument("--gate", type=float, default=2.0)
    args = ap.parse_args()

    truth = scoring.load_truth(args.workload[:-4] + "_truth.npz")
    t_all = truth["t"]
    uniq = np.unique(t_all)

    frames = read_dump(args.dump)
    for kind, label in (("L", "lidar"), ("R", "radar")):
        sel = [f for f in frames if f["kind"] == kind]
        if not sel:
            continue
        cov, spur, ndet, nobj = 0, 0, 0, 0
        for f in sel:
            k = int(np.argmin(np.abs(uniq - f["t"])))
            if abs(uniq[k] - f["t"]) > 0.03:
                continue
            idx = np.where(t_all == uniq[k])[0]
            g = truth["graded"][idx].astype(bool)
            idx = idx[g]
            if len(idx) == 0:
                continue
            tx, ty = truth["x"][idx], truth["y"][idx]
            tyaw, tl, tw = truth["yaw"][idx], truth["length"][idx], truth["width"][idx]
            d = np.array(f["d"])
            nobj += len(idx)
            ndet += len(d)
            if len(d) == 0:
                continue
            m = scoring.box_distance(d[:, 0], d[:, 1], tx, ty, tyaw, tl, tw)
            cov += int((m.min(axis=0) <= args.gate).sum())
            spur += int((m.min(axis=1) > args.gate).sum())
        print("%-6s frames=%4d  detections/frame=%6.1f  truth covered=%.3f  "
              "detections on nothing/frame=%6.1f"
              % (label, len(sel), ndet / max(1, len(sel)), cov / max(1, nobj),
                 spur / max(1, len(sel))))


if __name__ == "__main__":
    main()
