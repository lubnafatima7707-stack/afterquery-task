"""Break one run down into the individual misses and spurious objects, with the
range, speed and class of each, so tuning is aimed at a measured cause."""
import argparse
import collections
import os
import sys

import numpy as np
from scipy.optimize import linear_sum_assignment

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "tests"))
import scoring  # noqa: E402

CLS = ["car", "van", "truck", "cyclist", "pedestrian"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--binary", required=True)
    ap.add_argument("--workload", required=True)
    args = ap.parse_args()

    truth = scoring.load_truth(args.workload[:-4] + "_truth.npz")
    duration = float(truth["duration"])
    res = scoring.run_node(args.binary, args.workload, 180.0)
    m = scoring.score(res, truth, duration)
    print(scoring.summarise(m), "" if m["ok"] else "FAIL " + m["reason"])

    t_all = truth["t"]
    order = np.argsort(t_all, kind="stable")
    ts = t_all[order]
    want = np.arange(int(round(duration * scoring.GRID_HZ))) / scoring.GRID_HZ
    starts = np.searchsorted(ts, want - 1e-6, "left")
    ends = np.searchsorted(ts, want + 1e-6, "right")
    seen = {int(round(s * scoring.GRID_HZ)): (a, o) for s, a, o in res.frames}

    miss_by_cls = collections.Counter()
    miss_rng = []
    miss_spd = []
    false_speed = []
    false_rng = []
    false_near = []
    hit_by_cls = collections.Counter()
    pub_speed = []

    for k in range(len(want)):
        if k not in seen:
            continue
        idx = order[starts[k]:ends[k]]
        tx, ty = truth["x"][idx], truth["y"][idx]
        tg = truth["graded"][idx].astype(bool)
        tc = truth["cls"][idx]
        tspd = np.hypot(truth["vx"][idx], truth["vy"][idx])
        tyaw, tlen, twid = truth["yaw"][idx], truth["length"][idx], truth["width"][idx]
        objs = seen[k][1]
        if not objs:
            for b in range(len(idx)):
                if tg[b]:
                    miss_by_cls[CLS[tc[b]]] += 1
            continue
        px = np.array([o[1] for o in objs])
        py = np.array([o[2] for o in objs])
        pv = np.hypot([o[3] for o in objs], [o[4] for o in objs])
        pub_speed.extend(pv.tolist())
        if len(idx) == 0:
            false_speed.extend(pv.tolist())
            continue
        d = scoring.box_distance(px, py, tx, ty, tyaw, tlen, twid)
        cost = np.where(d <= scoring.MATCH_GATE, d, 1e6)
        ri, ci = linear_sum_assignment(cost)
        paired_p, paired_t = set(), set()
        for a, b in zip(ri, ci):
            if cost[a, b] >= 1e6:
                continue
            paired_p.add(int(a))
            paired_t.add(int(b))
            if tg[b]:
                hit_by_cls[CLS[tc[b]]] += 1
        for b in range(len(idx)):
            if b in paired_t or not tg[b]:
                continue
            miss_by_cls[CLS[tc[b]]] += 1
            miss_spd.append(float(tspd[b]))
            miss_rng.append(float(d[:, b].min()) if len(px) else 99.0)
        for a in range(len(objs)):
            if a in paired_p:
                continue
            false_speed.append(float(pv[a]))
            false_near.append(float(d[a].min()))

    print("\nhits by class:  ", dict(hit_by_cls))
    print("misses by class:", dict(miss_by_cls))
    if miss_spd:
        q = np.percentile(miss_spd, [10, 50, 90])
        print("missed object speed p10/p50/p90: %.2f %.2f %.2f m/s" % tuple(q))
        q = np.percentile(miss_rng, [10, 50, 90])
        print("distance from a missed object to the nearest published one: "
              "%.2f %.2f %.2f m" % tuple(q))
    if false_speed:
        q = np.percentile(false_speed, [10, 50, 90])
        print("spurious object speed p10/p50/p90: %.2f %.2f %.2f m/s" % tuple(q))
        q = np.percentile(false_near, [10, 50, 90])
        print("distance from a spurious object to the nearest truth object: "
              "%.2f %.2f %.2f m" % tuple(q))
        print("spurious slower than 2 m/s: %.2f of them"
              % float(np.mean(np.array(false_speed) < 2.0)))
    if pub_speed:
        print("published objects per frame: %.1f, speed median %.2f"
              % (len(pub_speed) / max(1, len(seen)), float(np.median(pub_speed))))
    print("\nstderr tail:\n" + res.stderr_tail)


if __name__ == "__main__":
    main()
