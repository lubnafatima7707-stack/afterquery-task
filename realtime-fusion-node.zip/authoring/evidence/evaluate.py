"""Score every build of the pipeline against the hidden workloads and print the
table the thresholds were set from.

Every row is produced by tests/scoring.py, the code the verifier itself runs, and
the bars are read out of tests/test_verify.py rather than retyped here.

    python evaluate.py --workloads <dir> --group all --out results.json
"""
import argparse
import glob
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TESTS = os.path.abspath(os.path.join(HERE, "..", "..", "tests"))
sys.path.insert(0, TESTS)

import scoring  # noqa: E402
import build_variant  # noqa: E402


def load_bars():
    src = open(os.path.join(TESTS, "test_verify.py"), encoding="utf-8").read()
    ns = {}
    start = src.index("BARS = {")
    end = src.index("}", start) + 1
    exec(src[start:end], ns)
    return ns["BARS"]


VARIANTS = os.path.join(HERE, "variants")

# name -> (fixes, extra source layer, what it is)
BUILDS = {
    "reference":   ("111", None, "all three repairs, the shipped solution/fixed sources"),
    "independent": ("111", os.path.join(VARIANTS, "independent"),
                    "the same three repairs written a different way end to end"),
    "as_shipped":  ("000", None, "the environment exactly as the agent receives it"),
    "no_slot":     ("011", None, "staging slots recycled before the consumer reads them"),
    "no_pose":     ("101", None, "ego pose taken as newest instead of at capture time"),
    "no_lock":     ("110", None, "tracker held for a whole drained batch"),
    "shortcut":    ("000", os.path.join(VARIANTS, "shortcut"),
                    "synchronise after every upload and change nothing else"),
}
GROUPS = {
    "all": list(BUILDS),
    "correct": ["reference", "independent"],
    "ablate": ["no_slot", "no_pose", "no_lock"],
    "broken": ["as_shipped", "shortcut"],
}


def verdict(m, bars):
    if not m["ok"]:
        return ["run: " + m["reason"]]
    bad = []
    if m["coverage"] < bars["min_coverage"]:
        bad.append("coverage")
    if m["recall"] < bars["min_recall"]:
        bad.append("recall")
    if m["pos_rmse"] > bars["max_pos_rmse"]:
        bad.append("position")
    if m["false_per_frame"] > bars["max_false_per_frame"]:
        bad.append("false")
    if m["late_p99"] > bars["max_late_p99"]:
        bad.append("late_p99")
    if m["late_max"] > bars["max_late_max"]:
        bad.append("late_max")
    return bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workloads", required=True)
    ap.add_argument("--group", default="all", choices=sorted(GROUPS))
    ap.add_argument("--repeat", type=int, default=1)
    ap.add_argument("--builds", default="")
    ap.add_argument("--arch", default=os.environ.get("RTF_ARCH", "sm_75"))
    ap.add_argument("--bindir", default=os.path.join(HERE, "_bin"))
    ap.add_argument("--timeout", type=float, default=180.0)
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    bars = load_bars()
    names = args.builds.split(",") if args.builds else GROUPS[args.group]
    files = sorted(glob.glob(os.path.join(args.workloads, "*.bin")))
    if not files:
        raise SystemExit("no workloads in " + args.workloads)
    os.makedirs(args.bindir, exist_ok=True)

    rows = []
    for name in names:
        fixes, overlay, what = BUILDS[name]
        work = os.path.join(args.bindir, "_src_" + name)
        build_variant.compose(fixes, work, overlay)
        exe = build_variant.build(work, fixes, os.path.join(args.bindir, name), args.arch)
        for path in files:
            truth = scoring.load_truth(path[:-4] + "_truth.npz")
            duration = float(truth["duration"])
            for rep in range(args.repeat):
                res = scoring.run_node(exe, path, args.timeout)
                m = scoring.score(res, truth, duration)
                m["build"] = name
                m["fixes"] = fixes
                m["workload"] = os.path.basename(path)[:-4]
                m["rep"] = rep
                m["fails"] = verdict(m, bars)
                rows.append(m)
                print("%-11s %-11s rep%d  %s  %s"
                      % (name, m["workload"], rep, scoring.summarise(m),
                         ("PASS" if not m["fails"] else "FAIL " + ",".join(m["fails"]))))
                sys.stdout.flush()

    print("\n%-11s %7s %7s %7s %7s %8s %8s   %s"
          % ("build", "recall", "pos", "vel", "false", "p99", "max", "worst case"))
    summary = []
    for name in names:
        sel = [r for r in rows if r["build"] == name]
        ok = [r for r in sel if r["ok"]]
        if not ok:
            print("%-11s  every run failed to produce a scoreable stream" % name)
            continue
        s = dict(build=name, fixes=BUILDS[name][0], what=BUILDS[name][2],
                 runs=len(sel),
                 recall=min(r["recall"] for r in ok),
                 pos=max(r["pos_rmse"] for r in ok),
                 vel=max(r["vel_rmse"] for r in ok),
                 false=max(r["false_per_frame"] for r in ok),
                 p99=max(r["late_p99"] for r in ok),
                 late=max(r["late_max"] for r in ok),
                 passed=sum(1 for r in sel if not r["fails"]))
        summary.append(s)
        print("%-11s %7.3f %7.3f %7.3f %7.2f %8.3f %8.3f   %d of %d pass"
              % (name, s["recall"], s["pos"], s["vel"], s["false"], s["p99"],
                 s["late"], s["passed"], s["runs"]))
    print("\nbars:", json.dumps(bars))
    if args.out:
        with open(args.out, "w", newline="\n") as f:
            json.dump({"bars": bars, "rows": rows, "summary": summary}, f, indent=1)
        print("wrote", args.out)


if __name__ == "__main__":
    main()
