# Measured scores

Worst case over 6 hidden recordings, one run each, scored by tests/scoring.py.

| build | recall | position m | velocity m/s | false/frame | late p99 s | late max s | runs passed |
| --- | --- | --- | --- | --- | --- | --- | --- |
| reference | 0.801 | 0.236 | 6.505 | 5.42 | 0.022 | 0.041 | 6 of 6 |
| independent | 0.804 | 0.326 | 6.938 | 6.36 | 0.025 | 0.038 | 6 of 6 |
| as_shipped | 0.727 | 0.487 | 10.709 | 19.34 | 1.221 | 1.460 | 0 of 6 |
| no_slot | 0.721 | 0.424 | 8.282 | 12.25 | 0.029 | 0.057 | 2 of 6 |
| no_pose | 0.669 | 0.574 | 11.205 | 24.86 | 0.053 | 0.091 | 0 of 6 |
| no_lock | 0.830 | 0.212 | 6.446 | 5.41 | 0.107 | 0.147 | 0 of 6 |
| shortcut | 0.770 | 0.494 | 10.164 | 15.68 | 1.408 | 1.647 | 0 of 6 |

| bar | value |
| --- | --- |
| max_false_per_frame | 7.5 |
| max_late_max | 0.3 |
| max_late_p99 | 0.05 |
| max_pos_rmse | 0.38 |
| min_coverage | 1.0 |
| min_recall | 0.68 |

Velocity error is reported in every row but is not a bar; see README.md.

## What each build is

- **reference** (fixes 111): all three repairs, the shipped solution/fixed sources
- **independent** (fixes 111): the same three repairs written a different way end to end
- **as_shipped** (fixes 000): the environment exactly as the agent receives it
- **no_slot** (fixes 011): staging slots recycled before the consumer reads them
- **no_pose** (fixes 101): ego pose taken as newest instead of at capture time
- **no_lock** (fixes 110): tracker held for a whole drained batch
- **shortcut** (fixes 000): synchronise after every upload and change nothing else

## Repeat stability

Three runs of every recording for each correct build, to check that the oracle passes every time rather than on average.

| build | runs | passed | worst recall | worst position | worst false/frame | worst p99 | worst max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| independent | 19 | 19 | 0.804 | 0.290 | 6.45 | 0.026 | 0.134 |
| reference | 18 | 18 | 0.774 | 0.261 | 5.41 | 0.028 | 0.038 |

## Every run

| build | recording | recall | position | velocity | false/frame | p99 | max | verdict |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| reference | hid_2201 | 0.894 | 0.199 | 5.034 | 2.89 | 0.022 | 0.022 | pass |
| reference | hid_2202 | 0.841 | 0.182 | 2.143 | 2.82 | 0.017 | 0.019 | pass |
| reference | hid_2203 | 0.890 | 0.196 | 4.215 | 3.49 | 0.016 | 0.041 | pass |
| reference | hid_2204 | 0.854 | 0.184 | 4.265 | 3.86 | 0.019 | 0.022 | pass |
| reference | hid_2205 | 0.927 | 0.146 | 3.551 | 5.42 | 0.022 | 0.025 | pass |
| reference | hid_2206 | 0.801 | 0.236 | 6.505 | 3.34 | 0.015 | 0.019 | pass |
| independent | hid_2201 | 0.910 | 0.232 | 6.232 | 2.94 | 0.016 | 0.038 | pass |
| independent | hid_2202 | 0.868 | 0.266 | 4.331 | 4.74 | 0.025 | 0.025 | pass |
| independent | hid_2203 | 0.877 | 0.212 | 4.878 | 4.25 | 0.016 | 0.019 | pass |
| independent | hid_2204 | 0.868 | 0.200 | 4.343 | 6.36 | 0.021 | 0.021 | pass |
| independent | hid_2205 | 0.916 | 0.139 | 3.845 | 5.67 | 0.025 | 0.028 | pass |
| independent | hid_2206 | 0.804 | 0.326 | 6.938 | 5.07 | 0.012 | 0.012 | pass |
| as_shipped | hid_2201 | 0.885 | 0.310 | 8.292 | 8.82 | 0.152 | 0.391 | fail false, late_p99, late_max |
| as_shipped | hid_2202 | 0.818 | 0.425 | 9.518 | 19.34 | 0.879 | 1.104 | fail position, false, late_p99, late_max |
| as_shipped | hid_2203 | 0.888 | 0.359 | 8.991 | 9.43 | 0.132 | 0.244 | fail false, late_p99 |
| as_shipped | hid_2204 | 0.805 | 0.487 | 10.709 | 17.61 | 1.160 | 1.400 | fail position, false, late_p99, late_max |
| as_shipped | hid_2205 | 0.944 | 0.171 | 4.116 | 9.69 | 0.101 | 0.188 | fail false, late_p99 |
| as_shipped | hid_2206 | 0.727 | 0.465 | 8.733 | 9.08 | 1.221 | 1.460 | fail position, false, late_p99, late_max |
| no_slot | hid_2201 | 0.881 | 0.126 | 5.537 | 7.18 | 0.028 | 0.028 | pass |
| no_slot | hid_2202 | 0.776 | 0.424 | 7.293 | 12.25 | 0.029 | 0.050 | fail position, false |
| no_slot | hid_2203 | 0.859 | 0.326 | 8.282 | 11.00 | 0.028 | 0.057 | fail false |
| no_slot | hid_2204 | | | | | | | did not score: run took 36.1 s, longer than the replay plus tail budget |
| no_slot | hid_2205 | 0.928 | 0.132 | 4.867 | 10.78 | 0.022 | 0.054 | fail false |
| no_slot | hid_2206 | 0.721 | 0.369 | 8.227 | 7.12 | 0.026 | 0.044 | pass |
| no_pose | hid_2201 | 0.854 | 0.274 | 7.503 | 15.02 | 0.028 | 0.062 | fail false |
| no_pose | hid_2202 | 0.706 | 0.494 | 9.092 | 17.36 | 0.035 | 0.085 | fail position, false |
| no_pose | hid_2203 | 0.818 | 0.402 | 10.027 | 24.86 | 0.036 | 0.063 | fail position, false |
| no_pose | hid_2204 | 0.686 | 0.574 | 11.205 | 18.76 | 0.053 | 0.091 | fail position, false, late_p99 |
| no_pose | hid_2205 | 0.882 | 0.258 | 7.059 | 22.36 | 0.020 | 0.044 | fail false |
| no_pose | hid_2206 | 0.669 | 0.518 | 10.344 | 10.35 | 0.031 | 0.043 | fail recall, position, false |
| no_lock | hid_2201 | 0.902 | 0.109 | 4.216 | 2.90 | 0.089 | 0.138 | fail late_p99 |
| no_lock | hid_2202 | 0.851 | 0.110 | 2.064 | 3.31 | 0.103 | 0.113 | fail late_p99 |
| no_lock | hid_2203 | 0.893 | 0.210 | 4.925 | 3.56 | 0.088 | 0.138 | fail late_p99 |
| no_lock | hid_2204 | 0.867 | 0.212 | 5.418 | 3.98 | 0.097 | 0.134 | fail late_p99 |
| no_lock | hid_2205 | 0.925 | 0.115 | 3.145 | 5.41 | 0.073 | 0.110 | fail late_p99 |
| no_lock | hid_2206 | 0.830 | 0.204 | 6.446 | 3.77 | 0.107 | 0.147 | fail late_p99 |
| shortcut | hid_2201 | 0.897 | 0.284 | 5.781 | 7.09 | 0.138 | 0.250 | fail late_p99 |
| shortcut | hid_2202 | 0.770 | 0.429 | 9.916 | 14.94 | 1.408 | 1.647 | fail position, false, late_p99, late_max |
| shortcut | hid_2203 | 0.893 | 0.369 | 8.078 | 7.75 | 0.108 | 0.197 | fail false, late_p99 |
| shortcut | hid_2204 | 0.820 | 0.491 | 8.307 | 15.68 | 1.223 | 1.463 | fail position, false, late_p99, late_max |
| shortcut | hid_2205 | 0.930 | 0.184 | 5.138 | 9.19 | 0.085 | 0.172 | fail false, late_p99 |
| shortcut | hid_2206 | 0.772 | 0.494 | 10.164 | 14.07 | 0.314 | 0.554 | fail position, false, late_p99, late_max |
