"""Run one fusion_node build against a set of workloads and print the metrics
the verifier uses.  Scored by tests/scoring.py, the verifier's own code.

    python run_eval.py --binary build/fusion_node --workloads dir [--repeat 1]
"""
import argparse
import glob
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "tests"))

import scoring  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--binary", required=True)
    ap.add_argument("--workloads", required=True, help="directory of *.bin files")
    ap.add_argument("--repeat", type=int, default=1)
    ap.add_argument("--timeout", type=float, default=180.0)
    ap.add_argument("--label", default="run")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    files = sorted(glob.glob(os.path.join(args.workloads, "*.bin")))
    if not files:
        print("no workloads found in", args.workloads)
        return 1

    rows = []
    for path in files:
        truth = scoring.load_truth(path[:-4] + "_truth.npz")
        duration = float(truth["duration"])
        for rep in range(args.repeat):
            res = scoring.run_node(args.binary, path, args.timeout)
            m = scoring.score(res, truth, duration)
            m["workload"] = os.path.basename(path)[:-4]
            m["rep"] = rep
            rows.append(m)
            print("%-14s rep%d  %s  %s" % (m["workload"], rep, scoring.summarise(m),
                                           ("" if m["ok"] else "FAIL: " + m["reason"])))
            sys.stdout.flush()

    good = [r for r in rows if r["ok"]]
    if good:
        def agg(key, fn):
            return fn([r[key] for r in good])
        print("\n%s: n=%d  recall mean=%.3f worst=%.3f | rmse mean=%.3f worst=%.3f | "
              "false/frame mean=%.2f worst=%.2f | late_p99 worst=%.3f | cover worst=%.3f"
              % (args.label, len(good),
                 agg("recall", lambda v: sum(v) / len(v)), agg("recall", min),
                 agg("pos_rmse", lambda v: sum(v) / len(v)), agg("pos_rmse", max),
                 agg("false_per_frame", lambda v: sum(v) / len(v)),
                 agg("false_per_frame", max),
                 agg("late_p99", max), agg("coverage", min)))
    if args.out:
        with open(args.out, "w", newline="\n") as f:
            json.dump({"label": args.label, "rows": rows}, f, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
