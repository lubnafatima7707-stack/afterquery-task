// Independent repair, pose at capture time.
//
// The reference walks a ring backwards looking for the bracketing pair.  Because
// localisation runs at a fixed 100 Hz, this version indexes straight into a table
// by timestamp instead, which needs no search at all, and validates the entry it
// landed on before using it.
#pragma once

#include <atomic>

#include "rtf.h"

namespace rtf {

class EgoSource {
 public:
  static constexpr int kN = 1024;
  static constexpr double kRate = 100.0;

  void publish(const OdomRec& r) {
    long long k = static_cast<long long>(llround(r.t_capture * kRate));
    Slot& s = buf_[static_cast<size_t>(k % kN + kN) % kN];
    s.seq.store(0, std::memory_order_release);
    s.key = k;
    s.p.t = r.t_capture;
    s.p.x = r.x;
    s.p.y = r.y;
    s.p.yaw = r.yaw;
    s.p.vx = r.vx;
    s.p.vy = r.vy;
    s.p.w = r.w;
    s.seq.store(1, std::memory_order_release);
    newest_.store(k, std::memory_order_release);
  }

  bool valid() const { return newest_.load(std::memory_order_acquire) > kNone; }

  Pose latest() const {
    Pose p;
    long long k = newest_.load(std::memory_order_acquire);
    if (k > kNone) read(k, &p);
    return p;
  }

  bool at(double t, Pose* out) const {
    long long newest = newest_.load(std::memory_order_acquire);
    if (newest <= kNone) return false;
    long long k = static_cast<long long>(std::floor(t * kRate));
    if (k >= newest) {
      Pose hi;
      if (!read(newest, &hi)) return false;
      double dt = t - hi.t;
      if (dt > 0.5) dt = 0.5;
      if (dt < 0.0) dt = 0.0;
      *out = hi;
      out->t = t;
      out->x = hi.x + hi.vx * static_cast<float>(dt);
      out->y = hi.y + hi.vy * static_cast<float>(dt);
      out->yaw = hi.yaw + hi.w * static_cast<float>(dt);
      return true;
    }
    if (k < newest - (kN - 8)) k = newest - (kN - 8);
    Pose lo, hi;
    if (!read(k, &lo) || !read(k + 1, &hi)) {
      *out = latest();
      return true;
    }
    double span = hi.t - lo.t;
    float f = (span > 1e-9) ? static_cast<float>((t - lo.t) / span) : 0.f;
    if (f < 0.f) f = 0.f;
    if (f > 1.f) f = 1.f;
    out->t = t;
    out->x = lo.x + f * (hi.x - lo.x);
    out->y = lo.y + f * (hi.y - lo.y);
    out->yaw = lo.yaw + f * wrap_pi(hi.yaw - lo.yaw);
    out->vx = lo.vx + f * (hi.vx - lo.vx);
    out->vy = lo.vy + f * (hi.vy - lo.vy);
    out->w = lo.w + f * (hi.w - lo.w);
    return true;
  }

 private:
  static constexpr long long kNone = -1000000000LL;

  struct Slot {
    std::atomic<int> seq{0};
    long long key = kNone;
    Pose p{};
  };

  bool read(long long k, Pose* out) const {
    const Slot& s = buf_[static_cast<size_t>(k % kN + kN) % kN];
    if (s.seq.load(std::memory_order_acquire) != 1) return false;
    if (s.key != k) return false;
    *out = s.p;
    return s.seq.load(std::memory_order_acquire) == 1 && s.key == k;
  }

  mutable Slot buf_[kN];
  std::atomic<long long> newest_{kNone};
};

}  // namespace rtf
