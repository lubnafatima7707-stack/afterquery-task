#include "pipeline.h"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <vector>

namespace rtf {
namespace {

using clk = std::chrono::steady_clock;

// Single link grouping of the surviving radar detections.
struct UF {
  std::vector<int> p;
  explicit UF(int n) : p(n) {
    for (int i = 0; i < n; ++i) p[i] = i;
  }
  int find(int a) {
    while (p[a] != a) {
      p[a] = p[p[a]];
      a = p[a];
    }
    return a;
  }
  void join(int a, int b) {
    a = find(a);
    b = find(b);
    if (a != b) p[b] = a;
  }
};

}  // namespace

double Pipeline::now() const {
  return std::chrono::duration<double>(clk::now() - t0_).count();
}

void Pipeline::sleep_until_replay(double t) const {
  auto target = t0_ + std::chrono::duration_cast<clk::duration>(
                          std::chrono::duration<double>(t));
  auto coarse = target - std::chrono::milliseconds(2);
  while (clk::now() < coarse) {
    if (!running_.load()) return;
    auto step = std::min(coarse, clk::now() + std::chrono::milliseconds(5));
    std::this_thread::sleep_until(step);
  }
  while (clk::now() < target) std::this_thread::yield();
}

bool Pipeline::init(const std::string& path, bool stats, const std::string& dump,
                    std::string* err) {
  stats_ = stats;
  if (!dump.empty()) dump_ = std::fopen(dump.c_str(), "w");
  if (!load_workload(path, &wl_, err)) return false;
  CUDA_CHECK(cudaStreamCreate(&stream_lidar_));
  CUDA_CHECK(cudaStreamCreate(&stream_radar_));
  lidar_ring_.init(kLidarPts);
  radar_ring_.init(static_cast<size_t>(kMaxRadarDet) * 4);
  lw_.init();
  rw_.init();
  dets_.reserve(kMaxDet + 512);
  pub_.reserve(kTrackCap);
  // Warm the driver and the kernels up so the first replayed frame does not
  // pay for context creation.
  const int warm_slot = lidar_ring_.acquire();
  CUDA_CHECK(cudaMemsetAsync(lidar_ring_.dev(warm_slot), 0,
                             kLidarPts * sizeof(uint16_t), stream_lidar_));
  DevPose warm{0.f, 0.f, 0.f, 0.f, 0.f};
  float daz = static_cast<float>((wl_.az_max - wl_.az_min) / wl_.cols);
  float del = static_cast<float>((wl_.el_max - wl_.el_min) / wl_.beams);
  lidar_frontend(&lw_, lidar_ring_.dev(warm_slot), warm,
                 static_cast<float>(wl_.az_min), daz, static_cast<float>(wl_.el_min),
                 del, 0.f, 0.f, stream_lidar_);
  CUDA_CHECK(cudaStreamSynchronize(stream_lidar_));
  lidar_ring_.release(warm_slot, stream_lidar_);
  return true;
}

void Pipeline::odom_thread() {
  for (const auto& r : wl_.odom) {
    if (!running_.load()) return;
    sleep_until_replay(r.t_deliver);
    ego_.publish(r);
  }
}

void Pipeline::radar_thread() {
  for (const auto& r : wl_.radar) {
    if (!running_.load()) return;
    sleep_until_replay(r.t_deliver);
    uint32_t n = std::min<uint32_t>(r.n, kMaxRadarDet);
    int slot = radar_ring_.acquire();
    std::memcpy(radar_ring_.host(slot), wl_.radar_blob.data() + size_t(r.offset) * 4,
                size_t(n) * 4 * sizeof(float));
    radar_ring_.submit(slot, size_t(n) * 4, stream_radar_);
    Item it{1, slot, n, r.t_capture, seq_.fetch_add(1)};
    {
      std::lock_guard<std::mutex> lk(q_mu_);
      q_.push_back(it);
    }
    q_cv_.notify_one();
  }
}

void Pipeline::lidar_thread() {
  for (const auto& r : wl_.lidar) {
    if (!running_.load()) return;
    sleep_until_replay(r.t_deliver);
    int slot = lidar_ring_.acquire();
    std::memcpy(lidar_ring_.host(slot), wl_.lidar_blob.data() + r.offset,
                size_t(kLidarPts) * sizeof(uint16_t));
    lidar_ring_.submit(slot, kLidarPts, stream_lidar_);
    Item it{2, slot, 0, r.t_capture, seq_.fetch_add(1)};
    {
      std::lock_guard<std::mutex> lk(q_mu_);
      q_.push_back(it);
    }
    q_cv_.notify_one();
  }
}

void Pipeline::process_lidar(const Item& it) {
  Pose e;
  if (!ego_.at(it.t_capture, &e)) {
    lidar_ring_.release(it.slot, stream_lidar_);
    return;
  }
  DevPose pose{e.x, e.y, e.yaw, e.vx, e.vy};
  float ox = pose.x - kGridN * kGridRes * 0.5f;
  float oy = pose.y - kGridN * kGridRes * 0.5f;
  float daz = static_cast<float>((wl_.az_max - wl_.az_min) / wl_.cols);
  float del = static_cast<float>((wl_.el_max - wl_.el_min) / wl_.beams);
  lidar_frontend(&lw_, lidar_ring_.dev(it.slot), pose, static_cast<float>(wl_.az_min),
                 daz, static_cast<float>(wl_.el_min), del, ox, oy, stream_lidar_);
  CUDA_CHECK(cudaStreamSynchronize(stream_lidar_));
  lidar_ring_.release(it.slot, stream_lidar_);

  int n = *lw_.host_count;
  n = std::min(n, kMaxDet);
  dets_.clear();
  for (int i = 0; i < n; ++i) {
    float ea = lw_.host_det[i * 4 + 2];
    float eb = lw_.host_det[i * 4 + 3];
    float lo = std::min(ea, eb), hi = std::max(ea, eb);
    // Roadside structure merges into one long label and nothing on a road is
    // wider than a lane, so both extents have to look like a vehicle.
    if (hi > kVehicleLenMax || lo > kVehicleWidMax) continue;
    Det d{};
    d.x = lw_.host_det[i * 4 + 0];
    d.y = lw_.host_det[i * 4 + 1];
    d.len = std::max(1.0f, hi);
    d.wid = std::max(0.8f, lo);
    d.has_vr = 0;
    d.src = 0;
    dets_.push_back(d);
  }
  n_lidar_clusters_.store(static_cast<long long>(dets_.size()));
  if (dump_) {
    std::fprintf(dump_, "L %.4f %zu %.3f %.3f %.4f\n", it.t_capture, dets_.size(),
                 pose.x, pose.y, pose.yaw);
    for (const auto& d : dets_)
      std::fprintf(dump_, "  %.3f %.3f %.2f %.2f\n", d.x, d.y, d.len, d.wid);
  }
  tracker_.step(it.t_capture, dets_);
  refresh_snapshot(it.t_capture);
}

void Pipeline::process_radar(const Item& it) {
  Pose e;
  if (!ego_.at(it.t_capture, &e)) {
    radar_ring_.release(it.slot, stream_radar_);
    return;
  }
  DevPose pose{e.x, e.y, e.yaw, e.vx, e.vy};
  int n = static_cast<int>(it.n);
  radar_frontend(&rw_, radar_ring_.dev(it.slot), n, pose, stream_radar_);
  CUDA_CHECK(cudaStreamSynchronize(stream_radar_));
  radar_ring_.release(it.slot, stream_radar_);

  const float* xs = rw_.host_pack;
  const float* ys = rw_.host_pack + kMaxRadarDet;
  const float* vs = rw_.host_pack + 2 * kMaxRadarDet;
  const float* us = rw_.host_pack + 3 * kMaxRadarDet;
  const float* vsy = rw_.host_pack + 4 * kMaxRadarDet;
  const int* mov = rw_.host_flag;
  const int* nbr = rw_.host_flag + kMaxRadarDet;

  // Close in, a real object paints several detections, so an isolated one there
  // is clutter.  Past kRadarDenseRange even a vehicle returns a single detection,
  // and requiring company would throw the whole far field away.
  static thread_local std::vector<int> keep;
  keep.clear();
  for (int i = 0; i < n; ++i) {
    if (!mov[i]) continue;
    float dx = xs[i] - pose.x, dy = ys[i] - pose.y;
    float r = std::sqrt(dx * dx + dy * dy);
    if (nbr[i] >= kRadarMinNbr || r > kRadarDenseRange) keep.push_back(i);
  }

  const int k = static_cast<int>(keep.size());
  UF uf(k);
  for (int a = 0; a < k; ++a) {
    for (int b = a + 1; b < k; ++b) {
      float dx = xs[keep[a]] - xs[keep[b]];
      float dy = ys[keep[a]] - ys[keep[b]];
      float dv = vs[keep[a]] - vs[keep[b]];
      if (dx * dx + dy * dy < 2.2f * 2.2f && std::fabs(dv) < 2.0f) uf.join(a, b);
    }
  }
  struct Acc {
    float sx = 0, sy = 0, sv = 0, sux = 0, suy = 0;
    float xmin = 1e9f, xmax = -1e9f, ymin = 1e9f, ymax = -1e9f;
    int n = 0;
  };
  static thread_local std::vector<Acc> acc;
  acc.assign(k, Acc{});
  for (int a = 0; a < k; ++a) {
    int r = uf.find(a);
    int i = keep[a];
    Acc& A = acc[r];
    A.sx += xs[i]; A.sy += ys[i]; A.sv += vs[i];
    A.sux += us[i]; A.suy += vsy[i];
    A.xmin = std::min(A.xmin, xs[i]); A.xmax = std::max(A.xmax, xs[i]);
    A.ymin = std::min(A.ymin, ys[i]); A.ymax = std::max(A.ymax, ys[i]);
    A.n += 1;
  }
  dets_.clear();
  for (int a = 0; a < k; ++a) {
    const Acc& A = acc[a];
    if (A.n < 1) continue;
    float inv = 1.0f / A.n;
    float ux = A.sux * inv, uy = A.suy * inv;
    float nrm = std::sqrt(ux * ux + uy * uy);
    if (nrm < 1e-3f) continue;
    Det d{};
    d.x = A.sx * inv;
    d.y = A.sy * inv;
    d.vr = A.sv * inv;
    d.ux = ux / nrm;
    d.uy = uy / nrm;
    d.has_vr = 1;
    d.src = 1;
    d.len = std::max(0.8f, std::max(A.xmax - A.xmin, A.ymax - A.ymin));
    d.wid = std::max(0.6f, std::min(A.xmax - A.xmin, A.ymax - A.ymin));
    dets_.push_back(d);
  }
  n_radar_moving_.store(static_cast<long long>(keep.size()));
  n_radar_clusters_.store(static_cast<long long>(dets_.size()));
  if (dump_) {
    std::fprintf(dump_, "R %.4f %zu %.3f %.3f %.4f\n", it.t_capture, dets_.size(),
                 pose.x, pose.y, pose.yaw);
    for (const auto& d : dets_)
      std::fprintf(dump_, "  %.3f %.3f %.2f %.2f\n", d.x, d.y, d.vr, 0.0f);
  }
  tracker_.step(it.t_capture, dets_);
  refresh_snapshot(it.t_capture);
}

void Pipeline::refresh_snapshot(double t) {
  unsigned cur = snap_seq_.load(std::memory_order_relaxed);
  Snap& s = snaps_[(cur + 1) % kSnaps];
  static thread_local std::vector<PubObj> tmp;
  tracker_.snapshot(t, &tmp);
  s.t = t;
  s.n = static_cast<int>(std::min(tmp.size(), static_cast<size_t>(kTrackCap)));
  for (int i = 0; i < s.n; ++i) s.objs[i] = tmp[i];
  snap_seq_.store(cur + 1, std::memory_order_release);
}

void Pipeline::process(const Item& it) {
  if (it.kind == 2)
    process_lidar(it);
  else
    process_radar(it);
}

void Pipeline::worker_thread() {
  std::vector<Item> batch;
  while (running_.load()) {
    {
      std::unique_lock<std::mutex> lk(q_mu_);
      q_cv_.wait_for(lk, std::chrono::milliseconds(5),
                     [&] { return !q_.empty() || !running_.load(); });
      batch.assign(q_.begin(), q_.end());
      q_.clear();
    }
    if (batch.empty()) continue;
    deep_.store(static_cast<long long>(batch.size()));
    std::sort(batch.begin(), batch.end(),
              [](const Item& a, const Item& b) { return a.seq < b.seq; });
    for (const auto& it : batch) process(it);
    batch.clear();
  }
}

void Pipeline::publisher_thread() {
  const int n_slots = static_cast<int>(wl_.t_end / kPublishPeriod);
  std::string line;
  line.reserve(1 << 16);
  char buf[128];
  for (int k = 0; k < n_slots; ++k) {
    double stamp = k * kPublishPeriod;
    sleep_until_replay(stamp);
    if (!running_.load()) return;
    const Snap& snap = snaps_[snap_seq_.load(std::memory_order_acquire) % kSnaps];
    double age = stamp - snap.t;
    pub_.clear();
    for (int i = 0; i < snap.n; ++i) {
      PubObj o = snap.objs[i];
      o.x += o.vx * static_cast<float>(age);
      o.y += o.vy * static_cast<float>(age);
      pub_.push_back(o);
    }
    line.clear();
    std::snprintf(buf, sizeof(buf), "F %.4f %d", stamp, static_cast<int>(pub_.size()));
    line += buf;
    for (const auto& o : pub_) {
      std::snprintf(buf, sizeof(buf), " %d %.3f %.3f %.3f %.3f", o.id, o.x, o.y, o.vx,
                    o.vy);
      line += buf;
    }
    line += '\n';
    std::fwrite(line.data(), 1, line.size(), stdout);
    std::fflush(stdout);
    if (stats_ && (k % 20) == 0) {
      Tracker::HeldBack hb = tracker_.held_back();
      size_t ntrk = tracker_.size();
      std::fprintf(stderr,
                   "[stats] t=%.2f objects=%zu tracks=%zu drain=%lld "
                   "lidar_clusters=%lld radar_moving=%lld radar_clusters=%lld "
                   "held(unconf=%d stale=%d no_radar=%d still=%d) "
                   "assoc(dets=%d hit=%d new=%d blocked=%d)\n",
                   stamp, pub_.size(), ntrk, deep_.load(),
                   n_lidar_clusters_.load(), n_radar_moving_.load(),
                   n_radar_clusters_.load(), hb.unconfirmed, hb.stale,
                   hb.no_radar, hb.not_moving, hb.dets, hb.assoc, hb.born,
                   hb.blocked);
    }
  }
}

void Pipeline::run() {
  std::printf("READY\n");
  std::fflush(stdout);
  t0_ = clk::now();
  threads_.emplace_back(&Pipeline::odom_thread, this);
  threads_.emplace_back(&Pipeline::radar_thread, this);
  threads_.emplace_back(&Pipeline::lidar_thread, this);
  threads_.emplace_back(&Pipeline::worker_thread, this);
  threads_.emplace_back(&Pipeline::publisher_thread, this);
  threads_.back().join();       // the publisher owns the length of the run
  shutdown();
}

void Pipeline::shutdown() {
  if (!running_.exchange(false)) return;
  q_cv_.notify_all();
  for (auto& th : threads_)
    if (th.joinable()) th.join();
  if (dump_) {
    std::fclose(dump_);
    dump_ = nullptr;
  }
  std::printf("DONE\n");
  std::fflush(stdout);
  lidar_ring_.destroy();
  radar_ring_.destroy();
  lw_.destroy();
  rw_.destroy();
  if (stream_lidar_) cudaStreamDestroy(stream_lidar_);
  if (stream_radar_) cudaStreamDestroy(stream_radar_);
}

}  // namespace rtf
