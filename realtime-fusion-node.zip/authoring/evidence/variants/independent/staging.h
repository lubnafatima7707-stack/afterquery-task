// Independent repair, slot lifetime.
//
// Where the reference hands slots back through a free list, this version keeps a
// CUDA event per slot.  The consumer records the event on the sensor stream once
// it has queued everything that reads the slot, and a producer about to reuse
// that slot waits on it.  No frame is dropped: the producer blocks instead, which
// costs delivery latency on a burst but never loses a measurement.
#pragma once

#include "rtf.h"

namespace rtf {

template <class T, int kSlots>
class StagingRing {
 public:
  void init(size_t elems) {
    elems_ = elems;
    for (int i = 0; i < kSlots; ++i) {
      CUDA_CHECK(cudaHostAlloc(reinterpret_cast<void**>(&host_[i]),
                               elems * sizeof(T), cudaHostAllocDefault));
      CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&dev_[i]), elems * sizeof(T)));
      CUDA_CHECK(cudaEventCreateWithFlags(&done_[i], cudaEventDisableTiming));
      armed_[i] = false;
    }
  }

  void destroy() {
    for (int i = 0; i < kSlots; ++i) {
      if (host_[i]) cudaFreeHost(host_[i]);
      if (dev_[i]) cudaFree(dev_[i]);
      if (done_[i]) cudaEventDestroy(done_[i]);
      host_[i] = nullptr;
      dev_[i] = nullptr;
      done_[i] = nullptr;
    }
  }

  int acquire() {
    int s = next_;
    next_ = (next_ + 1) % kSlots;
    if (armed_[s].load(std::memory_order_acquire)) {
      CUDA_CHECK(cudaEventSynchronize(done_[s]));
      armed_[s].store(false, std::memory_order_release);
    }
    return s;
  }

  int try_acquire() { return acquire(); }

  // Consumer side: every read of dev(s) is queued, mark the slot reusable once
  // the stream reaches this point.
  void release(int s, cudaStream_t stream) {
    if (s < 0) return;
    CUDA_CHECK(cudaEventRecord(done_[s], stream));
    armed_[s].store(true, std::memory_order_release);
  }

  T* host(int s) { return host_[s]; }
  T* dev(int s) { return dev_[s]; }
  size_t elems() const { return elems_; }

  void submit(int s, size_t elems, cudaStream_t stream) {
    CUDA_CHECK(cudaMemcpyAsync(dev_[s], host_[s], elems * sizeof(T),
                               cudaMemcpyHostToDevice, stream));
  }

 private:
  T* host_[kSlots] = {};
  T* dev_[kSlots] = {};
  cudaEvent_t done_[kSlots] = {};
  std::atomic<bool> armed_[kSlots];
  size_t elems_ = 0;
  int next_ = 0;
};

}  // namespace rtf
