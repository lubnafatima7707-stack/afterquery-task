"""Turn results.json from evaluate.py into the table quoted in README.md."""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "results.json")
    dst = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "results.md")
    data = json.load(open(src))
    bars, rows, summary = data["bars"], data["rows"], data["summary"]
    n_wl = len({r["workload"] for r in rows})

    lines = []
    lines.append("# Measured scores\n")
    lines.append("Worst case over %d hidden recordings, one run each, scored by "
                 "tests/scoring.py.\n" % n_wl)
    lines.append("| build | recall | position m | velocity m/s | false/frame | "
                 "late p99 s | late max s | runs passed |")
    lines.append("| --- | --- | --- | --- | --- | --- | --- | --- |")
    for s in summary:
        lines.append("| %s | %.3f | %.3f | %.3f | %.2f | %.3f | %.3f | %d of %d |"
                     % (s["build"], s["recall"], s["pos"], s["vel"], s["false"],
                        s["p99"], s["late"], s["passed"], s["runs"]))
    lines.append("")
    lines.append("| bar | value |")
    lines.append("| --- | --- |")
    for k in sorted(bars):
        lines.append("| %s | %s |" % (k, bars[k]))
    lines.append("")
    lines.append("Velocity error is reported in every row but is not a bar; see README.md.")
    lines.append("")
    lines.append("## What each build is\n")
    for s in summary:
        lines.append("- **%s** (fixes %s): %s" % (s["build"], s["fixes"], s["what"]))
    lines.append("")
    rp = os.path.join(os.path.dirname(os.path.abspath(src)), "repeats.json")
    if os.path.isfile(rp):
        reps = json.load(open(rp))["rows"]
        lines.append("## Repeat stability\n")
        lines.append("Three runs of every recording for each correct build, to check that the "
                     "oracle passes every time rather than on average.\n")
        lines.append("| build | runs | passed | worst recall | worst position | "
                     "worst false/frame | worst p99 | worst max |")
        lines.append("| --- | --- | --- | --- | --- | --- | --- | --- |")
        for b in sorted({r["build"] for r in reps}):
            sel = [r for r in reps if r["build"] == b]
            lines.append("| %s | %d | %d | %.3f | %.3f | %.2f | %.3f | %.3f |"
                         % (b, len(sel), sum(1 for r in sel if not r["fails"]),
                            min(r["recall"] for r in sel),
                            max(r["pos_rmse"] for r in sel),
                            max(r["false_per_frame"] for r in sel),
                            max(r["late_p99"] for r in sel),
                            max(r["late_max"] for r in sel)))
        lines.append("")
    lines.append("## Every run\n")
    lines.append("| build | recording | recall | position | velocity | false/frame | "
                 "p99 | max | verdict |")
    lines.append("| --- | --- | --- | --- | --- | --- | --- | --- | --- |")
    for r in rows:
        if not r["ok"]:
            lines.append("| %s | %s | | | | | | | did not score: %s |"
                         % (r["build"], r["workload"], r["reason"]))
            continue
        lines.append("| %s | %s | %.3f | %.3f | %.3f | %.2f | %.3f | %.3f | %s |"
                     % (r["build"], r["workload"], r["recall"], r["pos_rmse"],
                        r["vel_rmse"], r["false_per_frame"], r["late_p99"],
                        r["late_max"],
                        "pass" if not r["fails"] else "fail " + ", ".join(r["fails"])))
    open(dst, "w", newline="\n").write("\n".join(lines) + "\n")
    print("wrote", dst)


if __name__ == "__main__":
    main()
