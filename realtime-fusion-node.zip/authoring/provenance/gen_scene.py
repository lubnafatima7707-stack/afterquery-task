"""Scene generator for the realtime-fusion-node task.

Writes a workload file (the sensor stream, replayed by the node in wall clock
time) and a separate truth file (object states on the 20 Hz grading grid).
Ground truth comes from the simulator state itself, never from any solver.

    python gen_scene.py --seed 4101 --profile heavy --out ../../tests/workloads/hid_4101
"""
import argparse
import math
import os
import struct

import numpy as np

MAGIC = b"RTFW0002"

# ---------------------------------------------------------------- sensor rig
SENSOR_H = 1.90            # m above the road plane
LIDAR_BEAMS = 64
LIDAR_COLS = 768
LIDAR_AZ_MIN = -math.pi / 2
LIDAR_AZ_MAX = math.pi / 2
LIDAR_EL_MIN = math.radians(-24.0)
LIDAR_EL_MAX = math.radians(6.0)
LIDAR_HZ = 10.0
LIDAR_RMAX = 120.0
RADAR_HZ = 20.0
RADAR_RMAX = 110.0
ODOM_HZ = 100.0
GRID_HZ = 20.0             # grading grid

GRADE_RMAX = 72.0
GRADE_AZ = math.radians(75.0)
KEEP_RMAX = 125.0
KEEP_AZ = math.radians(180.0)
MOVING_MIN = 2.00   # objects slower than this are an ignore region, not a miss

CLASS_DIMS = {
    "car": (4.60, 1.90, 1.52),
    "van": (5.40, 2.05, 2.25),
    "truck": (10.8, 2.55, 3.30),
    "cyclist": (1.80, 0.62, 1.72),
    "pedestrian": (0.62, 0.58, 1.74),
}
CLASS_RCS = {"car": 12.0, "van": 14.0, "truck": 22.0, "cyclist": 3.0, "pedestrian": 1.2}
CLASS_ID = {"car": 0, "van": 1, "truck": 2, "cyclist": 3, "pedestrian": 4}


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


# ---------------------------------------------------------------- ego motion
class Ego:
    """Smooth curved path with a speed profile.  The pose here is exact; the
    odometry records handed to the node carry a small measurement noise."""

    def __init__(self, rng, duration):
        self.duration = duration
        self.dt = 1.0 / 400.0
        n = int(duration / self.dt) + 400
        t = np.arange(n) * self.dt

        v = (24.0
             + 6.0 * np.sin(2 * math.pi * t / 17.0 + rng.uniform(0, 6.28))
             + 2.5 * np.sin(2 * math.pi * t / 5.3 + rng.uniform(0, 6.28)))
        brake_t = rng.uniform(0.35, 0.6) * duration
        v = v - 8.0 * np.exp(-((t - brake_t) ** 2) / (2 * 1.4 ** 2))
        v = np.clip(v, 9.0, 34.0)

        w = (0.16 * np.sin(2 * math.pi * t / 21.0 + rng.uniform(0, 6.28))
             + 0.08 * np.sin(2 * math.pi * t / 7.0 + rng.uniform(0, 6.28)))
        lc_t = rng.uniform(0.2, 0.8) * duration
        w = w + 0.26 * np.sin((t - lc_t) * 2.2) * np.exp(-((t - lc_t) ** 2) / (2 * 0.9 ** 2))

        yaw = np.cumsum(w) * self.dt
        x = np.cumsum(v * np.cos(yaw)) * self.dt
        y = np.cumsum(v * np.sin(yaw)) * self.dt
        self.t, self.v, self.w = t, v, w
        self.yaw_u = np.unwrap(yaw)
        self.x, self.y = x, y

    def at(self, ts):
        ts = np.atleast_1d(np.asarray(ts, dtype=float))
        return (np.interp(ts, self.t, self.x),
                np.interp(ts, self.t, self.y),
                np.interp(ts, self.t, self.yaw_u),
                np.interp(ts, self.t, self.v),
                np.interp(ts, self.t, self.w))

    def pose(self, ts):
        x, y, yaw, v, w = self.at(ts)
        return float(x[0]), float(y[0]), float(yaw[0]), float(v[0]), float(w[0])


# ------------------------------------------------------------------- objects
class Obj:
    def __init__(self, oid, cls, t0, t1, p0, vel, accel, lat_event):
        self.oid = oid
        self.cls = cls
        self.t0, self.t1 = t0, t1
        self.p0 = np.asarray(p0, dtype=float)
        self.vel = np.asarray(vel, dtype=float)
        self.accel = float(accel)
        self.lat_event = lat_event
        self.dims = CLASS_DIMS[cls]

    def state(self, t):
        dt = t - self.t0
        sp = math.hypot(self.vel[0], self.vel[1])
        head = math.atan2(self.vel[1], self.vel[0])
        along = sp * dt + 0.5 * self.accel * dt * dt
        spd = max(0.0, sp + self.accel * dt)
        lat, lat_rate = 0.0, 0.0
        if self.lat_event is not None:
            te, amp, wid = self.lat_event
            u = (t - te) / wid
            th = math.tanh(u)
            lat = amp * th
            lat_rate = amp * (1.0 - th * th) / wid
        ux, uy = math.cos(head), math.sin(head)
        nx, ny = -uy, ux
        x = self.p0[0] + ux * along + nx * lat
        y = self.p0[1] + uy * along + ny * lat
        vx = ux * spd + nx * lat_rate
        vy = uy * spd + ny * lat_rate
        yaw = math.atan2(vy, vx) if (vx * vx + vy * vy) > 1e-6 else head
        return x, y, vx, vy, yaw

    def alive(self, t):
        return self.t0 <= t <= self.t1


def build_objects(rng, ego, duration, n_target):
    objs = []
    oid = 1
    for _ in range(int(n_target)):
        t0 = rng.uniform(-3.0, duration * 0.8)
        t1 = min(duration + 1.0, t0 + rng.uniform(7.0, duration + 3.0))
        if t1 - t0 < 3.0:
            continue
        t_ref = max(0.0, t0)
        ex, ey, eyaw, ev, _ = ego.pose(t_ref)
        cls = str(rng.choice(["car", "car", "car", "van", "truck", "cyclist"],
                             p=[0.32, 0.22, 0.15, 0.13, 0.10, 0.08]))
        oncoming = bool(rng.random() < 0.34 and cls in ("car", "van", "truck"))
        ahead = rng.uniform(-22.0, 74.0)
        lateral = rng.uniform(-9.0, 9.0)
        if cls == "pedestrian":
            ahead = rng.uniform(5.0, 45.0)
            lateral = rng.uniform(-14.0, 14.0)
        px = ex + ahead * math.cos(eyaw) - lateral * math.sin(eyaw)
        py = ey + ahead * math.sin(eyaw) + lateral * math.cos(eyaw)
        if cls == "pedestrian":
            sp = rng.uniform(0.8, 1.9)
            head = eyaw + rng.uniform(1.0, 2.2) * float(rng.choice([-1.0, 1.0]))
        elif cls == "cyclist":
            sp = rng.uniform(3.5, 7.0)
            head = eyaw + rng.normal(0.0, 0.09)
        elif oncoming:
            sp = rng.uniform(14.0, 28.0)
            head = eyaw + math.pi + rng.normal(0.0, 0.05)
        else:
            sp = max(2.0, ev + rng.normal(0.0, 6.5))
            head = eyaw + rng.normal(0.0, 0.05)
        vel = (sp * math.cos(head), sp * math.sin(head))
        accel = rng.normal(0.0, 0.9) if cls in ("car", "van") else rng.normal(0.0, 0.3)
        lat_event = None
        if cls in ("car", "van", "truck") and rng.random() < 0.35:
            lat_event = (rng.uniform(t0, t1), rng.uniform(-3.6, 3.6), rng.uniform(1.2, 2.6))
        objs.append(Obj(oid, cls, t0, t1, (px, py), vel, accel, lat_event))
        oid += 1
    return objs


def build_static(rng, ego, duration, urban):
    boxes = []
    ts = np.arange(0.0, duration + 1.0, 0.5)
    xs, ys, yaws, _, _ = ego.at(ts)
    for k in range(len(ts)):
        nx, ny = -math.sin(yaws[k]), math.cos(yaws[k])
        for side in (1, -1):
            cx = xs[k] + side * 10.5 * nx
            cy = ys[k] + side * 10.5 * ny
            boxes.append((cx, cy, 0.45, yaws[k], 3.0, 0.16, 0.85))
        if k % 14 == 0:
            for side in (1, -1):
                cx = xs[k] + side * 12.5 * nx + rng.normal(0, 0.4)
                cy = ys[k] + side * 12.5 * ny + rng.normal(0, 0.4)
                boxes.append((cx, cy, 3.8, 0.0, 0.17, 0.17, 7.6))
        if urban and k % 8 == 0:
            for side in (1, -1):
                cx = xs[k] + side * 21.0 * nx
                cy = ys[k] + side * 21.0 * ny
                boxes.append((cx, cy, 4.5, yaws[k], 6.0, 3.0, 9.0))
        if k % 26 == 0 and rng.random() < 0.5:
            side = float(rng.choice([-1.0, 1.0]))
            cx = xs[k] + side * 13.6 * nx
            cy = ys[k] + side * 13.6 * ny
            boxes.append((cx, cy, 0.76, yaws[k], 2.3, 0.95, 0.76))
    return np.asarray(boxes, dtype=np.float64)


# ------------------------------------------------------------- lidar render
def _box_corners(cx, cy, cz, yaw, hl, hw, hh):
    c, s = math.cos(yaw), math.sin(yaw)
    out = np.empty((8, 3))
    k = 0
    for sx in (-1, 1):
        for sy in (-1, 1):
            for sz in (-1, 1):
                lx, ly, lz = sx * hl, sy * hw, sz * hh
                out[k] = (cx + c * lx - s * ly, cy + s * lx + c * ly, cz + lz)
                k += 1
    return out


def render_lidar(boxes, ex, ey, eyaw, az_grid, el_grid, rng):
    """Range image (beams, cols) in metres.  boxes rows are
    cx, cy, cz, yaw, half_length, half_width, half_height in world coordinates."""
    nb, nc = len(el_grid), len(az_grid)
    sin_el = np.sin(el_grid)[:, None]
    with np.errstate(divide="ignore", invalid="ignore"):
        ground = np.where(sin_el < -1e-4, -SENSOR_H / sin_el, np.inf)
    img = np.broadcast_to(ground, (nb, nc)).copy()
    img[img > LIDAR_RMAX] = np.inf

    az_world = az_grid + eyaw
    daz = az_grid[1] - az_grid[0]
    dele = el_grid[1] - el_grid[0]

    for b in boxes:
        cx, cy, cz, byaw, hl, hw, hh = b
        rel = _box_corners(cx, cy, cz, byaw, hl, hw, hh) - np.array([ex, ey, SENSOR_H])
        hor = np.hypot(rel[:, 0], rel[:, 1])
        if hor.min() > LIDAR_RMAX:
            continue
        ref = math.atan2(cy - ey, cx - ex)
        caz = ref + np.arctan2(np.sin(np.arctan2(rel[:, 1], rel[:, 0]) - ref),
                               np.cos(np.arctan2(rel[:, 1], rel[:, 0]) - ref))
        cel = np.arctan2(rel[:, 2], np.maximum(hor, 1e-3))
        c0 = int(math.floor((caz.min() - eyaw - az_grid[0]) / daz))
        c1 = int(math.ceil((caz.max() - eyaw - az_grid[0]) / daz))
        r0 = int(math.floor((cel.min() - el_grid[0]) / dele))
        r1 = int(math.ceil((cel.max() - el_grid[0]) / dele))
        c0, c1 = max(0, c0), min(nc - 1, c1)
        r0, r1 = max(0, r0), min(nb - 1, r1)
        if c1 < c0 or r1 < r0:
            continue
        sub_az = az_world[c0:c1 + 1]
        sub_el = el_grid[r0:r1 + 1]
        ce = np.cos(sub_el)[:, None]
        se = np.sin(sub_el)[:, None]
        dx = ce * np.cos(sub_az)[None, :]
        dy = ce * np.sin(sub_az)[None, :]
        dz = np.broadcast_to(se, dx.shape)
        cb, sb = math.cos(byaw), math.sin(byaw)
        ro = np.array([cb * (ex - cx) + sb * (ey - cy),
                       -sb * (ex - cx) + cb * (ey - cy),
                       SENSOR_H - cz])
        rd0 = cb * dx + sb * dy
        rd1 = -sb * dx + cb * dy
        rd2 = dz
        tmin = np.full(dx.shape, -np.inf)
        tmax = np.full(dx.shape, np.inf)
        for comp, o_c, h_c in ((rd0, ro[0], hl), (rd1, ro[1], hw), (rd2, ro[2], hh)):
            safe = np.where(np.abs(comp) < 1e-9, 1e-9, comp)
            ta = (-h_c - o_c) / safe
            tb = (h_c - o_c) / safe
            lo = np.minimum(ta, tb)
            hi = np.maximum(ta, tb)
            par = np.abs(comp) < 1e-9
            lo = np.where(par, np.where(np.abs(o_c) <= h_c, -np.inf, np.inf), lo)
            hi = np.where(par, np.where(np.abs(o_c) <= h_c, np.inf, -np.inf), hi)
            tmin = np.maximum(tmin, lo)
            tmax = np.minimum(tmax, hi)
        hit = (tmax >= np.maximum(tmin, 0.0)) & (tmin > 0.3) & (tmin < LIDAR_RMAX)
        blk = img[r0:r1 + 1, c0:c1 + 1]
        img[r0:r1 + 1, c0:c1 + 1] = np.where(hit & (tmin < blk), tmin, blk)

    out = img + rng.normal(0.0, 0.022, img.shape)
    out[rng.random(img.shape) < 0.035] = np.inf
    out[~np.isfinite(out)] = 0.0
    out[out < 0.0] = 0.0
    return out


# -------------------------------------------------------------- radar frame
def radar_frame(objs, static_boxes, ego, t, n_clutter, rng):
    ex, ey, eyaw, ev, ew = ego.pose(t)
    evx, evy = ev * math.cos(eyaw), ev * math.sin(eyaw)
    rows = []
    for ob in objs:
        if not ob.alive(t):
            continue
        ox, oy, ovx, ovy, oyaw = ob.state(t)
        dx, dy = ox - ex, oy - ey
        r = math.hypot(dx, dy)
        if r > RADAR_RMAX or r < 1.0:
            continue
        az = wrap(math.atan2(dy, dx) - eyaw)
        if abs(az) > math.radians(80.0):
            continue
        L, W, _ = ob.dims
        n_det = 2 if ob.cls == "cyclist" else max(2, int(round(4.0 * math.exp(-r / 60.0) + 1)))
        if r < 18.0 and ob.cls in ("car", "van", "truck"):
            n_det += 2
        for _ in range(n_det):
            sx = rng.uniform(-L / 2, L / 2)
            sy = rng.uniform(-W / 2, W / 2)
            px = ox + math.cos(oyaw) * sx - math.sin(oyaw) * sy
            py = oy + math.sin(oyaw) * sx + math.cos(oyaw) * sy
            ddx, ddy = px - ex, py - ey
            rr = math.hypot(ddx, ddy)
            aa = wrap(math.atan2(ddy, ddx) - eyaw)
            ux, uy = ddx / rr, ddy / rr
            vr = (ovx - evx) * ux + (ovy - evy) * uy
            sig_r = 0.045 + 0.0012 * rr
            rows.append((rr + rng.normal(0, sig_r),
                         aa + rng.normal(0, math.radians(0.32)),
                         vr + rng.normal(0, 0.055),
                         CLASS_RCS[ob.cls] * math.exp(rng.normal(0, 0.35))))
    obj_rows = np.asarray(rows, dtype=np.float32) if rows else np.zeros((0, 4), dtype=np.float32)

    # Clutter from roadside structure, road surface and spray.  Most of it is
    # stationary, so its radial velocity is the projection of the ego velocity;
    # a minority moves, which is what stops a naive Doppler split from working.
    n_static = int(n_clutter)
    if n_static <= 0:
        clut = np.zeros((0, 4), dtype=np.float32)
    else:
        u = rng.random(n_static)
        rr = 3.0 + (RADAR_RMAX - 3.5) * np.power(u, 0.75)
        aa = rng.uniform(-math.radians(80.0), math.radians(80.0), n_static)
        # bias a third of it onto the two roadside corridors
        side = rng.choice([-1.0, 1.0], n_static)
        lat = side * rng.normal(11.0, 2.2, n_static)
        onroad = rng.random(n_static) < 0.34
        aa = np.where(onroad, np.arctan2(lat, np.maximum(rr, 1.0)), aa)
        ux, uy = np.cos(aa + eyaw), np.sin(aa + eyaw)
        vr = -(evx * ux + evy * uy) + rng.normal(0, 0.07, n_static)
        # vegetation, rain and wheel spray carry a small Doppler of their own;
        # only the tail of that spread clears a stationary world test
        spread = rng.random(n_static) < 0.006
        vr = vr + np.where(spread, rng.normal(0.0, 1.3, n_static), 0.0)
        rcs = np.exp(rng.normal(0.4, 0.85, n_static))
        clut = np.stack([rr + rng.normal(0, 0.05, n_static),
                         aa + rng.normal(0, math.radians(0.32), n_static),
                         vr, rcs], axis=1).astype(np.float32)
        keep = (clut[:, 0] > 1.5) & (clut[:, 0] < RADAR_RMAX) & (np.abs(clut[:, 1]) < math.radians(80.0))
        clut = clut[keep]
    arr = np.concatenate([obj_rows, clut], axis=0) if len(clut) else obj_rows
    if len(arr) == 0:
        return np.zeros((0, 4), dtype=np.float32)
    rng.shuffle(arr, axis=0)
    return arr


# ------------------------------------------------------------- load profile
def clutter_at(t, duration, profile):
    """Radar detections contributed by static structure over time.  The heavy
    phase is the sustained load the node has to hold its deadline through."""
    warm, tail = 4.0, 3.0
    hot0, hot1 = warm, duration - tail
    if profile == "light":
        base, peak = 160.0, 420.0
    elif profile in ("heavy", "stress"):
        base, peak = 220.0, 2600.0
    else:
        base, peak = 200.0, 1500.0
    if t < hot0:
        return base
    if t > hot1:
        return base + (peak - base) * 0.18
    u = (t - hot0) / max(1e-6, hot1 - hot0)
    ramp = min(1.0, u / 0.12)
    wobble = 0.78 + 0.22 * math.sin(2 * math.pi * t / 2.7)
    return base + (peak - base) * ramp * wobble


def build_stalls(rng, duration, profile):
    """Intervals where the sensor drivers hand nothing over.

    A loaded host stalls its capture threads for a few tens of milliseconds at a
    time and then releases everything that piled up in one go, so frames arrive
    in bursts rather than on a clean period.  Both sensors share the stall: it is
    a property of the host, not of one device.
    """
    warm, tail = 4.0, 3.0
    if profile == "light":
        gap, span = 6.0, (0.05, 0.09)
    elif profile == "heavy":
        gap, span = 1.5, (0.30, 0.48)
    elif profile == "stress":
        gap, span = 0.9, (0.42, 0.64)
    else:
        gap, span = 3.0, (0.11, 0.20)
    stalls = []
    t = warm + rng.uniform(0.4, 1.4)
    while t < duration - tail:
        stalls.append((t, t + rng.uniform(*span)))
        t += rng.uniform(gap * 0.55, gap * 1.45)
    return stalls


def deliver(t_nom, stalls, rng):
    for a, b in stalls:
        if a <= t_nom < b:
            return b + float(rng.uniform(0.0004, 0.0035))
    return t_nom + float(rng.normal(0.0, 0.0015))


# ----------------------------------------------------------------- writing
def write_workload(path, recs, meta):
    with open(path, "wb") as f:
        f.write(MAGIC)
        f.write(struct.pack("<dd", meta["t_start"], meta["t_end"]))
        f.write(struct.pack("<IIII", meta["n_odom"], meta["n_radar"],
                            meta["n_lidar"], meta["n_rec"]))
        f.write(struct.pack("<II", LIDAR_BEAMS, LIDAR_COLS))
        f.write(struct.pack("<dddd", LIDAR_AZ_MIN, LIDAR_AZ_MAX,
                            LIDAR_EL_MIN, LIDAR_EL_MAX))
        f.write(struct.pack("<d", SENSOR_H))
        for kind, t, tc, payload in recs:
            f.write(struct.pack("<Bdd", kind, t, tc))
            if kind == 0:
                f.write(payload)
            elif kind == 1:
                f.write(struct.pack("<I", payload.shape[0]))
                f.write(payload.astype("<f4").tobytes(order="C"))
            else:
                f.write(payload.tobytes(order="C"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--profile", default="heavy",
                    choices=["light", "medium", "heavy", "stress"])
    ap.add_argument("--duration", type=float, default=24.0)
    ap.add_argument("--objects", type=int, default=34)
    ap.add_argument("--urban", type=int, default=0)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    dur = args.duration
    ego = Ego(rng, dur)
    objs = build_objects(rng, ego, dur, args.objects)
    static = build_static(rng, ego, dur, bool(args.urban))
    stalls = build_stalls(rng, dur, args.profile)

    az_grid = LIDAR_AZ_MIN + (np.arange(LIDAR_COLS) + 0.5) * (LIDAR_AZ_MAX - LIDAR_AZ_MIN) / LIDAR_COLS
    el_grid = LIDAR_EL_MIN + (np.arange(LIDAR_BEAMS) + 0.5) * (LIDAR_EL_MAX - LIDAR_EL_MIN) / LIDAR_BEAMS

    recs = []
    n_odom = n_radar = n_lidar = 0

    for k in range(int(dur * ODOM_HZ) + 1):
        t = k / ODOM_HZ
        x, y, yaw, v, w = ego.pose(t)
        payload = struct.pack("<6f",
                              x + rng.normal(0, 0.012), y + rng.normal(0, 0.012),
                              yaw + rng.normal(0, 0.0006),
                              v * math.cos(yaw) + rng.normal(0, 0.01),
                              v * math.sin(yaw) + rng.normal(0, 0.01),
                              w + rng.normal(0, 0.0009))
        recs.append((0, t, t, payload))
        n_odom += 1

    for k in range(int(dur * RADAR_HZ)):
        t = k / RADAR_HZ
        dets = radar_frame(objs, static, ego, t, clutter_at(t, dur, args.profile), rng)
        t_deliver = deliver(t + 0.036, stalls, rng)
        recs.append((1, max(t + 1e-4, t_deliver), t, dets))
        n_radar += 1

    for k in range(int(dur * LIDAR_HZ)):
        t = k / LIDAR_HZ
        ex, ey, eyaw, _, _ = ego.pose(t)
        live = [(*o.state(t)[:2], 0.0, o.state(t)[4], o.dims[0] / 2, o.dims[1] / 2, o.dims[2] / 2)
                for o in objs if o.alive(t)]
        boxes = []
        for (ox, oy, _z, oyaw, hl, hw, hh) in live:
            boxes.append((ox, oy, hh, oyaw, hl, hw, hh))
        allb = np.asarray(boxes + [tuple(b) for b in static], dtype=np.float64) if boxes else static
        img = render_lidar(allb, ex, ey, eyaw, az_grid, el_grid, rng)
        cm = np.clip(np.round(img * 100.0), 0, 65535).astype("<u2")
        t_deliver = deliver(t + 0.048, stalls, rng)
        recs.append((2, max(t + 1e-4, t_deliver), t, cm))
        n_lidar += 1

    recs.sort(key=lambda r: (r[1], r[0]))
    meta = dict(t_start=0.0, t_end=dur, n_odom=n_odom, n_radar=n_radar,
                n_lidar=n_lidar, n_rec=len(recs))
    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    write_workload(args.out + ".bin", recs, meta)

    # ---- truth on the grading grid, in the world frame
    tid, tt, tx, ty, tvx, tvy, tyaw, tlen, twid, tcls = [], [], [], [], [], [], [], [], [], []
    tgraded = []
    n_grid = int(dur * GRID_HZ)
    for k in range(n_grid):
        t = k / GRID_HZ
        ex, ey, eyaw, _, _ = ego.pose(t)
        for ob in objs:
            if not ob.alive(t):
                continue
            ox, oy, ovx, ovy, oyaw = ob.state(t)
            dx, dy = ox - ex, oy - ey
            r = math.hypot(dx, dy)
            az = abs(wrap(math.atan2(dy, dx) - eyaw))
            if r > KEEP_RMAX or r < 1.0 or az > KEEP_AZ:
                continue
            speed = math.hypot(ovx, ovy)
            tgraded.append(1 if (r <= GRADE_RMAX and az <= GRADE_AZ
                                 and r >= 1.5 and speed >= MOVING_MIN) else 0)
            tid.append(ob.oid)
            tt.append(t)
            tx.append(ox)
            ty.append(oy)
            tvx.append(ovx)
            tvy.append(ovy)
            tyaw.append(oyaw)
            tlen.append(ob.dims[0])
            twid.append(ob.dims[1])
            tcls.append(CLASS_ID[ob.cls])
    np.savez_compressed(
        args.out + "_truth.npz",
        stall_start=np.asarray([a for a, _ in stalls]),
        stall_end=np.asarray([b for _, b in stalls]),
        t=np.asarray(tt, dtype=np.float64), oid=np.asarray(tid, dtype=np.int32),
        x=np.asarray(tx), y=np.asarray(ty), vx=np.asarray(tvx), vy=np.asarray(tvy),
        yaw=np.asarray(tyaw), length=np.asarray(tlen), width=np.asarray(twid),
        cls=np.asarray(tcls, dtype=np.int32),
        graded=np.asarray(tgraded, dtype=np.int32),
        duration=np.float64(dur), grid_hz=np.float64(GRID_HZ),
        seed=np.int64(args.seed), profile=np.str_(args.profile),
    )
    sz = os.path.getsize(args.out + ".bin") / 1e6
    print("wrote %s.bin  %.1f MB  recs=%d odom=%d radar=%d lidar=%d  truth_rows=%d"
          % (args.out, sz, len(recs), n_odom, n_radar, n_lidar, len(tt)))
    print("  graded rows: %d of %d" % (int(np.sum(tgraded)), len(tgraded)))


if __name__ == "__main__":
    main()
