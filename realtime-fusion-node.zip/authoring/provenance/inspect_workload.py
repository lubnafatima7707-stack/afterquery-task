"""Quick sanity dump of a generated workload: record mix, arrival spacing,
radar frame sizes, and one lidar range image summary."""
import math
import struct
import sys

import numpy as np

import gen_scene as G


def read(path):
    buf = open(path, "rb").read()
    assert buf[:8] == G.MAGIC, buf[:8]
    o = 8
    t0, t1 = struct.unpack_from("<dd", buf, o); o += 16
    n_odom, n_radar, n_lidar, n_rec = struct.unpack_from("<IIII", buf, o); o += 16
    beams, cols = struct.unpack_from("<II", buf, o); o += 8
    az0, az1, el0, el1 = struct.unpack_from("<dddd", buf, o); o += 32
    sh, = struct.unpack_from("<d", buf, o); o += 8
    recs = []
    for _ in range(n_rec):
        kind, t, tc = struct.unpack_from("<Bdd", buf, o); o += 17
        if kind == 0:
            p = np.frombuffer(buf, "<f4", 6, o); o += 24
        elif kind == 1:
            n, = struct.unpack_from("<I", buf, o); o += 4
            p = np.frombuffer(buf, "<f4", n * 4, o).reshape(n, 4); o += n * 16
        else:
            p = np.frombuffer(buf, "<u2", beams * cols, o).reshape(beams, cols); o += beams * cols * 2
        recs.append((kind, t, p))
    return dict(t0=t0, t1=t1, beams=beams, cols=cols, sh=sh,
                az=(az0, az1), el=(el0, el1), recs=recs)


if __name__ == "__main__":
    w = read(sys.argv[1])
    recs = w["recs"]
    for kind, name in ((0, "odom"), (1, "radar"), (2, "lidar")):
        ts = np.array([t for k, t, _ in recs if k == kind])
        d = np.diff(ts)
        print("%-6s n=%4d  dt mean=%.4f min=%.4f max=%.4f" %
              (name, len(ts), d.mean(), d.min(), d.max()))
    rn = np.array([p.shape[0] for k, _, p in recs if k == 1])
    print("radar dets/frame: min=%d med=%d max=%d" % (rn.min(), int(np.median(rn)), rn.max()))
    lid = [(t, p) for k, t, p in recs if k == 2]
    t, img = lid[len(lid) // 2]
    r = img.astype(np.float64) / 100.0
    valid = r > 0
    print("lidar t=%.2f valid=%.3f  r: p05=%.1f med=%.1f p95=%.1f max=%.1f" %
          (t, valid.mean(), np.percentile(r[valid], 5), np.median(r[valid]),
           np.percentile(r[valid], 95), r[valid].max()))
    # returns above the road plane are the object and structure hits
    el = G.LIDAR_EL_MIN + (np.arange(w["beams"]) + 0.5) * (G.LIDAR_EL_MAX - G.LIDAR_EL_MIN) / w["beams"]
    z = w["sh"] + r * np.sin(el)[:, None]
    above = valid & (z > 0.35)
    print("returns above 0.35 m: %.3f of valid  (n=%d)" % (above.sum() / valid.sum(), above.sum()))
    tr = np.load(sys.argv[1].replace(".bin", "_truth.npz"))
    tt = tr["t"]
    uniq, cnt = np.unique(tt, return_counts=True)
    print("graded objects per grid frame: min=%d mean=%.1f max=%d over %d frames"
          % (cnt.min(), cnt.mean(), cnt.max(), len(uniq)))
    print("distinct object ids graded: %d" % len(np.unique(tr["oid"])))
