"""Copy the grader's metric code into the agent visible tools directory.

The development scorer has to agree with the grader exactly, so rather than keep
a second implementation the one in tests/scoring.py is copied across verbatim.
Run this whenever tests/scoring.py changes.
"""
import os
import shutil

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
SRC = os.path.join(ROOT, "tests", "scoring.py")
DST = os.path.join(ROOT, "environment", "data", "app", "tools", "rtf_scoring.py")

HEADER = ('"""Metric code shared with the grader.  Copied verbatim from the\n'
          'verifier by authoring/provenance/make_devtools.py; do not edit here."""\n')


def main():
    os.makedirs(os.path.dirname(DST), exist_ok=True)
    body = open(SRC, encoding="utf-8").read()
    open(DST, "w", encoding="utf-8", newline="\n").write(HEADER + body)
    print("copied tests/scoring.py to", os.path.relpath(DST, ROOT))


if __name__ == "__main__":
    main()
