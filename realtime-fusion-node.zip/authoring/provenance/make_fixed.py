"""Derive solution/fixed/pipeline.{h,cpp} from the shipped sources.

The reference repair touches three places in the pipeline and nothing else, so
keeping a second hand edited copy of a 300 line file around only invites drift.
This script rewrites exactly those places, wrapping each in the guard that lets
authoring/evidence compile any subset of the three fixes.

    python make_fixed.py
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
SHIPPED = os.path.join(ROOT, "environment", "data", "app", "src")
FIXED = os.path.join(ROOT, "solution", "fixed")


def sub(text, old, new, label):
    if old not in text:
        sys.exit("make_fixed: could not find the %s site" % label)
    if text.count(old) != 1:
        sys.exit("make_fixed: the %s site is not unique" % label)
    return text.replace(old, new)


def build_header():
    h = open(os.path.join(SHIPPED, "pipeline.h"), encoding="utf-8").read()
    h = sub(h, '#include "ego.h"', '#include "ego.h"\n#include "fixups.h"', "header include")
    h = sub(h, """  StagingRing<uint16_t, 2> lidar_ring_;
  StagingRing<float, 2> radar_ring_;""",
            """  // Sized for the worst delivery burst the sensor drivers produce, so a burst
  // costs latency instead of a frame.
#if FIX_SLOT_LIFETIME
  StagingRing<uint16_t, 5> lidar_ring_;
  StagingRing<float, 8> radar_ring_;
#else
  StagingRing<uint16_t, 2> lidar_ring_;
  StagingRing<float, 2> radar_ring_;
#endif""", "staging ring sizes")
    h = sub(h, "  std::atomic<long long> deep_{0};",
            "  std::atomic<long long> deep_{0};\n"
            "  std::atomic<long long> dropped_{0};\n"
            "", "counters")
    return h


def build_source():
    p = open(os.path.join(SHIPPED, "pipeline.cpp"), encoding="utf-8").read()
    p = sub(p, '#include "pipeline.h"', '#include "pipeline.h"\n\n#include "fixups.h"',
            "source include")
    # ---- producers take a slot that nothing is still reading, or drop the frame
    for sensor in ("radar", "lidar"):
        p = sub(p, "    int slot = %s_ring_.acquire();" % sensor,
                """#if FIX_SLOT_LIFETIME
    int slot = %s_ring_.try_acquire();
    if (slot < 0) {
      dropped_.fetch_add(1);
      continue;
    }
#else
    int slot = %s_ring_.acquire();
#endif""" % (sensor, sensor), "%s acquire" % sensor)

    # ---- the pose a frame is compensated with
    p = sub(p, """  // Odometry lands every 10 ms, so the newest pose is the vehicle state this
  // frame was taken at, to within one odometry period.
  Pose e = ego_.latest();""",
            """  // The pose the vehicle actually held when this frame was captured, not the
  // newest one to have arrived by the time the frame reached this stage.
  Pose e;
  if (!ego_.at(it.t_capture, &e)) {
    lidar_ring_.release(it.slot);
    return;
  }""", "lidar pose")
    p = sub(p, """void Pipeline::process_radar(const Item& it) {
  Pose e = ego_.latest();""",
            """void Pipeline::process_radar(const Item& it) {
  Pose e;
  if (!ego_.at(it.t_capture, &e)) {
    radar_ring_.release(it.slot);
    return;
  }""", "radar pose")

    # ---- hand the slot back once every read of it has retired
    p = sub(p, """  CUDA_CHECK(cudaStreamSynchronize(stream_lidar_));

  int n = *lw_.host_count;""",
            """  CUDA_CHECK(cudaStreamSynchronize(stream_lidar_));
  lidar_ring_.release(it.slot);

  int n = *lw_.host_count;""", "lidar release")
    p = sub(p, """  CUDA_CHECK(cudaStreamSynchronize(stream_radar_));

  const float* xs""",
            """  CUDA_CHECK(cudaStreamSynchronize(stream_radar_));
  radar_ring_.release(it.slot);

  const float* xs""", "radar release")

    # ---- the tracker is locked per update, not per drained batch
    p = p.replace("  tracker_.step(it.t_capture, dets_);\n}",
                  """#if FIX_DRAIN_POLICY
  std::lock_guard<std::mutex> lk(track_mu_);
#endif
  tracker_.step(it.t_capture, dets_);
}""")

    # ---- the tracker is locked per update, never for a whole drained batch
    p = sub(p, """    // Hold the tracker for the whole batch so the publisher never observes a
    // half applied set of updates.
    {
      std::lock_guard<std::mutex> lk(track_mu_);
      for (const auto& it : batch) process(it);
    }
    batch.clear();""",
            """#if FIX_DRAIN_POLICY
    // Every queued frame still gets folded in, in order.  What changes is that
    // the tracker is locked around each update instead of for the whole batch,
    // so a burst costs the publisher a few hundred microseconds rather than the
    // time it takes to work through everything that piled up.
    for (const auto& it : batch) process(it);
#else
    {
      std::lock_guard<std::mutex> lk(track_mu_);
      for (const auto& it : batch) process(it);
    }
#endif
    batch.clear();""", "drain policy")

    # ---- warm up has to return its slot too
    p = sub(p, """  CUDA_CHECK(cudaMemsetAsync(lidar_ring_.dev(0), 0, kLidarPts * sizeof(uint16_t),
                             stream_lidar_));""",
            """#if FIX_SLOT_LIFETIME
  const int warm_slot = lidar_ring_.try_acquire();
#else
  const int warm_slot = 0;
#endif
  CUDA_CHECK(cudaMemsetAsync(lidar_ring_.dev(warm_slot), 0,
                             kLidarPts * sizeof(uint16_t), stream_lidar_));""",
            "warm up slot")
    p = sub(p, """  lidar_frontend(&lw_, lidar_ring_.dev(0), warm, static_cast<float>(wl_.az_min), daz,
                 static_cast<float>(wl_.el_min), del, 0.f, 0.f, stream_lidar_);
  CUDA_CHECK(cudaStreamSynchronize(stream_lidar_));
  return true;""",
            """  lidar_frontend(&lw_, lidar_ring_.dev(warm_slot), warm,
                 static_cast<float>(wl_.az_min), daz, static_cast<float>(wl_.el_min),
                 del, 0.f, 0.f, stream_lidar_);
  CUDA_CHECK(cudaStreamSynchronize(stream_lidar_));
  lidar_ring_.release(warm_slot);
  return true;""", "warm up frontend")

    return p


def main():
    os.makedirs(FIXED, exist_ok=True)
    open(os.path.join(FIXED, "pipeline.h"), "w", encoding="utf-8", newline="\n").write(build_header())
    open(os.path.join(FIXED, "pipeline.cpp"), "w", encoding="utf-8", newline="\n").write(build_source())
    print("regenerated solution/fixed/pipeline.h and pipeline.cpp from the shipped sources")


if __name__ == "__main__":
    main()
