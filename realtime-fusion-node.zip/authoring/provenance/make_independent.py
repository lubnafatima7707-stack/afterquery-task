"""Derive the independent repair of pipeline.{h,cpp} from the shipped sources.

This is a second, structurally different correct solution, used only to calibrate
the thresholds: a bar that the reference clears but this does not is a bar that
is measuring the reference's tuning rather than whether the job was done.

It differs from solution/fixed in all three places.  Slots come back through a
CUDA event recorded by the consumer rather than a free list, and a producer with
nothing free blocks instead of dropping.  The pose lookup indexes a table by
timestamp rather than walking a ring.  And the tracker is never locked at all:
it belongs to the worker thread, which publishes finished snapshots into a small
rotation that the publisher reads without taking anything.

    python make_independent.py
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
SHIPPED = os.path.join(ROOT, "environment", "data", "app", "src")
OUT = os.path.join(ROOT, "authoring", "evidence", "variants", "independent")


def sub(text, old, new, label):
    if text.count(old) != 1:
        sys.exit("make_independent: %s site appears %d times" % (label, text.count(old)))
    return text.replace(old, new)


def build_header():
    h = open(os.path.join(SHIPPED, "pipeline.h"), encoding="utf-8").read()
    h = sub(h, """  StagingRing<uint16_t, 2> lidar_ring_;
  StagingRing<float, 2> radar_ring_;""",
            """  StagingRing<uint16_t, 6> lidar_ring_;
  StagingRing<float, 10> radar_ring_;""", "ring sizes")
    h = sub(h, "  mutable std::mutex track_mu_;",
            """  // The tracker belongs to the worker thread.  Finished object lists go into
  // this rotation and the publisher reads the newest one without locking.
  static constexpr int kSnaps = 4;
  struct Snap {
    double t = 0.0;
    int n = 0;
    PubObj objs[kTrackCap];
  };
  Snap snaps_[kSnaps];
  std::atomic<unsigned> snap_seq_{0};""", "snapshot buffers")
    return h


def build_source():
    p = open(os.path.join(SHIPPED, "pipeline.cpp"), encoding="utf-8").read()

    p = sub(p, """  // Odometry lands every 10 ms, so the newest pose is the vehicle state this
  // frame was taken at, to within one odometry period.
  Pose e = ego_.latest();""",
            """  Pose e;
  if (!ego_.at(it.t_capture, &e)) {
    lidar_ring_.release(it.slot, stream_lidar_);
    return;
  }""", "lidar pose")
    p = sub(p, """void Pipeline::process_radar(const Item& it) {
  Pose e = ego_.latest();""",
            """void Pipeline::process_radar(const Item& it) {
  Pose e;
  if (!ego_.at(it.t_capture, &e)) {
    radar_ring_.release(it.slot, stream_radar_);
    return;
  }""", "radar pose")

    p = sub(p, """  CUDA_CHECK(cudaStreamSynchronize(stream_lidar_));

  int n = *lw_.host_count;""",
            """  CUDA_CHECK(cudaStreamSynchronize(stream_lidar_));
  lidar_ring_.release(it.slot, stream_lidar_);

  int n = *lw_.host_count;""", "lidar release")
    p = sub(p, """  CUDA_CHECK(cudaStreamSynchronize(stream_radar_));

  const float* xs""",
            """  CUDA_CHECK(cudaStreamSynchronize(stream_radar_));
  radar_ring_.release(it.slot, stream_radar_);

  const float* xs""", "radar release")

    # every update finishes by publishing a snapshot for the publisher to read
    p = p.replace("  tracker_.step(it.t_capture, dets_);\n}",
                  "  tracker_.step(it.t_capture, dets_);\n  refresh_snapshot(it.t_capture);\n}")

    p = sub(p, """    // Hold the tracker for the whole batch so the publisher never observes a
    // half applied set of updates.
    {
      std::lock_guard<std::mutex> lk(track_mu_);
      for (const auto& it : batch) process(it);
    }
    batch.clear();""",
            """    for (const auto& it : batch) process(it);
    batch.clear();""", "worker loop")

    p = sub(p, """    {
      std::lock_guard<std::mutex> lk(track_mu_);
      tracker_.snapshot(stamp, &pub_);
    }""",
            """    const Snap& snap = snaps_[snap_seq_.load(std::memory_order_acquire) % kSnaps];
    double age = stamp - snap.t;
    pub_.clear();
    for (int i = 0; i < snap.n; ++i) {
      PubObj o = snap.objs[i];
      o.x += o.vx * static_cast<float>(age);
      o.y += o.vy * static_cast<float>(age);
      pub_.push_back(o);
    }""", "publisher read")

    p = sub(p, """    if (stats_ && (k % 20) == 0) {
      Tracker::HeldBack hb;
      size_t ntrk;
      {
        std::lock_guard<std::mutex> lk(track_mu_);
        hb = tracker_.held_back();
        ntrk = tracker_.size();
      }""",
            """    if (stats_ && (k % 20) == 0) {
      Tracker::HeldBack hb = tracker_.held_back();
      size_t ntrk = tracker_.size();""", "stats read")

    p = sub(p, """  CUDA_CHECK(cudaMemsetAsync(lidar_ring_.dev(0), 0, kLidarPts * sizeof(uint16_t),
                             stream_lidar_));""",
            """  const int warm_slot = lidar_ring_.acquire();
  CUDA_CHECK(cudaMemsetAsync(lidar_ring_.dev(warm_slot), 0,
                             kLidarPts * sizeof(uint16_t), stream_lidar_));""",
            "warm up slot")
    p = sub(p, """  lidar_frontend(&lw_, lidar_ring_.dev(0), warm, static_cast<float>(wl_.az_min), daz,
                 static_cast<float>(wl_.el_min), del, 0.f, 0.f, stream_lidar_);
  CUDA_CHECK(cudaStreamSynchronize(stream_lidar_));
  return true;""",
            """  lidar_frontend(&lw_, lidar_ring_.dev(warm_slot), warm,
                 static_cast<float>(wl_.az_min), daz, static_cast<float>(wl_.el_min),
                 del, 0.f, 0.f, stream_lidar_);
  CUDA_CHECK(cudaStreamSynchronize(stream_lidar_));
  lidar_ring_.release(warm_slot, stream_lidar_);
  return true;""", "warm up frontend")

    p = sub(p, "void Pipeline::process(const Item& it) {",
            """void Pipeline::refresh_snapshot(double t) {
  unsigned cur = snap_seq_.load(std::memory_order_relaxed);
  Snap& s = snaps_[(cur + 1) % kSnaps];
  static thread_local std::vector<PubObj> tmp;
  tracker_.snapshot(t, &tmp);
  s.t = t;
  s.n = static_cast<int>(std::min(tmp.size(), static_cast<size_t>(kTrackCap)));
  for (int i = 0; i < s.n; ++i) s.objs[i] = tmp[i];
  snap_seq_.store(cur + 1, std::memory_order_release);
}

void Pipeline::process(const Item& it) {""", "snapshot helper")
    return p


def main():
    os.makedirs(OUT, exist_ok=True)
    h = build_header()
    h = sub(h, "  void process_radar(const Item& it);",
            "  void process_radar(const Item& it);\n  void refresh_snapshot(double t);",
            "helper decl")
    open(os.path.join(OUT, "pipeline.h"), "w", encoding="utf-8", newline="\n").write(h)
    open(os.path.join(OUT, "pipeline.cpp"), "w", encoding="utf-8", newline="\n").write(build_source())
    print("regenerated the independent pipeline from the shipped sources")


if __name__ == "__main__":
    main()
