"""Write the workload manifests the two images generate their recordings from.

Shipping the recordings makes the Docker build context nearly a hundred megabytes,
and the context upload is fragile at that size.  The generator is seeded, so the
images regenerate the recordings instead and check them against the hashes
recorded here, which are taken from the files the thresholds were calibrated on.

The .bin is hashed byte for byte.  The truth file is checked by its row counts
instead, because its positions come out of transcendental functions whose last
bit is not the same on every libm.

    python make_manifests.py <dir with the calibrated recordings> ...
"""
import hashlib
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))

DEV = [
    dict(name="dev_light", seed=1101, profile="light", duration=20.0, objects=34, urban=0),
    dict(name="dev_burst", seed=1102, profile="heavy", duration=24.0, objects=34, urban=0),
    dict(name="dev_stress", seed=1103, profile="stress", duration=24.0, objects=34, urban=0),
]
HIDDEN = [
    dict(name="hid_2201", seed=2201, profile="heavy", duration=24.0, objects=34, urban=0),
    dict(name="hid_2202", seed=2202, profile="stress", duration=24.0, objects=34, urban=0),
    dict(name="hid_2203", seed=2203, profile="heavy", duration=24.0, objects=34, urban=0),
    dict(name="hid_2204", seed=2204, profile="stress", duration=24.0, objects=34, urban=0),
    dict(name="hid_2205", seed=2205, profile="heavy", duration=24.0, objects=34, urban=0),
    dict(name="hid_2206", seed=2206, profile="stress", duration=24.0, objects=34, urban=0),
]


def hash_bin(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def truth_counts(path):
    """Row counts of the truth file.

    The .bin is hashed byte for byte, which is portable because everything in it
    is quantised.  The truth arrays are not: they come out of transcendental
    functions whose last bit differs between one platform's libm and another, so
    the same seed on Linux and on Windows gives positions that disagree by a few
    ulps, around 1e-13 m.  Hashing those would fail a build for nothing, so what
    is checked instead is the shape of the answer, which is exact everywhere.
    """
    z = np.load(path, allow_pickle=False)
    return int(z["t"].shape[0]), int(z["graded"].sum()), int(len(np.unique(z["oid"])))


def build(specs, source_dir):
    out = []
    for spec in specs:
        base = os.path.join(source_dir, spec["name"])
        row = dict(spec)
        row["sha256_bin"] = hash_bin(base + ".bin")
        rows, graded, objs = truth_counts(base + "_truth.npz")
        row["truth_rows"] = rows
        row["truth_graded"] = graded
        row["truth_objects"] = objs
        out.append(row)
        print("  %-12s bin %s  rows %d graded %d objects %d"
              % (row["name"], row["sha256_bin"][:16], rows, graded, objs))
    return out


def main():
    dev_src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        ROOT, "environment", "data", "app", "workloads")
    hid_src = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, "tests", "workloads")

    print("development recordings from", dev_src)
    dev = build(DEV, dev_src)
    print("graded recordings from", hid_src)
    hid = build(HIDDEN, hid_src)

    for path, rows in ((os.path.join(ROOT, "environment", "data", "gen", "manifest.json"), dev),
                       (os.path.join(ROOT, "tests", "gen", "manifest.json"), hid)):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", newline="\n") as f:
            json.dump({"workloads": rows}, f, indent=1)
        print("wrote", os.path.relpath(path, ROOT))


if __name__ == "__main__":
    main()
