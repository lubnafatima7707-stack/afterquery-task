"""Regenerate the recordings listed in a manifest and check them against it.

Both images run this at build time instead of carrying the recordings, which keeps
the Docker build context down to source code.  Every recording is redrawn from its
seed by gen_scene.py and checked against what was recorded when the thresholds
were calibrated, so a build that would produce different data fails here rather
than silently grading against something else.

    python3 make_workloads.py --manifest manifest.json --out /app/workloads
"""
import argparse
import hashlib
import json
import os
import subprocess
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def hash_bin(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def truth_counts(path):
    """Row counts of the truth file.

    The .bin is hashed byte for byte, which is portable because everything in it
    is quantised.  The truth arrays are not: they come out of transcendental
    functions whose last bit differs between one platform's libm and another, so
    the same seed on Linux and on Windows gives positions that disagree by a few
    ulps, around 1e-13 m.  Hashing those would fail a build for nothing, so what
    is checked instead is the shape of the answer, which is exact everywhere.
    """
    z = np.load(path, allow_pickle=False)
    return int(z["t"].shape[0]), int(z["graded"].sum()), int(len(np.unique(z["oid"])))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", default=os.path.join(HERE, "manifest.json"))
    ap.add_argument("--out", required=True)
    ap.add_argument("--generator", default=os.path.join(HERE, "gen_scene.py"))
    ap.add_argument("--skip-check", action="store_true",
                    help="generate without comparing against the recorded hashes")
    args = ap.parse_args()

    rows = json.load(open(args.manifest))["workloads"]
    os.makedirs(args.out, exist_ok=True)
    bad = []

    for row in rows:
        base = os.path.join(args.out, row["name"])
        cmd = [sys.executable, args.generator,
               "--seed", str(row["seed"]),
               "--profile", row["profile"],
               "--duration", str(row["duration"]),
               "--objects", str(row["objects"]),
               "--urban", str(row["urban"]),
               "--out", base]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            sys.stderr.write(r.stdout + r.stderr)
            raise SystemExit("generator failed for " + row["name"])

        got_bin = hash_bin(base + ".bin")
        counts = truth_counts(base + "_truth.npz")
        want = (row["truth_rows"], row["truth_graded"], row["truth_objects"])
        ok = (got_bin == row["sha256_bin"] and counts == want)
        print("%-12s %6.1f MB  %s" % (row["name"],
                                      os.path.getsize(base + ".bin") / 1e6,
                                      "ok" if ok else "MISMATCH"))
        if not ok:
            bad.append("%s: bin %s wanted %s, truth counts %s wanted %s"
                       % (row["name"], got_bin[:16], row["sha256_bin"][:16], counts, want))

    if bad and not args.skip_check:
        sys.stderr.write("\n".join(bad) + "\n")
        raise SystemExit("regenerated recordings do not match the calibrated ones")
    print("generated %d recordings into %s" % (len(rows), args.out))


if __name__ == "__main__":
    main()
