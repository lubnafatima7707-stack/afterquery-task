# fusion_node

Perception fusion stage. Replays a recorded sensor stream in wall clock time and publishes a
fused moving object list at 20 Hz.

## Threads

| thread | what it does |
| --- | --- |
| `odom_thread` | delivers localisation poses at 100 Hz into `EgoSource` |
| `radar_thread` | delivers radar detection lists at 20 Hz, stages and uploads them |
| `lidar_thread` | delivers lidar range images at 10 Hz, stages and uploads them |
| `worker_thread` | drains the work queue, runs the front ends, updates the tracker |
| `publisher_thread` | every 50 ms, snapshots the tracker and writes one line to stdout |

Each sensor has its own CUDA stream. Ingest puts the host to device copy on that stream and
the worker puts the front end kernels for the same frame on the same stream, so the copy and
the kernels stay ordered with respect to one another without any explicit synchronisation.

## Files

| file | contents |
| --- | --- |
| `src/rtf.h` | geometry, rates, gates and every tuning constant |
| `src/workload.cpp` | replay file reader |
| `src/staging.h` | `StagingRing`, the pinned host and device buffers frames are staged through |
| `src/ego.h` | `EgoSource`, the pose distribution point |
| `src/kernels.cu` | lidar and radar front ends |
| `src/tracker.cpp` | constant velocity EKF, gated association, lifecycle |
| `src/pipeline.cpp` | threads, queue, worker loop, publisher |

## Lidar front end

Unproject the range image into sensor and world coordinates, sweep 2048 candidate ground
planes over a grid of pitch, roll and height and keep the one with the most inliers, drop
everything within the ground band, scatter what is left into a 512 by 512 occupancy grid at
0.45 m, run 32 rounds of label propagation to connect neighbouring cells, and reduce each
label to a centroid and an extent. Labels whose extent does not look like a road vehicle are
discarded, which is what removes guardrails and building faces.

## Radar front end

Project each detection into the world frame, subtract the ego motion from its measured
closing rate so that what remains is the target's own radial velocity, call a detection
moving when that exceeds `kMovingVr`, count neighbours within `kRadarNbrRange` to reject
isolated returns near the vehicle, and group the survivors on the host.

## Tracker

Constant velocity EKF per object with position updates from both sensors and a radial
velocity update from the radar. Association is greedy on clearance from the track body.
A track is reported once it is confirmed, recently updated, seen moving by the radar and
holding a velocity above `kFilterSpeed`.

## Building it

The image ships the sources only, so build before anything else:

```
cmake -S /app -B /app/build -DCMAKE_BUILD_TYPE=Release -DCMAKE_CUDA_ARCHITECTURES=90
cmake --build /app/build --parallel
```

## Running it

```
/app/build/fusion_node --workload /app/workloads/dev_light.bin
/app/build/fusion_node --workload /app/workloads/dev_burst.bin --stats
/app/build/fusion_node --workload /app/workloads/dev_stress.bin --dump-detections /tmp/d.txt
```

`--stats` prints a line on stderr every second with queue depth, front end counts and the
reasons tracks were held back. `--dump-detections` writes the per frame detection lists.

## Scoring a run

```
python3 /app/tools/score_dev.py /app/workloads/dev_burst.bin
```
