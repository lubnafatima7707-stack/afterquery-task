// Ego pose distribution.
//
// The localisation module pushes a pose at 100 Hz.  Everything downstream needs
// the vehicle pose to move sensor measurements into the world frame before they
// can be associated with tracks.
#pragma once

#include "rtf.h"

namespace rtf {

class EgoSource {
 public:
  // Called from the odometry thread on every incoming pose.
  void publish(const OdomRec& r) {
    cur_.t = r.t_capture;
    cur_.x = r.x;
    cur_.y = r.y;
    cur_.yaw = r.yaw;
    cur_.vx = r.vx;
    cur_.vy = r.vy;
    cur_.w = r.w;
    have_ = true;
  }

  // Newest pose the localisation module has produced.  Poses land every 10 ms,
  // so this is the vehicle state to within one odometry period.
  Pose latest() const { return cur_; }

  bool valid() const { return have_; }

 private:
  Pose cur_{};
  bool have_ = false;
};

}  // namespace rtf
