#include "kernels.h"

namespace rtf {
namespace {

__device__ __forceinline__ void decode_plane(int c, float* a, float* b, float* h) {
  int k = c % kPlaneH;
  int j = (c / kPlaneH) % kPlaneRoll;
  int i = c / (kPlaneH * kPlaneRoll);
  *a = -kPlaneSlopeMax + 2.0f * kPlaneSlopeMax * i / (kPlanePitch - 1);
  *b = -kPlaneSlopeMax + 2.0f * kPlaneSlopeMax * j / (kPlaneRoll - 1);
  *h = -kPlaneHMax + 2.0f * kPlaneHMax * k / (kPlaneH - 1);
}

__global__ void k_unproject(const uint16_t* __restrict__ rng, float az_min, float daz,
                            float el_min, float del, DevPose pose, float sensor_h,
                            float* __restrict__ xs, float* __restrict__ ys,
                            float* __restrict__ zs, float* __restrict__ xw,
                            float* __restrict__ yw, uint8_t* __restrict__ valid) {
  int idx = blockIdx.x * blockDim.x + threadIdx.x;
  if (idx >= kLidarPts) return;
  float r = rng[idx] * 0.01f;
  if (r < 0.4f) {
    valid[idx] = 0;
    xs[idx] = ys[idx] = zs[idx] = 0.f;
    xw[idx] = yw[idx] = 0.f;
    return;
  }
  int beam = idx / kLidarCols;
  int col = idx - beam * kLidarCols;
  float az = az_min + (col + 0.5f) * daz;
  float el = el_min + (beam + 0.5f) * del;
  float ce = cosf(el), se = sinf(el);
  float px = r * ce * cosf(az);
  float py = r * ce * sinf(az);
  float pz = sensor_h + r * se;
  xs[idx] = px;
  ys[idx] = py;
  zs[idx] = pz;
  float cy = cosf(pose.yaw), sy = sinf(pose.yaw);
  xw[idx] = pose.x + cy * px - sy * py;
  yw[idx] = pose.y + sy * px + cy * py;
  valid[idx] = 1;
}

// One block per candidate plane.  Every block walks the whole cloud, which is
// the arithmetic the accelerator is here for.
__global__ void k_plane_score(const float* __restrict__ xs, const float* __restrict__ ys,
                              const float* __restrict__ zs,
                              const uint8_t* __restrict__ valid,
                              int* __restrict__ score) {
  __shared__ int red[256];
  float a, b, h;
  decode_plane(blockIdx.x, &a, &b, &h);
  int local = 0;
  for (int i = threadIdx.x; i < kLidarPts; i += blockDim.x) {
    if (!valid[i]) continue;
    float px = xs[i], py = ys[i];
    if (px * px + py * py > kPlaneScoreRange * kPlaneScoreRange) continue;
    float d = zs[i] - (h + a * px + b * py);
    local += (fabsf(d) < kGroundBand) ? 1 : 0;
  }
  red[threadIdx.x] = local;
  __syncthreads();
  for (int s = blockDim.x / 2; s > 0; s >>= 1) {
    if (threadIdx.x < s) red[threadIdx.x] += red[threadIdx.x + s];
    __syncthreads();
  }
  if (threadIdx.x == 0) score[blockIdx.x] = red[0];
}

__global__ void k_plane_best(const int* __restrict__ score, float* __restrict__ best) {
  __shared__ int bv[256];
  __shared__ int bi[256];
  int v = -1, bidx = 0;
  for (int c = threadIdx.x; c < kPlaneCand; c += blockDim.x) {
    if (score[c] > v) {
      v = score[c];
      bidx = c;
    }
  }
  bv[threadIdx.x] = v;
  bi[threadIdx.x] = bidx;
  __syncthreads();
  for (int s = blockDim.x / 2; s > 0; s >>= 1) {
    if (threadIdx.x < s && bv[threadIdx.x + s] > bv[threadIdx.x]) {
      bv[threadIdx.x] = bv[threadIdx.x + s];
      bi[threadIdx.x] = bi[threadIdx.x + s];
    }
    __syncthreads();
  }
  if (threadIdx.x == 0) {
    float a, b, h;
    decode_plane(bi[0], &a, &b, &h);
    best[0] = a;
    best[1] = b;
    best[2] = h;
  }
}

__device__ __forceinline__ int cell_of(float x, float y, float ox, float oy) {
  int gi = (int)floorf((x - ox) / kGridRes);
  int gj = (int)floorf((y - oy) / kGridRes);
  if (gi < 0 || gi >= kGridN || gj < 0 || gj >= kGridN) return -1;
  return gi * kGridN + gj;
}

__device__ __forceinline__ bool is_object_point(int i, const float* xs, const float* ys,
                                                const float* zs, const uint8_t* valid,
                                                const float* plane) {
  if (!valid[i]) return false;
  float px = xs[i], py = ys[i];
  float r2 = px * px + py * py;
  if (r2 > 78.0f * 78.0f || r2 < 1.2f) return false;
  float gz = plane[2] + plane[0] * px + plane[1] * py;
  float dz = zs[i] - gz;
  return dz > kGroundBand && dz < 3.6f;
}

__global__ void k_cell_count(const float* xs, const float* ys, const float* zs,
                             const float* xw, const float* yw, const uint8_t* valid,
                             const float* plane, float ox, float oy, int* cell_n) {
  int i = blockIdx.x * blockDim.x + threadIdx.x;
  if (i >= kLidarPts) return;
  if (!is_object_point(i, xs, ys, zs, valid, plane)) return;
  int c = cell_of(xw[i], yw[i], ox, oy);
  if (c >= 0) atomicAdd(&cell_n[c], 1);
}

__global__ void k_label_init(const int* cell_n, int* label) {
  int c = blockIdx.x * blockDim.x + threadIdx.x;
  if (c >= kGridCells) return;
  label[c] = (cell_n[c] >= kMinCellPts) ? c : -1;
}

__global__ void k_label_prop(const int* __restrict__ in, int* __restrict__ out) {
  int c = blockIdx.x * blockDim.x + threadIdx.x;
  if (c >= kGridCells) return;
  int cur = in[c];
  if (cur < 0) {
    out[c] = -1;
    return;
  }
  int gi = c / kGridN, gj = c - gi * kGridN;
  int best = cur;
  for (int di = -1; di <= 1; ++di) {
    int ni = gi + di;
    if (ni < 0 || ni >= kGridN) continue;
    for (int dj = -1; dj <= 1; ++dj) {
      int nj = gj + dj;
      if (nj < 0 || nj >= kGridN) continue;
      int v = in[ni * kGridN + nj];
      if (v >= 0 && v < best) best = v;
    }
  }
  out[c] = best;
}

__global__ void k_point_reduce(const float* xs, const float* ys, const float* zs,
                               const float* xw, const float* yw, const uint8_t* valid,
                               const float* plane, float ox, float oy,
                               const int* cell_n, const int* label, int* acc_n,
                               float* acc_sx, float* acc_sy, float* acc_sxx,
                               float* acc_syy) {
  int i = blockIdx.x * blockDim.x + threadIdx.x;
  if (i >= kLidarPts) return;
  if (!is_object_point(i, xs, ys, zs, valid, plane)) return;
  int c = cell_of(xw[i], yw[i], ox, oy);
  if (c < 0 || cell_n[c] < kMinCellPts) return;
  int L = label[c];
  if (L < 0) return;
  float px = xw[i], py = yw[i];
  atomicAdd(&acc_n[L], 1);
  atomicAdd(&acc_sx[L], px);
  atomicAdd(&acc_sy[L], py);
  atomicAdd(&acc_sxx[L], px * px);
  atomicAdd(&acc_syy[L], py * py);
}

__global__ void k_emit(const int* acc_n, const float* acc_sx, const float* acc_sy,
                       const float* acc_sxx, const float* acc_syy, float* det,
                       int* det_count) {
  int c = blockIdx.x * blockDim.x + threadIdx.x;
  if (c >= kGridCells) return;
  int n = acc_n[c];
  if (n < kMinClusterPts) return;
  float inv = 1.0f / n;
  float mx = acc_sx[c] * inv;
  float my = acc_sy[c] * inv;
  float vx = fmaxf(0.0f, acc_sxx[c] * inv - mx * mx);
  float vy = fmaxf(0.0f, acc_syy[c] * inv - my * my);
  int slot = atomicAdd(det_count, 1);
  if (slot >= kMaxDet) return;
  det[slot * 4 + 0] = mx;
  det[slot * 4 + 1] = my;
  det[slot * 4 + 2] = sqrtf(12.0f * vx) + kGridRes;
  det[slot * 4 + 3] = sqrtf(12.0f * vy) + kGridRes;
}

// ------------------------------------------------------------------- radar
__global__ void k_radar_world(const float* __restrict__ src, int n, DevPose pose,
                              float* x, float* y, float* vr, float* ux, float* uy,
                              int* moving) {
  int i = blockIdx.x * blockDim.x + threadIdx.x;
  if (i >= n) return;
  float r = src[i * 4 + 0];
  float az = src[i * 4 + 1];
  float v = src[i * 4 + 2];
  float cy = cosf(pose.yaw), sy = sinf(pose.yaw);
  float sx = r * cosf(az), sxy = r * sinf(az);
  x[i] = pose.x + cy * sx - sy * sxy;
  y[i] = pose.y + sy * sx + cy * sxy;
  // ego velocity expressed in the sensor frame
  float evx = cy * pose.vx + sy * pose.vy;
  float evy = -sy * pose.vx + cy * pose.vy;
  float ca = cosf(az), sa = sinf(az);
  // What the radar measures is the closing rate between sensor and target.  Take
  // the ego motion back out so that what leaves this kernel is the target's own
  // radial velocity, which is the quantity the world frame tracker models.
  float v_static = -(evx * ca + evy * sa);
  float v_target = v - v_static;
  vr[i] = v_target;
  ux[i] = cy * ca - sy * sa;
  uy[i] = sy * ca + cy * sa;
  moving[i] = (fabsf(v_target) > kMovingVr) ? 1 : 0;
}

// Pairwise density count.  Quadratic in the detection count, which is what the
// clutter load actually costs.
__global__ void k_radar_density(const float* x, const float* y, const float* vr, int n,
                                int* nbr) {
  int i = blockIdx.x * blockDim.x + threadIdx.x;
  float xi = 0.f, yi = 0.f, vi = 0.f;
  if (i < n) {
    xi = x[i];
    yi = y[i];
    vi = vr[i];
  }
  __shared__ float sx[256], sy[256], sv[256];
  int count = 0;
  for (int base = 0; base < n; base += 256) {
    int j = base + threadIdx.x;
    if (j < n) {
      sx[threadIdx.x] = x[j];
      sy[threadIdx.x] = y[j];
      sv[threadIdx.x] = vr[j];
    }
    __syncthreads();
    int lim = min(256, n - base);
    if (i < n) {
      for (int k = 0; k < lim; ++k) {
        float dx = xi - sx[k], dy = yi - sy[k], dv = vi - sv[k];
        if (dx * dx + dy * dy < kRadarNbrRange * kRadarNbrRange &&
            fabsf(dv) < kRadarNbrVel)
          ++count;
      }
    }
    __syncthreads();
  }
  if (i < n) nbr[i] = count - 1;
}

}  // namespace

void LidarWork::init() {
  size_t np = kLidarPts;
  CUDA_CHECK(cudaMalloc(&xs, np * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&ys, np * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&zs, np * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&xw, np * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&yw, np * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&valid, np * sizeof(uint8_t)));
  CUDA_CHECK(cudaMalloc(&plane_score, kPlaneCand * sizeof(int)));
  CUDA_CHECK(cudaMalloc(&plane_best, 3 * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&cell_n, kGridCells * sizeof(int)));
  CUDA_CHECK(cudaMalloc(&label_a, kGridCells * sizeof(int)));
  CUDA_CHECK(cudaMalloc(&label_b, kGridCells * sizeof(int)));
  CUDA_CHECK(cudaMalloc(&acc_n, kGridCells * sizeof(int)));
  CUDA_CHECK(cudaMalloc(&acc_sx, kGridCells * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&acc_sy, kGridCells * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&acc_sxx, kGridCells * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&acc_syy, kGridCells * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&det, kMaxDet * 4 * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&det_count, sizeof(int)));
  CUDA_CHECK(cudaHostAlloc(&host_det, kMaxDet * 4 * sizeof(float), cudaHostAllocDefault));
  CUDA_CHECK(cudaHostAlloc(&host_count, sizeof(int), cudaHostAllocDefault));
}

void LidarWork::destroy() {
  cudaFree(xs); cudaFree(ys); cudaFree(zs); cudaFree(xw); cudaFree(yw);
  cudaFree(valid); cudaFree(plane_score); cudaFree(plane_best);
  cudaFree(cell_n); cudaFree(label_a); cudaFree(label_b);
  cudaFree(acc_n); cudaFree(acc_sx); cudaFree(acc_sy);
  cudaFree(acc_sxx); cudaFree(acc_syy);
  cudaFree(det); cudaFree(det_count);
  cudaFreeHost(host_det); cudaFreeHost(host_count);
}

void RadarWork::init() {
  CUDA_CHECK(cudaMalloc(&x, kMaxRadarDet * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&y, kMaxRadarDet * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&vr, kMaxRadarDet * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&ux, kMaxRadarDet * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&uy, kMaxRadarDet * sizeof(float)));
  CUDA_CHECK(cudaMalloc(&moving, kMaxRadarDet * sizeof(int)));
  CUDA_CHECK(cudaMalloc(&nbr, kMaxRadarDet * sizeof(int)));
  CUDA_CHECK(cudaHostAlloc(&host_pack, kMaxRadarDet * 5 * sizeof(float), cudaHostAllocDefault));
  CUDA_CHECK(cudaHostAlloc(&host_flag, kMaxRadarDet * 2 * sizeof(int), cudaHostAllocDefault));
}

void RadarWork::destroy() {
  cudaFree(x); cudaFree(y); cudaFree(vr); cudaFree(ux); cudaFree(uy);
  cudaFree(moving); cudaFree(nbr);
  cudaFreeHost(host_pack); cudaFreeHost(host_flag);
}

void lidar_frontend(LidarWork* w, const uint16_t* d_range, const DevPose& pose,
                    float az_min, float daz, float el_min, float del, float ox,
                    float oy, cudaStream_t s) {
  const int T = 256;
  const int blocks = (kLidarPts + T - 1) / T;
  k_unproject<<<blocks, T, 0, s>>>(d_range, az_min, daz, el_min, del, pose, kSensorH,
                                   w->xs, w->ys, w->zs, w->xw, w->yw, w->valid);
  k_plane_score<<<kPlaneCand, T, 0, s>>>(w->xs, w->ys, w->zs, w->valid, w->plane_score);
  k_plane_best<<<1, T, 0, s>>>(w->plane_score, w->plane_best);

  CUDA_CHECK(cudaMemsetAsync(w->cell_n, 0, kGridCells * sizeof(int), s));
  CUDA_CHECK(cudaMemsetAsync(w->acc_n, 0, kGridCells * sizeof(int), s));
  CUDA_CHECK(cudaMemsetAsync(w->acc_sx, 0, kGridCells * sizeof(float), s));
  CUDA_CHECK(cudaMemsetAsync(w->acc_sy, 0, kGridCells * sizeof(float), s));
  CUDA_CHECK(cudaMemsetAsync(w->acc_sxx, 0, kGridCells * sizeof(float), s));
  CUDA_CHECK(cudaMemsetAsync(w->acc_syy, 0, kGridCells * sizeof(float), s));
  CUDA_CHECK(cudaMemsetAsync(w->det_count, 0, sizeof(int), s));

  k_cell_count<<<blocks, T, 0, s>>>(w->xs, w->ys, w->zs, w->xw, w->yw, w->valid,
                                    w->plane_best, ox, oy, w->cell_n);
  const int cblocks = (kGridCells + T - 1) / T;
  k_label_init<<<cblocks, T, 0, s>>>(w->cell_n, w->label_a);
  int* a = w->label_a;
  int* b = w->label_b;
  for (int it = 0; it < kLabelIters; ++it) {
    k_label_prop<<<cblocks, T, 0, s>>>(a, b);
    int* tmp = a;
    a = b;
    b = tmp;
  }
  k_point_reduce<<<blocks, T, 0, s>>>(w->xs, w->ys, w->zs, w->xw, w->yw, w->valid,
                                      w->plane_best, ox, oy, w->cell_n, a, w->acc_n,
                                      w->acc_sx, w->acc_sy, w->acc_sxx, w->acc_syy);
  k_emit<<<cblocks, T, 0, s>>>(w->acc_n, w->acc_sx, w->acc_sy, w->acc_sxx, w->acc_syy,
                               w->det, w->det_count);
  CUDA_CHECK(cudaMemcpyAsync(w->host_det, w->det, kMaxDet * 4 * sizeof(float),
                             cudaMemcpyDeviceToHost, s));
  CUDA_CHECK(cudaMemcpyAsync(w->host_count, w->det_count, sizeof(int),
                             cudaMemcpyDeviceToHost, s));
}

void radar_frontend(RadarWork* w, const float* d_det, int n, const DevPose& pose,
                    cudaStream_t s) {
  if (n <= 0) {
    w->host_flag[0] = 0;
    return;
  }
  const int T = 256;
  int blocks = (n + T - 1) / T;
  k_radar_world<<<blocks, T, 0, s>>>(d_det, n, pose, w->x, w->y, w->vr, w->ux, w->uy,
                                     w->moving);
  k_radar_density<<<blocks, T, 0, s>>>(w->x, w->y, w->vr, n, w->nbr);
  CUDA_CHECK(cudaMemcpyAsync(w->host_pack, w->x, n * sizeof(float),
                             cudaMemcpyDeviceToHost, s));
  CUDA_CHECK(cudaMemcpyAsync(w->host_pack + kMaxRadarDet, w->y, n * sizeof(float),
                             cudaMemcpyDeviceToHost, s));
  CUDA_CHECK(cudaMemcpyAsync(w->host_pack + 2 * kMaxRadarDet, w->vr, n * sizeof(float),
                             cudaMemcpyDeviceToHost, s));
  CUDA_CHECK(cudaMemcpyAsync(w->host_pack + 3 * kMaxRadarDet, w->ux, n * sizeof(float),
                             cudaMemcpyDeviceToHost, s));
  CUDA_CHECK(cudaMemcpyAsync(w->host_pack + 4 * kMaxRadarDet, w->uy, n * sizeof(float),
                             cudaMemcpyDeviceToHost, s));
  CUDA_CHECK(cudaMemcpyAsync(w->host_flag, w->moving, n * sizeof(int),
                             cudaMemcpyDeviceToHost, s));
  CUDA_CHECK(cudaMemcpyAsync(w->host_flag + kMaxRadarDet, w->nbr, n * sizeof(int),
                             cudaMemcpyDeviceToHost, s));
}

}  // namespace rtf
