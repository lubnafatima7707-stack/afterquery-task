// Device workspaces and kernel launchers for the two sensor front ends.
#pragma once

#include "rtf.h"

namespace rtf {

struct DevPose {
  float x, y, yaw, vx, vy;
};

// Scratch the lidar front end needs for one frame.
struct LidarWork {
  float *xs = nullptr, *ys = nullptr, *zs = nullptr;
  float *xw = nullptr, *yw = nullptr;
  uint8_t *valid = nullptr;
  int *plane_score = nullptr;   // kPlaneCand
  float *plane_best = nullptr;  // 3 floats: slope_x, slope_y, height
  int *cell_n = nullptr;        // kGridCells
  int *label_a = nullptr, *label_b = nullptr;
  int *acc_n = nullptr;
  float *acc_sx = nullptr, *acc_sy = nullptr, *acc_sxx = nullptr, *acc_syy = nullptr;
  float *det = nullptr;         // kMaxDet * 4
  int *det_count = nullptr;
  float *host_det = nullptr;    // pinned, kMaxDet * 4
  int *host_count = nullptr;    // pinned

  void init();
  void destroy();
};

struct RadarWork {
  float *x = nullptr, *y = nullptr, *vr = nullptr, *ux = nullptr, *uy = nullptr;
  int *moving = nullptr, *nbr = nullptr;
  float *host_pack = nullptr;   // pinned, kMaxRadarDet * 5
  int *host_flag = nullptr;     // pinned, kMaxRadarDet * 2

  void init();
  void destroy();
};

// Full lidar front end: unproject, ground plane sweep, occupancy clustering.
// Leaves the cluster list in work->host_det / work->host_count.
void lidar_frontend(LidarWork* work, const uint16_t* d_range, const DevPose& pose,
                    float az_min, float daz, float el_min, float del,
                    float grid_ox, float grid_oy, cudaStream_t stream);

// Radar front end: world projection, stationary rejection, density count.
void radar_frontend(RadarWork* work, const float* d_det, int n, const DevPose& pose,
                    cudaStream_t stream);

}  // namespace rtf
