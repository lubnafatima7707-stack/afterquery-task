// fusion_node: replays a recorded sensor stream through the perception fusion
// pipeline in wall clock time and publishes a moving object list at 20 Hz.
#include <cstdio>
#include <cstring>
#include <string>

#include "pipeline.h"

int main(int argc, char** argv) {
  std::string workload;
  std::string dump;
  bool stats = false;
  for (int i = 1; i < argc; ++i) {
    if (std::strcmp(argv[i], "--workload") == 0 && i + 1 < argc) {
      workload = argv[++i];
    } else if (std::strcmp(argv[i], "--stats") == 0) {
      stats = true;
    } else if (std::strcmp(argv[i], "--dump-detections") == 0 && i + 1 < argc) {
      dump = argv[++i];
    } else {
      std::fprintf(stderr, "usage: fusion_node --workload <file.bin> [--stats] "
                 "[--dump-detections <file>]\n");
      return 2;
    }
  }
  if (workload.empty()) {
    std::fprintf(stderr, "usage: fusion_node --workload <file.bin> [--stats] "
                 "[--dump-detections <file>]\n");
    return 2;
  }

  int devices = 0;
  if (cudaGetDeviceCount(&devices) != cudaSuccess || devices == 0) {
    std::fprintf(stderr, "[fusion] no CUDA device available\n");
    return 3;
  }
  CUDA_CHECK(cudaSetDevice(0));

  rtf::Pipeline pipe;
  std::string err;
  if (!pipe.init(workload, stats, dump, &err)) {
    std::fprintf(stderr, "[fusion] init failed: %s\n", err.c_str());
    return 4;
  }
  pipe.run();
  return 0;
}
