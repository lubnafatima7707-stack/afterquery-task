#pragma once

#include <atomic>
#include <condition_variable>
#include <deque>
#include <mutex>
#include <thread>

#include "ego.h"
#include "kernels.h"
#include "rtf.h"
#include "staging.h"
#include "tracker.h"

namespace rtf {

// One unit of sensor work waiting for the fusion stage.
struct Item {
  int kind;          // 1 radar, 2 lidar
  int slot;          // staging slot the frame was written into
  uint32_t n;        // radar detection count
  double t_capture;
  uint64_t seq;
};

class Pipeline {
 public:
  bool init(const std::string& workload_path, bool stats, const std::string& dump,
            std::string* err);
  void run();
  void shutdown();

 private:
  void odom_thread();
  void radar_thread();
  void lidar_thread();
  void worker_thread();
  void publisher_thread();

  void process(const Item& it);
  void process_lidar(const Item& it);
  void process_radar(const Item& it);

  double now() const;
  void sleep_until_replay(double t) const;

  Workload wl_;
  EgoSource ego_;
  StagingRing<uint16_t, 2> lidar_ring_;
  StagingRing<float, 2> radar_ring_;
  cudaStream_t stream_lidar_ = nullptr;
  cudaStream_t stream_radar_ = nullptr;
  LidarWork lw_;
  RadarWork rw_;
  Tracker tracker_;

  mutable std::mutex track_mu_;
  std::mutex q_mu_;
  std::condition_variable q_cv_;
  std::deque<Item> q_;

  std::atomic<bool> running_{true};
  std::atomic<uint64_t> seq_{0};
  std::atomic<long long> deep_{0};
  std::atomic<long long> n_lidar_clusters_{0};
  std::atomic<long long> n_radar_moving_{0};
  std::atomic<long long> n_radar_clusters_{0};
  bool stats_ = false;
  std::FILE* dump_ = nullptr;

  std::chrono::steady_clock::time_point t0_;
  std::vector<std::thread> threads_;
  std::vector<Det> dets_;
  std::vector<PubObj> pub_;
};

}  // namespace rtf
