// Shared types and configuration for the fusion node.
#pragma once

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

#include <cuda_runtime.h>

namespace rtf {

// ---- sensor rig (fixed by the vehicle build, mirrored by the replay files)
constexpr int kLidarBeams = 64;
constexpr int kLidarCols = 768;
constexpr int kLidarPts = kLidarBeams * kLidarCols;
constexpr float kSensorH = 1.90f;

// ---- ground plane sweep: an exhaustive grid over pitch, roll and height.
constexpr int kPlanePitch = 16;
constexpr int kPlaneRoll = 16;
constexpr int kPlaneH = 8;
constexpr int kPlaneCand = kPlanePitch * kPlaneRoll * kPlaneH;
constexpr float kPlaneSlopeMax = 0.060f;
constexpr float kPlaneHMax = 0.50f;
constexpr float kGroundBand = 0.25f;
constexpr float kPlaneScoreRange = 60.0f;

// ---- occupancy grid used for lidar clustering
constexpr int kGridN = 512;
constexpr float kGridRes = 0.45f;
constexpr int kGridCells = kGridN * kGridN;
constexpr int kLabelIters = 32;   // enough to pull a whole guardrail into one label
constexpr int kMinCellPts = 1;
constexpr int kMinClusterPts = 4;

// ---- radar
constexpr int kMaxRadarDet = 8192;
constexpr float kRadarNbrRange = 3.5f;
constexpr float kRadarNbrVel = 1.5f;
constexpr int kRadarMinNbr = 1;
constexpr float kRadarDenseRange = 60.0f;
constexpr float kMovingVr = 1.35f;

// ---- fusion
constexpr int kMaxDet = 768;
constexpr int kMaxTracks = 256;
constexpr double kPublishPeriod = 0.05;
constexpr float kVehicleLenMax = 13.0f;
constexpr float kVehicleWidMax = 3.4f;
constexpr float kGateClear = 1.9f;    // m of clearance outside the track body
constexpr float kMergeClear = 0.9f;   // m, two bodies this close are one object
constexpr float kMergeVel = 4.0f;     // m/s, and they have to agree on motion
constexpr int kConfirmHits = 3;
// Two sensors at different rates means a track is unmatched by most batches.
// Staleness is therefore counted in seconds, never in consecutive batches.
constexpr double kCoastMax = 1.20;    // s without an update before a track dies
constexpr double kFreshMax = 0.60;    // s without an update before it is held back

#define CUDA_CHECK(expr)                                                      \
  do {                                                                        \
    cudaError_t _e = (expr);                                                  \
    if (_e != cudaSuccess) {                                                   \
      std::fprintf(stderr, "[fusion] CUDA error %s at %s:%d -> %s\n",          \
                   cudaGetErrorString(_e), __FILE__, __LINE__, #expr);         \
      std::abort();                                                            \
    }                                                                          \
  } while (0)

struct OdomRec {
  double t_deliver;
  double t_capture;
  float x, y, yaw, vx, vy, w;
};

struct RadarRec {
  double t_deliver;
  double t_capture;
  uint32_t n;
  uint32_t offset;  // index into Workload::radar_blob, in float4 units
};

struct LidarRec {
  double t_deliver;
  double t_capture;
  uint32_t offset;  // index into Workload::lidar_blob, in uint16 units
};

struct Workload {
  double t_start = 0.0;
  double t_end = 0.0;
  int beams = kLidarBeams;
  int cols = kLidarCols;
  double az_min = 0.0, az_max = 0.0, el_min = 0.0, el_max = 0.0;
  double sensor_h = kSensorH;
  std::vector<OdomRec> odom;
  std::vector<RadarRec> radar;
  std::vector<LidarRec> lidar;
  std::vector<float> radar_blob;    // 4 floats per detection: r, az, vr, rcs
  std::vector<uint16_t> lidar_blob; // kLidarPts per frame, range in cm
};

bool load_workload(const std::string& path, Workload* out, std::string* err);

// Ego pose sample handed around the pipeline.
struct Pose {
  double t = 0.0;
  float x = 0.f, y = 0.f, yaw = 0.f, vx = 0.f, vy = 0.f, w = 0.f;
};

// One fused detection, already in the world frame.
struct Det {
  float x, y;
  float len, wid;
  float vr;       // radial velocity, valid when has_vr
  float ux, uy;   // line of sight unit vector the radial velocity refers to
  int has_vr;
  int src;        // 0 lidar, 1 radar
};

inline float wrap_pi(float a) {
  while (a > 3.14159265f) a -= 6.28318531f;
  while (a < -3.14159265f) a += 6.28318531f;
  return a;
}

}  // namespace rtf
