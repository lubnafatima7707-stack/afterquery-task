// Pinned staging buffers for handing sensor frames to the device.
//
// Each slot owns a page locked host landing pad and the device buffer the copy
// targets.  Two slots let the copy for the current frame overlap the kernels
// still running on the previous one, which is all the overlap this pipeline
// needs at the rates the sensors deliver.
#pragma once

#include "rtf.h"

namespace rtf {

template <class T, int kSlots>
class StagingRing {
 public:
  void init(size_t elems) {
    elems_ = elems;
    for (int i = 0; i < kSlots; ++i) {
      CUDA_CHECK(cudaHostAlloc(reinterpret_cast<void**>(&host_[i]),
                               elems * sizeof(T), cudaHostAllocDefault));
      CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&dev_[i]), elems * sizeof(T)));
    }
  }

  void destroy() {
    for (int i = 0; i < kSlots; ++i) {
      if (host_[i]) cudaFreeHost(host_[i]);
      if (dev_[i]) cudaFree(dev_[i]);
      host_[i] = nullptr;
      dev_[i] = nullptr;
    }
  }

  // Hand out the next slot in the rotation.
  int acquire() {
    int s = next_;
    next_ = (next_ + 1) % kSlots;
    return s;
  }

  T* host(int s) { return host_[s]; }
  T* dev(int s) { return dev_[s]; }
  size_t elems() const { return elems_; }

  // Queue the upload of the slot that was just filled.
  void submit(int s, size_t elems, cudaStream_t stream) {
    CUDA_CHECK(cudaMemcpyAsync(dev_[s], host_[s], elems * sizeof(T),
                               cudaMemcpyHostToDevice, stream));
  }

 private:
  T* host_[kSlots] = {};
  T* dev_[kSlots] = {};
  size_t elems_ = 0;
  int next_ = 0;
};

}  // namespace rtf
