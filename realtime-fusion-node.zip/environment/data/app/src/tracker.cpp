#include "tracker.h"

#include <algorithm>
#include <cmath>

namespace rtf {
namespace {

constexpr float kQAccel = 1.4f;      // m/s^2, process noise
constexpr float kRLidar = 0.55f;     // m
constexpr float kRRadar = 0.80f;     // m
constexpr float kRVr = 0.30f;        // m/s
constexpr float kSpeedCap = 46.0f;   // m/s, nothing on a road goes faster
constexpr float kVrInnovMax = 18.0f; // m/s, beyond this it is a bad association

struct Pair {
  float cost;
  int di;
  int ti;
};

// Clearance between a point and an oriented footprint, zero inside it.  The
// association gate and the duplicate test both work on bodies rather than on
// centres, because a lidar cluster sits on the face a vehicle turns towards the
// sensor while its radar detections spread down the whole flank.
float clearance(float px, float py, float cx, float cy, float head, float len,
                float wid) {
  float dx = px - cx, dy = py - cy;
  float c = std::cos(head), s = std::sin(head);
  float lx = std::fabs(dx * c + dy * s) - 0.5f * len;
  float ly = std::fabs(-dx * s + dy * c) - 0.5f * wid;
  lx = std::max(lx, 0.0f);
  ly = std::max(ly, 0.0f);
  return std::sqrt(lx * lx + ly * ly);
}

float heading_of(const Track& tr) {
  float sp = std::sqrt(tr.vx * tr.vx + tr.vy * tr.vy);
  return (sp > 1.0f) ? std::atan2(tr.vy, tr.vx) : tr.heading;
}

}  // namespace

void Tracker::predict_to(Track* tr, double t) const {
  float dt = static_cast<float>(t - tr->t);
  if (dt <= 0.f) return;
  tr->x += tr->vx * dt;
  tr->y += tr->vy * dt;
  tr->t = t;

  float* P = tr->P;
  float p[16];
  for (int i = 0; i < 16; ++i) p[i] = P[i];
  for (int c = 0; c < 4; ++c) {
    p[0 * 4 + c] += dt * p[2 * 4 + c];
    p[1 * 4 + c] += dt * p[3 * 4 + c];
  }
  for (int r = 0; r < 4; ++r) {
    p[r * 4 + 0] += dt * p[r * 4 + 2];
    p[r * 4 + 1] += dt * p[r * 4 + 3];
  }
  float q = kQAccel * kQAccel;
  float dt2 = dt * dt, dt3 = dt2 * dt, dt4 = dt2 * dt2;
  p[0 * 4 + 0] += q * dt4 / 4.f;
  p[1 * 4 + 1] += q * dt4 / 4.f;
  p[2 * 4 + 2] += q * dt2;
  p[3 * 4 + 3] += q * dt2;
  p[0 * 4 + 2] += q * dt3 / 2.f;
  p[2 * 4 + 0] += q * dt3 / 2.f;
  p[1 * 4 + 3] += q * dt3 / 2.f;
  p[3 * 4 + 1] += q * dt3 / 2.f;
  for (int i = 0; i < 16; ++i) P[i] = p[i];
}

void Tracker::clamp_speed(Track* tr) const {
  float sp = std::sqrt(tr->vx * tr->vx + tr->vy * tr->vy);
  if (sp > kSpeedCap) {
    float k = kSpeedCap / sp;
    tr->vx *= k;
    tr->vy *= k;
  }
}

void Tracker::update_pos(Track* tr, float mx, float my, float r) const {
  float* P = tr->P;
  float R = r * r;
  float s00 = P[0] + R, s01 = P[1], s11 = P[5] + R;
  float det = s00 * s11 - s01 * s01;
  if (det < 1e-9f) return;
  float i00 = s11 / det, i01 = -s01 / det, i11 = s00 / det;
  float K[8];
  for (int i = 0; i < 4; ++i) {
    float a = P[i * 4 + 0], b = P[i * 4 + 1];
    K[i * 2 + 0] = a * i00 + b * i01;
    K[i * 2 + 1] = a * i01 + b * i11;
  }
  float yx = mx - tr->x, yy = my - tr->y;
  tr->x += K[0] * yx + K[1] * yy;
  tr->y += K[2] * yx + K[3] * yy;
  tr->vx += K[4] * yx + K[5] * yy;
  tr->vy += K[6] * yx + K[7] * yy;
  float p[16];
  for (int i = 0; i < 4; ++i)
    for (int j = 0; j < 4; ++j)
      p[i * 4 + j] = P[i * 4 + j] - K[i * 2 + 0] * P[0 * 4 + j] - K[i * 2 + 1] * P[1 * 4 + j];
  for (int i = 0; i < 16; ++i) P[i] = p[i];
  clamp_speed(tr);
}

void Tracker::update_vr(Track* tr, float vr, float ux, float uy) const {
  float* P = tr->P;
  float PH[4];
  for (int i = 0; i < 4; ++i) PH[i] = P[i * 4 + 2] * ux + P[i * 4 + 3] * uy;
  float S = ux * PH[2] + uy * PH[3] + kRVr * kRVr;
  if (S < 1e-9f) return;
  float innov = vr - (tr->vx * ux + tr->vy * uy);
  // A radial speed that disagrees with the track by more than any road vehicle
  // could have changed is a wrong association, not new information.
  if (std::fabs(innov) > kVrInnovMax) return;
  float K[4];
  for (int i = 0; i < 4; ++i) K[i] = PH[i] / S;
  tr->x += K[0] * innov;
  tr->y += K[1] * innov;
  tr->vx += K[2] * innov;
  tr->vy += K[3] * innov;
  float p[16];
  for (int i = 0; i < 4; ++i)
    for (int j = 0; j < 4; ++j)
      p[i * 4 + j] = P[i * 4 + j] - K[i] * (ux * P[2 * 4 + j] + uy * P[3 * 4 + j]);
  for (int i = 0; i < 16; ++i) P[i] = p[i];
  clamp_speed(tr);
}

// Two tracks on one body: the younger is retired and its evidence carried over,
// so a vehicle that grew a second track does not trade the report back and forth
// between them.
void Tracker::merge_duplicates() {
  for (size_t i = 0; i < tracks_.size(); ++i) {
    if (tracks_[i].dead || tracks_[i].hits < 2) continue;
    for (size_t j = i + 1; j < tracks_.size(); ++j) {
      if (tracks_[j].dead || tracks_[j].hits < 2) continue;
      float a = clearance(tracks_[j].x, tracks_[j].y, tracks_[i].x, tracks_[i].y,
                          heading_of(tracks_[i]), tracks_[i].len, tracks_[i].wid);
      float b = clearance(tracks_[i].x, tracks_[i].y, tracks_[j].x, tracks_[j].y,
                          heading_of(tracks_[j]), tracks_[j].len, tracks_[j].wid);
      float sep = std::min(a, b);
      if (sep > kMergeClear) continue;
      // Overlapping bodies are one object whatever the two filters currently
      // believe about its velocity; only near misses have to agree on motion.
      if (sep > 1e-3f) {
        float dvx = tracks_[i].vx - tracks_[j].vx;
        float dvy = tracks_[i].vy - tracks_[j].vy;
        if (dvx * dvx + dvy * dvy > kMergeVel * kMergeVel) continue;
      }
      size_t keep = (tracks_[i].born <= tracks_[j].born) ? i : j;
      size_t drop = (keep == i) ? j : i;
      tracks_[keep].radar_hits += tracks_[drop].radar_hits;
      tracks_[keep].lidar_hits += tracks_[drop].lidar_hits;
      tracks_[keep].hits += tracks_[drop].hits;
      tracks_[keep].len = std::max(tracks_[keep].len, tracks_[drop].len);
      tracks_[drop].dead = true;
      if (drop == i) break;
    }
  }
}

void Tracker::step(double t, const std::vector<Det>& dets) {
  for (auto& tr : tracks_) predict_to(&tr, t);

  const int nd = static_cast<int>(dets.size());
  const int nt = static_cast<int>(tracks_.size());
  std::vector<Pair> pairs;
  pairs.reserve(static_cast<size_t>(nd) * 4);
  for (int d = 0; d < nd; ++d) {
    for (int k = 0; k < nt; ++k) {
      const Track& tr = tracks_[k];
      float c = clearance(dets[d].x, dets[d].y, tr.x, tr.y, heading_of(tr),
                          tr.len, tr.wid);
      if (c < kGateClear) pairs.push_back({c, d, k});
    }
  }
  std::sort(pairs.begin(), pairs.end(),
            [](const Pair& a, const Pair& b) { return a.cost < b.cost; });

  std::vector<char> det_used(nd, 0), trk_used(nt, 0);
  int n_assoc = 0, n_born = 0, n_blocked = 0;
  for (const auto& p : pairs) {
    if (det_used[p.di] || trk_used[p.ti]) continue;
    det_used[p.di] = 1;
    trk_used[p.ti] = 1;
    Track& tr = tracks_[p.ti];
    const Det& d = dets[p.di];
    update_pos(&tr, d.x, d.y, d.src == 0 ? kRLidar : kRRadar);
    if (d.has_vr) update_vr(&tr, d.vr, d.ux, d.uy);
    if (d.src == 1) {
      tr.radar_hits += 1;
    } else {
      tr.lidar_hits += 1;
      tr.len = 0.6f * tr.len + 0.4f * std::min(d.len, kVehicleLenMax);
      tr.wid = 0.6f * tr.wid + 0.4f * std::min(std::max(d.wid, 1.2f), kVehicleWidMax);
    }
    tr.hits += 1;
    n_assoc += 1;
    tr.last_t = t;
    if (tr.hits >= kConfirmHits) tr.confirmed = true;
  }

  // One object paints several detections in a single frame.  A detection that
  // already lies on a track's body belongs to that object even when the track
  // has taken another detection this batch, so it must not start a second one.
  for (int d = 0; d < nd; ++d) {
    if (det_used[d]) continue;
    if (static_cast<int>(tracks_.size()) >= kTrackCap) break;
    bool inside = false;
    for (int k = 0; k < nt; ++k) {
      const Track& tk = tracks_[k];
      if (clearance(dets[d].x, dets[d].y, tk.x, tk.y, heading_of(tk),
                    tk.len, tk.wid) < kGateClear) {
        inside = true;
        break;
      }
    }
    if (inside) { n_blocked += 1; continue; }
    n_born += 1;
    Track tr;
    tr.id = next_id_++;
    tr.t = t;
    tr.born = t;
    tr.last_t = t;
    tr.x = dets[d].x;
    tr.y = dets[d].y;
    if (dets[d].has_vr) {
      // The radar pins only the component along the line of sight; the rest of
      // the velocity stays wide open until position updates settle it.
      tr.vx = dets[d].vr * dets[d].ux;
      tr.vy = dets[d].vr * dets[d].uy;
      tr.heading = std::atan2(dets[d].uy, dets[d].ux);
    }
    tr.len = std::max(2.5f, std::min(dets[d].len, kVehicleLenMax));
    tr.wid = std::min(std::max(1.4f, dets[d].wid), kVehicleWidMax);
    for (int i = 0; i < 4; ++i) tr.P[i * 4 + i] = (i < 2) ? 3.0f : 100.0f;
    tr.hits = 1;
    tr.radar_hits = (dets[d].src == 1) ? 1 : 0;
    tr.lidar_hits = (dets[d].src == 0) ? 1 : 0;
    tracks_.push_back(tr);
  }

  for (auto& tr : tracks_) {
    float sp = std::sqrt(tr.vx * tr.vx + tr.vy * tr.vy);
    if (sp > 1.0f) tr.heading = std::atan2(tr.vy, tr.vx);
  }

  held_.assoc = n_assoc;
  held_.born = n_born;
  held_.blocked = n_blocked;
  held_.dets = nd;
  merge_duplicates();
  tracks_.erase(std::remove_if(tracks_.begin(), tracks_.end(),
                               [t](const Track& tr) {
                                 return tr.dead || (t - tr.last_t) > kCoastMax;
                               }),
                tracks_.end());
}

void Tracker::snapshot(double stamp, std::vector<PubObj>* out) const {
  out->clear();
  held_.unconfirmed = held_.stale = held_.no_radar = 0;
  held_.not_moving = held_.published = 0;
  for (const auto& tr : tracks_) {
    if (!tr.confirmed) { held_.unconfirmed += 1; continue; }
    if ((stamp - tr.last_t) > kFreshMax) { held_.stale += 1; continue; }
    if (tr.radar_hits < kPubRadarHits) { held_.no_radar += 1; continue; }
    if (std::sqrt(tr.vx * tr.vx + tr.vy * tr.vy) < kFilterSpeed) {
      held_.not_moving += 1;
      continue;
    }
    float dt = static_cast<float>(stamp - tr.t);
    if (dt < -0.5f || dt > 1.5f) continue;
    PubObj o;
    o.id = tr.id;
    o.x = tr.x + tr.vx * dt;
    o.y = tr.y + tr.vy * dt;
    o.vx = tr.vx;
    o.vy = tr.vy;
    held_.published += 1;
    out->push_back(o);
  }
}

}  // namespace rtf
