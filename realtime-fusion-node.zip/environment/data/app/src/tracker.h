// Multi object tracker: constant velocity EKF per object, gated greedy
// association, hit/miss lifecycle.
#pragma once

#include "rtf.h"

namespace rtf {

constexpr int kTrackCap = 1024;
// The radar is the channel that separates a moving body from the roadside: the
// lidar sees both and cannot tell them apart in one frame.
constexpr int kPubRadarHits = 3;

// A reported object has to have covered ground in the world frame.  Filter
// velocity alone is not enough: one Doppler update on a roadside return is all
// it takes to give a parked car a velocity it never had.
constexpr float kFilterSpeed = 1.80f; // m/s before a track counts as moving

struct Track {
  int id = 0;
  double t = 0.0;
  float x = 0, y = 0, vx = 0, vy = 0;
  float P[16] = {};
  float len = 2.0f, wid = 1.8f;
  int hits = 0;
  int radar_hits = 0;
  int lidar_hits = 0;
  double last_t = 0.0;
  bool dead = false;
  bool confirmed = false;
  float heading = 0.f;
  double born = 0.0;
};

struct PubObj {
  int id;
  float x, y, vx, vy;
};

class Tracker {
 public:
  // Fold one batch of detections, all carrying the same measurement time.
  void step(double t, const std::vector<Det>& dets);

  // Report the moving objects, each propagated to stamp.
  void snapshot(double stamp, std::vector<PubObj>* out) const;

  size_t size() const { return tracks_.size(); }

  // Why tracks did not reach the last published frame, for the stats line.
  struct HeldBack {
    int unconfirmed = 0, stale = 0, no_radar = 0, not_moving = 0, published = 0;
    int assoc = 0, born = 0, blocked = 0, dets = 0;
  };
  HeldBack held_back() const { return held_; }

 private:
  void predict_to(Track* tr, double t) const;
  void clamp_speed(Track* tr) const;
  void update_pos(Track* tr, float mx, float my, float r) const;
  void update_vr(Track* tr, float vr, float ux, float uy) const;
  void merge_duplicates();

  mutable HeldBack held_;
  std::vector<Track> tracks_;
  int next_id_ = 1;
};

}  // namespace rtf
