// Replay file reader.  The whole file is pulled into memory before the clock
// starts so that disk latency never shows up as pipeline latency.
#include "rtf.h"

#include <cstring>
#include <fstream>

namespace rtf {
namespace {

struct Cursor {
  const uint8_t* p;
  const uint8_t* end;
  bool ok = true;

  template <class T>
  T take() {
    T v{};
    if (p + sizeof(T) > end) {
      ok = false;
      return v;
    }
    std::memcpy(&v, p, sizeof(T));
    p += sizeof(T);
    return v;
  }

  bool take_bytes(void* dst, size_t n) {
    if (p + n > end) {
      ok = false;
      return false;
    }
    std::memcpy(dst, p, n);
    p += n;
    return true;
  }
};

}  // namespace

bool load_workload(const std::string& path, Workload* out, std::string* err) {
  std::ifstream f(path, std::ios::binary);
  if (!f) {
    *err = "cannot open " + path;
    return false;
  }
  std::vector<uint8_t> buf((std::istreambuf_iterator<char>(f)),
                           std::istreambuf_iterator<char>());
  if (buf.size() < 80) {
    *err = "replay file too short";
    return false;
  }
  if (std::memcmp(buf.data(), "RTFW0002", 8) != 0) {
    *err = "bad magic in replay file";
    return false;
  }
  Cursor c{buf.data() + 8, buf.data() + buf.size()};
  out->t_start = c.take<double>();
  out->t_end = c.take<double>();
  uint32_t n_odom = c.take<uint32_t>();
  uint32_t n_radar = c.take<uint32_t>();
  uint32_t n_lidar = c.take<uint32_t>();
  uint32_t n_rec = c.take<uint32_t>();
  out->beams = static_cast<int>(c.take<uint32_t>());
  out->cols = static_cast<int>(c.take<uint32_t>());
  out->az_min = c.take<double>();
  out->az_max = c.take<double>();
  out->el_min = c.take<double>();
  out->el_max = c.take<double>();
  out->sensor_h = c.take<double>();
  if (!c.ok) {
    *err = "truncated header";
    return false;
  }
  if (out->beams != kLidarBeams || out->cols != kLidarCols) {
    *err = "replay file does not match the configured lidar geometry";
    return false;
  }

  out->odom.reserve(n_odom);
  out->radar.reserve(n_radar);
  out->lidar.reserve(n_lidar);
  out->lidar_blob.resize(static_cast<size_t>(n_lidar) * kLidarPts);

  size_t lidar_seen = 0;
  for (uint32_t i = 0; i < n_rec; ++i) {
    uint8_t kind = c.take<uint8_t>();
    double t_deliver = c.take<double>();
    double t_capture = c.take<double>();
    if (!c.ok) break;
    if (kind == 0) {
      OdomRec r{};
      r.t_deliver = t_deliver;
      r.t_capture = t_capture;
      float v[6];
      if (!c.take_bytes(v, sizeof(v))) break;
      r.x = v[0]; r.y = v[1]; r.yaw = v[2];
      r.vx = v[3]; r.vy = v[4]; r.w = v[5];
      out->odom.push_back(r);
    } else if (kind == 1) {
      uint32_t n = c.take<uint32_t>();
      if (!c.ok) break;
      RadarRec r{};
      r.t_deliver = t_deliver;
      r.t_capture = t_capture;
      r.n = n;
      r.offset = static_cast<uint32_t>(out->radar_blob.size() / 4);
      size_t base = out->radar_blob.size();
      out->radar_blob.resize(base + static_cast<size_t>(n) * 4);
      if (n && !c.take_bytes(out->radar_blob.data() + base, sizeof(float) * 4 * n)) break;
      out->radar.push_back(r);
    } else if (kind == 2) {
      LidarRec r{};
      r.t_deliver = t_deliver;
      r.t_capture = t_capture;
      r.offset = static_cast<uint32_t>(lidar_seen * kLidarPts);
      if (lidar_seen >= n_lidar) {
        *err = "more lidar frames than the header declares";
        return false;
      }
      if (!c.take_bytes(out->lidar_blob.data() + r.offset,
                        sizeof(uint16_t) * kLidarPts)) break;
      ++lidar_seen;
      out->lidar.push_back(r);
    } else {
      *err = "unknown record kind";
      return false;
    }
  }
  if (!c.ok) {
    *err = "truncated record stream";
    return false;
  }
  if (out->odom.empty()) {
    *err = "replay file carries no odometry";
    return false;
  }
  return true;
}

}  // namespace rtf
