"""Metric code shared with the grader.  Copied verbatim from the
verifier by authoring/provenance/make_devtools.py; do not edit here."""
"""Metrics for the realtime-fusion-node task.

The node is launched here, its stdout is read line by line and each line is
stamped with the reader's own monotonic clock, so publication latency is
measured outside the process under test and cannot be reported by it.
"""
import os
import signal
import subprocess
import sys
import threading
import time

import numpy as np
from scipy.optimize import linear_sum_assignment

GRID_HZ = 20.0
MATCH_GATE = 2.00        # m, clearance outside the object footprint
LOAD_BUDGET = 45.0       # s allowed between launch and READY
TAIL_BUDGET = 3.0        # s allowed after the last publish slot


class RunResult:
    def __init__(self):
        self.frames = []       # (stamp, arrival, [(id, x, y, vx, vy), ...])
        self.ready_at = None
        self.launched_at = None
        self.exit_code = None
        self.wall = 0.0
        self.stderr_tail = ""
        self.error = None


def run_node(binary, workload, timeout, extra_args=None, env=None):
    """Run the node once and time every published line on arrival."""
    res = RunResult()
    cmd = [binary, "--workload", workload] + list(extra_args or [])
    res.launched_at = time.monotonic()
    try:
        popen_kw = dict(stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                        bufsize=1, universal_newlines=True, env=env)
        if os.name == "posix":
            popen_kw["start_new_session"] = True
        proc = subprocess.Popen(cmd, **popen_kw)
    except OSError as exc:
        res.error = "cannot launch node: %s" % exc
        return res

    err_chunks = []

    def drain_err():
        try:
            for line in proc.stderr:
                err_chunks.append(line)
                if len(err_chunks) > 4000:
                    del err_chunks[:2000]
        except Exception:
            pass

    th = threading.Thread(target=drain_err, daemon=True)
    th.start()

    deadline = res.launched_at + timeout
    try:
        for line in proc.stdout:
            now = time.monotonic()
            if now > deadline:
                res.error = "node exceeded the %.0f s run budget" % timeout
                break
            line = line.strip()
            if not line:
                continue
            if line == "READY":
                if res.ready_at is None:
                    res.ready_at = now
                continue
            if line == "DONE":
                continue
            if line[0] != "F":
                continue
            parts = line.split()
            try:
                stamp = float(parts[1])
                count = int(parts[2])
            except (IndexError, ValueError):
                res.error = "malformed output line"
                break
            objs = []
            base = 3
            if len(parts) < base + 5 * count:
                res.error = "output line declares %d objects but carries %d fields" % (
                    count, len(parts) - base)
                break
            for i in range(count):
                o = parts[base + 5 * i: base + 5 * i + 5]
                try:
                    objs.append((int(o[0]), float(o[1]), float(o[2]),
                                 float(o[3]), float(o[4])))
                except ValueError:
                    res.error = "non numeric object field"
                    break
            if res.error:
                break
            res.frames.append((stamp, now, objs))
    finally:
        try:
            proc.stdout.close()
        except Exception:
            pass
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            pass
        if proc.poll() is None:
            _kill_group(proc)
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                pass
        res.exit_code = proc.poll()
    th.join(timeout=2.0)
    res.wall = time.monotonic() - res.launched_at
    res.stderr_tail = "".join(err_chunks[-40:])
    return res


def _kill_group(proc):
    try:
        if os.name == "posix":
            os.killpg(proc.pid, signal.SIGKILL)
        else:
            proc.kill()
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def box_distance(px, py, cx, cy, yaw, length, width):
    """Clearance between reported points and object footprints.

    A sensor sees the faces of a vehicle, not its centre, so a correct tracker
    may report anywhere on or inside the body.  Distance to the oriented
    rectangle is zero for every such answer and grows only once the reported
    point leaves the object.
    """
    dx = px[:, None] - cx[None, :]
    dy = py[:, None] - cy[None, :]
    c = np.cos(yaw)[None, :]
    s = np.sin(yaw)[None, :]
    lx = np.abs(dx * c + dy * s) - 0.5 * length[None, :]
    ly = np.abs(-dx * s + dy * c) - 0.5 * width[None, :]
    return np.hypot(np.maximum(lx, 0.0), np.maximum(ly, 0.0))


def load_truth(path):
    z = np.load(path, allow_pickle=False)
    return {k: z[k] for k in z.files}


def score(res, truth, duration):
    """Accuracy and deadline metrics for one run."""
    m = {
        "ok": False,
        "reason": "",
        "n_frames": len(res.frames),
        "n_slots": int(round(duration * GRID_HZ)),
        "recall": 0.0,
        "pos_rmse": float("inf"),
        "vel_rmse": float("inf"),
        "false_per_frame": float("inf"),
        "late_p99": float("inf"),
        "late_max": float("inf"),
        "late_min": 0.0,
        "coverage": 0.0,
        "wall": res.wall,
        "load_s": 0.0,
    }
    if res.error:
        m["reason"] = res.error
        return m
    if res.ready_at is None:
        m["reason"] = "node never reported READY"
        return m
    m["load_s"] = res.ready_at - res.launched_at
    if m["load_s"] > LOAD_BUDGET:
        m["reason"] = "startup took %.1f s, over the %.0f s budget" % (
            m["load_s"], LOAD_BUDGET)
        return m

    n_slots = m["n_slots"]
    want = np.arange(n_slots) / GRID_HZ

    # ---- one published frame per slot, in order
    seen = {}
    for stamp, arrival, objs in res.frames:
        k = int(round(stamp * GRID_HZ))
        if k < 0 or k >= n_slots:
            continue
        if abs(stamp - k / GRID_HZ) > 0.004:
            m["reason"] = "published stamp %.4f is not on the 20 Hz grid" % stamp
            return m
        if k in seen:
            m["reason"] = "slot %d published more than once" % k
            return m
        seen[k] = (arrival, objs)
    m["coverage"] = len(seen) / float(n_slots)

    # ---- publication lateness, measured by the reader
    late = np.array([seen[k][0] - res.ready_at - want[k] for k in sorted(seen)])
    if late.size:
        m["late_p99"] = float(np.percentile(late, 99))
        m["late_max"] = float(late.max())
        m["late_min"] = float(late.min())
    if m["late_min"] < -0.05:
        m["reason"] = "a frame was published %.3f s before its own slot" % (-m["late_min"])
        return m
    if res.wall > m["load_s"] + duration + TAIL_BUDGET:
        m["reason"] = "run took %.1f s, longer than the replay plus tail budget" % res.wall
        return m

    # ---- accuracy against the sealed truth
    t_all = truth["t"]
    graded = truth["graded"].astype(bool)
    hits = 0
    n_graded = 0
    sq = []
    vq = []
    n_false = 0
    order = np.argsort(t_all, kind="stable")
    t_sorted = t_all[order]
    starts = np.searchsorted(t_sorted, want - 1e-6, side="left")
    ends = np.searchsorted(t_sorted, want + 1e-6, side="right")

    for k in range(n_slots):
        idx = order[starts[k]:ends[k]]
        tx = truth["x"][idx]
        ty = truth["y"][idx]
        tg = graded[idx]
        tyaw = truth["yaw"][idx]
        tvx = truth["vx"][idx]
        tvy = truth["vy"][idx]
        tlen = truth["length"][idx]
        twid = truth["width"][idx]
        n_graded += int(tg.sum())
        if k not in seen:
            continue
        objs = seen[k][1]
        if not len(objs):
            continue
        px = np.array([o[1] for o in objs])
        py = np.array([o[2] for o in objs])
        pvx = np.array([o[3] for o in objs])
        pvy = np.array([o[4] for o in objs])
        if len(idx) == 0:
            n_false += len(objs)
            continue
        d = box_distance(px, py, tx, ty, tyaw, tlen, twid)
        cost = np.where(d <= MATCH_GATE, d, 1e6)
        ri, ci = linear_sum_assignment(cost)
        paired_pred = set()
        for a, b in zip(ri, ci):
            if cost[a, b] >= 1e6:
                continue
            paired_pred.add(int(a))
            if tg[b]:
                hits += 1
                sq.append(d[a, b] ** 2)
                vq.append((pvx[a] - tvx[b]) ** 2 + (pvy[a] - tvy[b]) ** 2)
        n_false += len(objs) - len(paired_pred)

    m["recall"] = hits / float(n_graded) if n_graded else 0.0
    m["pos_rmse"] = float(np.sqrt(np.mean(sq))) if sq else float("inf")
    m["vel_rmse"] = float(np.sqrt(np.mean(vq))) if vq else float("inf")
    m["false_per_frame"] = n_false / float(max(1, len(seen)))
    m["ok"] = True
    return m


def summarise(m):
    return ("recall=%.3f pos=%.3f vel=%.3f false/frame=%.2f late_p99=%.3f "
            "late_max=%.3f cover=%.3f"
            % (m["recall"], m["pos_rmse"], m["vel_rmse"], m["false_per_frame"],
               m["late_p99"], m["late_max"], m["coverage"]))
