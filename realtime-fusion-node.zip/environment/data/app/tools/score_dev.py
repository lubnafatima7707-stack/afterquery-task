"""Score a run of fusion_node against one of the development recordings.

    python3 /app/tools/score_dev.py /app/workloads/dev_burst.bin
    python3 /app/tools/score_dev.py /app/workloads/*.bin --binary /app/build/fusion_node

The metric code in rtf_scoring.py is the same code the grader runs, so the
numbers printed here are the numbers that decide the task.  The recordings under
/app/workloads are development data; grading uses recordings you do not have.
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rtf_scoring as scoring  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("workloads", nargs="+")
    ap.add_argument("--binary", default="/app/build/fusion_node")
    ap.add_argument("--timeout", type=float, default=180.0)
    ap.add_argument("--stats", action="store_true",
                    help="let the node print its own diagnostics on stderr")
    args = ap.parse_args()

    worst = 0
    for path in args.workloads:
        truth_path = path[:-4] + "_truth.npz"
        if not os.path.isfile(truth_path):
            print("%s: no truth file beside it" % path)
            worst = 1
            continue
        truth = scoring.load_truth(truth_path)
        res = scoring.run_node(args.binary, path, args.timeout,
                               extra_args=["--stats"] if args.stats else None)
        m = scoring.score(res, truth, float(truth["duration"]))
        name = os.path.basename(path)[:-4]
        if not m["ok"]:
            print("%-12s FAILED: %s" % (name, m["reason"]))
            worst = 1
            continue
        print("%-12s recall=%.3f  position=%.3f m  velocity=%.3f m/s  "
              "false/frame=%.2f  late p99=%.3f s  late max=%.3f s  frames=%d/%d"
              % (name, m["recall"], m["pos_rmse"], m["vel_rmse"],
                 m["false_per_frame"], m["late_p99"], m["late_max"],
                 m["n_frames"], m["n_slots"]))
        if args.stats and res.stderr_tail:
            print(res.stderr_tail.rstrip())
    return worst


if __name__ == "__main__":
    sys.exit(main())
