fusion_node is the perception fusion stage of a driver assistance stack and its source is in
/app/src. It replays a recorded sensor stream at the speed the vehicle produced it. The
lidar hands over a 64 beam range image ten times a second. Radar detections come twice as
often, and localisation poses at 100 Hz. Ingest threads stage each frame into pinned memory
and push it to the device, where a worker runs the front ends as CUDA kernels and feeds what
comes back into a tracker. A publisher writes the fused moving object list out every 50 ms.
The CMake project is /app/CMakeLists.txt. Nothing is compiled yet, and ARCHITECTURE.md
has both the design and the cmake lines that produce /app/build/fusion_node.

Once it is built, launch it with /app/build/fusion_node --workload and the path of a
recording. It reads the
whole file first, prints READY on stdout, and only then starts the replay clock. From there
you get one line per cycle, flushed as it goes. Each line opens with the letter F, then the
stamp in seconds on the 0.05 s grid, then how many objects follow. After that come five
fields per object: the integer identifier, x, y, vx, vy, one space between every field.
Metres and metres per second, in the world frame the localisation pose uses. An identifier
has to stay with an object for as long as that object is tracked. DONE ends the stream. Keep
diagnostics on stderr. Nothing but the object list belongs on stdout.

Three recordings to work against are in /app/workloads, the simulator truth beside each one.
/app/tools/score_dev.py scores a run with the grader's own code. On dev_light.bin the node
is fine. On the other two it is not. Both came off a vehicle whose host stalls its capture
threads for a few hundred milliseconds, then dumps the backlog in one go, so frames land in
clumps rather than on a period. What comes out the far end stops describing the road.
Objects sit where nothing is. Reported velocities argue with what the traffic is actually
doing. The cycle drifts off its slot. Push the same frames through slowly and the answer
comes out right, so the recordings themselves are sound.

Make it behave under that delivery pattern without eating the cycle time. Grading looks at
the source only. Leave /app/src and /app/CMakeLists.txt the way you want them built. It
rebuilds with cmake in a seperate container off the same image, offline, CUDA architecture
90, then plays six recordings you have never seen, from the same simulator and the same two
delivery profiles. If the tree will not configure, or will not compile, that is the end of
it. Nothing installs at grading time either, so what you need has to be there already.

Everything is scored on a 20 Hz grid. At each grid point the truth is whatever the simulator
had moving at 2.0 m/s or faster, inside 72 m, inside 75 degrees of boresight. Slower than
that, or further out to 125 m, and it neither counts for you nor against you. Pairing is one
to one per frame by Hungarian assignment on clearance, which is the distance from the point
you reported to the object footprint and is zero anywhere on or inside the body. Nothing
pairs beyond 2.0 m. Recall is the share of truth that found a pair, position error the root
mean square clearance across those pairs. Anything you report that pairs with nothing counts
as a false object, averaged over your published frames. Lateness the grader works out for
itself. It stamps every line as it arrives, then takes off the frame stamp and the moment it
recieved READY.

To pass, all six recordings have to publish exactly one frame per grid point and come in at
recall of 0.68 or better, position error of 0.38 m or less, no more than 7.50 false objects
per frame, 99th percentile lateness under 0.050 s, and nothing later than 0.300 s. Crash and
you fail. Go quiet and you fail. Run more than three seconds past the end of a recording and
you fail as well. Getting as far as READY is allowed 45 seconds.

One H100, eight cores, and the toolkit the project already builds against. Only /app/src and
/app/CMakeLists.txt survive to grading. The recordings in /app/workloads are development
data.

You have 14400 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
