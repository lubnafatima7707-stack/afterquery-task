// Ego pose distribution.
//
// A sensor frame has to be moved into the world frame with the pose the vehicle
// held when the frame was captured, not with whatever pose happens to be newest
// when the frame reaches the fusion stage.  The two differ by the whole transport
// and queueing delay, which is exactly the quantity that grows under load, so the
// newest pose turns a latency problem into a position error that no downstream
// filter can undo.  Keeping a short history and interpolating at the capture
// timestamp removes that coupling.
#pragma once

#include <atomic>

#include "fixups.h"
#include "rtf.h"

namespace rtf {

class EgoSource {
 public:
  static constexpr int kN = 512;   // about five seconds at 100 Hz

  void publish(const OdomRec& r) {
    uint64_t w = write_.load(std::memory_order_relaxed);
    Pose& s = buf_[w % kN];
    s.t = r.t_capture;
    s.x = r.x;
    s.y = r.y;
    s.yaw = r.yaw;
    s.vx = r.vx;
    s.vy = r.vy;
    s.w = r.w;
    write_.store(w + 1, std::memory_order_release);
  }

  bool valid() const { return write_.load(std::memory_order_acquire) > 0; }

  Pose latest() const {
    uint64_t w = write_.load(std::memory_order_acquire);
    if (w == 0) return Pose{};
    return buf_[(w - 1) % kN];
  }

  // Vehicle pose at time t.  Interpolates between the two samples that bracket
  // t; ahead of the newest sample it extrapolates with the reported velocity,
  // which is only ever a few milliseconds of reach.
  bool at(double t, Pose* out) const {
#if !FIX_POSE_AT_CAPTURE
    (void)t;
    if (!valid()) return false;
    *out = latest();
    return true;
#else
    for (int attempt = 0; attempt < 4; ++attempt) {
      uint64_t w = write_.load(std::memory_order_acquire);
      if (w == 0) return false;
      uint64_t newest = w - 1;
      uint64_t oldest = (w > kN - 4) ? (w - (kN - 4)) : 0;
      Pose hi = buf_[newest % kN];
      if (t >= hi.t) {
        double dt = t - hi.t;
        if (dt > 0.5) dt = 0.5;
        *out = hi;
        out->t = t;
        out->x = hi.x + hi.vx * static_cast<float>(dt);
        out->y = hi.y + hi.vy * static_cast<float>(dt);
        out->yaw = hi.yaw + hi.w * static_cast<float>(dt);
        if (write_.load(std::memory_order_acquire) == w) return true;
        continue;
      }
      uint64_t lo_i = newest;
      bool found = false;
      while (lo_i > oldest) {
        if (buf_[(lo_i - 1) % kN].t <= t) {
          lo_i -= 1;
          found = true;
          break;
        }
        lo_i -= 1;
      }
      Pose lo = buf_[lo_i % kN];
      if (!found || lo.t > t) {
        *out = lo;
        if (write_.load(std::memory_order_acquire) == w) return true;
        continue;
      }
      Pose up = buf_[(lo_i + 1) % kN];
      double span = up.t - lo.t;
      float f = (span > 1e-9) ? static_cast<float>((t - lo.t) / span) : 0.f;
      out->t = t;
      out->x = lo.x + f * (up.x - lo.x);
      out->y = lo.y + f * (up.y - lo.y);
      out->yaw = lo.yaw + f * wrap_pi(up.yaw - lo.yaw);
      out->vx = lo.vx + f * (up.vx - lo.vx);
      out->vy = lo.vy + f * (up.vy - lo.vy);
      out->w = lo.w + f * (up.w - lo.w);
      if (write_.load(std::memory_order_acquire) - w < static_cast<uint64_t>(kN - 8))
        return true;
    }
    *out = latest();
    return true;
#endif
  }

 private:
  Pose buf_[kN] = {};
  std::atomic<uint64_t> write_{0};
};

}  // namespace rtf
