// The reference repair is three independent changes to the shipped pipeline.
//
// Each one sits behind a guard that defaults to on.  solve.sh compiles with the
// defaults, so the reference solution is simply all three applied.  The guards
// exist so that authoring/evidence can compile the same sources with any subset
// enabled and score what each change is actually worth, instead of keeping three
// drifting copies of the pipeline around.
#pragma once

#ifndef FIX_SLOT_LIFETIME
#define FIX_SLOT_LIFETIME 1   // a staging slot returns to the producer only
#endif                        // after the consumer has finished reading it

#ifndef FIX_POSE_AT_CAPTURE
#define FIX_POSE_AT_CAPTURE 1 // measurements are moved into the world frame with
#endif                        // the pose held at their capture stamp

#ifndef FIX_DRAIN_POLICY
#define FIX_DRAIN_POLICY 1    // superseded frames are skipped and the tracker is
#endif                        // locked per update rather than per drained batch
