// Pinned staging buffers for handing sensor frames to the device.
//
// A slot is owned by the producer from the moment it is taken until the consumer
// has finished every read of the matching device buffer.  Handing the same slot
// out again before that happens lets the host memcpy of a later frame race the
// still pending upload of an earlier one, and lets a later upload overwrite a
// device buffer whose kernels have not run yet.  Neither shows up while the
// consumer keeps pace, and both show up the moment it falls a frame behind.
#pragma once

#include <deque>
#include <mutex>

#include "fixups.h"
#include "rtf.h"

namespace rtf {

template <class T, int kSlots>
class StagingRing {
 public:
  void init(size_t elems) {
    elems_ = elems;
    for (int i = 0; i < kSlots; ++i) {
      CUDA_CHECK(cudaHostAlloc(reinterpret_cast<void**>(&host_[i]),
                               elems * sizeof(T), cudaHostAllocDefault));
      CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&dev_[i]), elems * sizeof(T)));
      free_.push_back(i);
    }
  }

  void destroy() {
    for (int i = 0; i < kSlots; ++i) {
      if (host_[i]) cudaFreeHost(host_[i]);
      if (dev_[i]) cudaFree(dev_[i]);
      host_[i] = nullptr;
      dev_[i] = nullptr;
    }
  }

  // Plain rotation: whatever slot comes next, in flight or not.
  int acquire() {
    int s = next_;
    next_ = (next_ + 1) % kSlots;
    return s;
  }

  // A slot nothing downstream is still reading, or -1 when every slot is in
  // flight.  Returning -1 drops the frame; blocking here would only push the
  // backlog one stage upstream.
  int try_acquire() {
    std::lock_guard<std::mutex> lk(mu_);
    if (free_.empty()) return -1;
    int s = free_.front();
    free_.pop_front();
    return s;
  }

  // Called by the consumer once every copy and kernel that reads dev(s) has
  // completed on its stream.
  void release(int s) {
#if FIX_SLOT_LIFETIME
    if (s < 0) return;
    std::lock_guard<std::mutex> lk(mu_);
    free_.push_back(s);
#else
    (void)s;
#endif
  }

  T* host(int s) { return host_[s]; }
  T* dev(int s) { return dev_[s]; }
  size_t elems() const { return elems_; }

  void submit(int s, size_t elems, cudaStream_t stream) {
    CUDA_CHECK(cudaMemcpyAsync(dev_[s], host_[s], elems * sizeof(T),
                               cudaMemcpyHostToDevice, stream));
  }

 private:
  T* host_[kSlots] = {};
  T* dev_[kSlots] = {};
  size_t elems_ = 0;
  int next_ = 0;
  std::mutex mu_;
  std::deque<int> free_;
};

}  // namespace rtf
