#!/bin/bash
set -euo pipefail

# Reference repair.  Three changes to the shipped pipeline, each in the file that
# owns the concern:
#   staging.h    a staging slot goes back to the producer only once the consumer
#                has finished reading it, and a producer with no free slot drops
#                the frame instead of overwriting one still in flight
#   ego.h        the ego pose is interpolated at a frame's capture stamp instead
#                of taking whatever sample happens to be newest
#   pipeline.*   a drained batch skips frames already superseded by a newer one
#                from the same sensor, and the tracker is locked per update
#                rather than for the whole batch
HERE="$(cd "$(dirname "$0")" && pwd)"

cp "$HERE/fixed/fixups.h"     /app/src/fixups.h
cp "$HERE/fixed/staging.h"    /app/src/staging.h
cp "$HERE/fixed/ego.h"        /app/src/ego.h
cp "$HERE/fixed/pipeline.h"   /app/src/pipeline.h
cp "$HERE/fixed/pipeline.cpp" /app/src/pipeline.cpp

cmake -S /app -B /app/build -DCMAKE_BUILD_TYPE=Release -DCMAKE_CUDA_ARCHITECTURES=90
cmake --build /app/build --parallel

# Prove the repaired node still runs end to end before handing it over.
/app/build/fusion_node --workload /app/workloads/dev_light.bin > /dev/null
