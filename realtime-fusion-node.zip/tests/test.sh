#!/bin/bash
set -uo pipefail

mkdir -p /logs/verifier
# The verifier compiles and runs the agent's own program, so the reward channel
# has to be out of reach of that program and of anything it leaves behind.  Only
# root, which runs this script and pytest, may enter or write here.
chown root:root /logs/verifier
chmod 700 /logs/verifier

cd /tests
python3 -m pytest -q -p no:cacheprovider --ctrf /logs/verifier/ctrf.json test_verify.py \
  > /logs/verifier/pytest.log 2>&1
code=$?

if [ "$code" -eq 0 ]; then
  printf "1" > /logs/verifier/reward.txt
else
  printf "0" > /logs/verifier/reward.txt
fi

cat /logs/verifier/pytest.log
exit 0
