"""Sealed verifier for realtime-fusion-node.

Builds the agent's source tree, replays every hidden workload through the node
once, and grades the published object stream against the simulator's own truth.
Publication latency is measured by this process as each line arrives, so the node
cannot report its own timing.
"""
import glob
import json
import os
import shutil
import subprocess
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import scoring  # noqa: E402

APP = "/app"
SRC = os.path.join(APP, "src")
CMAKE_LISTS = os.path.join(APP, "CMakeLists.txt")
BUILD_DIR = "/verifier_build"
BINARY = os.path.join(BUILD_DIR, "fusion_node")
WORKLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "workloads")
METRICS_PATH = "/logs/verifier/metrics.json"

BUILD_TIMEOUT = 900.0
RUN_TIMEOUT = 150.0

# Bars.  Every one of them sits between the weakest correct build measured in
# authoring/evidence and the strongest broken one; the numbers are in README.md.
# Velocity error is reported but not a bar: it separates the same builds position
# and false alarms already separate, and its spread across recordings is wide
# enough that a bar tight enough to catch anything would also be a coin flip for a
# correct solver.
BARS = {
    "min_recall": 0.68,
    "max_pos_rmse": 0.38,
    "max_false_per_frame": 7.50,
    "max_late_p99": 0.050,
    # The 99th percentile is what separates a node that holds its cycle from one
    # that does not.  The worst single frame is kept only as a guard against a
    # gross stall, set well clear of what a correct build produces, because one
    # scheduling outlier in a run of 480 frames is not evidence of anything.
    "max_late_max": 0.300,
    "min_coverage": 1.0,
}

REQUIRED_SOURCES = ["main.cpp", "pipeline.cpp", "tracker.cpp", "workload.cpp", "kernels.cu"]

_cache = {}


def workload_names():
    names = sorted(os.path.basename(p)[:-4]
                   for p in glob.glob(os.path.join(WORKLOAD_DIR, "*.bin")))
    assert names, "no hidden workloads baked into the verifier image"
    return names


def _have_cuda_device():
    try:
        r = subprocess.run(["nvidia-smi", "-L"], capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.SubprocessError):
        return False, "nvidia-smi is not available in the verifier container"
    if r.returncode != 0 or "GPU" not in r.stdout:
        return False, "nvidia-smi reported no GPU: %s %s" % (r.stdout.strip(), r.stderr.strip())
    return True, r.stdout.strip()


def _build():
    if "build" in _cache:
        return _cache["build"]
    if os.path.isdir(BUILD_DIR):
        shutil.rmtree(BUILD_DIR)
    os.makedirs(BUILD_DIR, exist_ok=True)
    log = []
    for cmd in (["cmake", "-S", APP, "-B", BUILD_DIR, "-DCMAKE_BUILD_TYPE=Release",
                 "-DCMAKE_CUDA_ARCHITECTURES=90"],
                ["cmake", "--build", BUILD_DIR, "--parallel"]):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=BUILD_TIMEOUT)
        except subprocess.TimeoutExpired:
            _cache["build"] = (False, "build timed out after %.0f s" % BUILD_TIMEOUT)
            return _cache["build"]
        log.append(r.stdout[-4000:] + r.stderr[-4000:])
        if r.returncode != 0:
            _cache["build"] = (False, "build failed:\n" + "\n".join(log)[-6000:])
            return _cache["build"]
    ok = os.path.isfile(BINARY) and os.access(BINARY, os.X_OK)
    _cache["build"] = (ok, "" if ok else "the build produced no fusion_node executable")
    return _cache["build"]


def _metrics(name):
    key = "m:" + name
    if key in _cache:
        return _cache[key]
    workload = os.path.join(WORKLOAD_DIR, name + ".bin")
    truth = scoring.load_truth(os.path.join(WORKLOAD_DIR, name + "_truth.npz"))
    duration = float(truth["duration"])
    res = scoring.run_node(BINARY, workload, RUN_TIMEOUT)
    m = scoring.score(res, truth, duration)
    m["workload"] = name
    m["stderr_tail"] = res.stderr_tail[-1500:]
    _cache[key] = m
    return m


def _record():
    rows = [v for k, v in _cache.items() if k.startswith("m:")]
    try:
        os.makedirs("/logs/verifier", exist_ok=True)
        with open(METRICS_PATH, "w") as f:
            json.dump({"bars": BARS, "runs": rows}, f, indent=1, default=str)
    except OSError:
        pass


def test_cuda_device_visible():
    ok, detail = _have_cuda_device()
    assert ok, detail


def test_sources_present():
    assert os.path.isfile(CMAKE_LISTS), "no /app/CMakeLists.txt was handed over"
    assert os.path.isdir(SRC), "no /app/src directory was handed over"
    missing = [s for s in REQUIRED_SOURCES if not os.path.isfile(os.path.join(SRC, s))]
    assert not missing, "these source files are missing from /app/src: %s" % ", ".join(missing)


def test_build_succeeds():
    ok, detail = _build()
    assert ok, detail


@pytest.mark.parametrize("name", workload_names())
def test_workload(name):
    ok, detail = _build()
    assert ok, detail
    m = _metrics(name)
    _record()
    assert m["ok"], "%s: %s\nnode stderr:\n%s" % (name, m["reason"], m["stderr_tail"])
    assert m["coverage"] >= BARS["min_coverage"], (
        "%s: published %d of %d slots" % (name, m["n_frames"], m["n_slots"]))
    assert m["late_p99"] <= BARS["max_late_p99"], (
        "%s: 99th percentile publication lateness %.3f s exceeds %.3f s"
        % (name, m["late_p99"], BARS["max_late_p99"]))
    assert m["late_max"] <= BARS["max_late_max"], (
        "%s: worst publication lateness %.3f s exceeds %.3f s"
        % (name, m["late_max"], BARS["max_late_max"]))
    assert m["recall"] >= BARS["min_recall"], (
        "%s: recall %.3f below %.3f" % (name, m["recall"], BARS["min_recall"]))
    assert m["pos_rmse"] <= BARS["max_pos_rmse"], (
        "%s: position error %.3f m above %.3f m"
        % (name, m["pos_rmse"], BARS["max_pos_rmse"]))
    assert m["false_per_frame"] <= BARS["max_false_per_frame"], (
        "%s: %.2f unmatched objects per frame, above %.2f"
        % (name, m["false_per_frame"], BARS["max_false_per_frame"]))
