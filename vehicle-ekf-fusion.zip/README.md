# vehicle-ekf-fusion

The agent writes a causal streaming estimator, `/app/estimator.py`, that fuses 50 Hz IMU and GNSS fixes into vehicle position, heading and speed. The verifier runs it on 6 hidden drives.

## Difficulty

All data is synthetic, produced by a seeded kinematic simulator (`authoring/provenance/scenarios.py`). The true trajectory is integrated first, and the sensor streams are derived from it afterwards, so ground truth is independent of any estimator.

The instruction and `sensor_spec.json` give only vendor-style nominal figures. The following effects are not described anywhere and have to be characterized from the two dev drives with truth:

- GNSS latency: each fix describes the vehicle 0.1 to 0.4 s before its stamp, and the value differs per drive, so it must be estimated online.
- Time-correlated GNSS position error.
- Two or three outages of 30 to 75 s per drive.
- Multipath intervals where a 10 to 30 m position offset ramps in over several seconds while Doppler velocity stays usable.

The estimator also has to track a gyro scale-factor error of up to 5% and biases that random walk. It must be causal, because the protocol answers each query before revealing later data, and it is graded on drives it never sees.

Each ingredient was switched off in both correct designs, the reference and the structurally different blind estimator, so no claim rests on one implementation. Hidden drives failed out of 6 at the shipped bars (`results_hidden.txt`, `results_hidden_extra.txt`):

| Ingredient switched off | Reference | Blind estimator |
|---|---|---|
| Latency estimation | 6 | 6 |
| Gyro scale factor | 5 | 5 |
| Bias states | 6 | 6 |
| Doppler velocity | 5 | 4 |
| Correlated GNSS error model (white noise instead) | 2 | 1 |
| Multipath handling | 3 | 0 |

Baselines that are not correct designs fail every hidden drive: a naive textbook loosely coupled filter, a fixed-gain complementary filter, and a reviewer-style shortcut that dead-reckons forward from the latest fix with course taken from Doppler (worst 21.52 m / 38.09 m / 10.67°).

Latency estimation, the gyro scale factor, bias states and Doppler velocity are load bearing in both designs, and stay so on the 40-drive calibration pool: the blind estimator with each one removed fails 38, 32, 40 and 24 of 40 pool drives. The correlated GNSS error model and the multipath handling are **not** claimed as necessary ingredients. The blind estimator without them fails 1 and 0 of the 6 hidden drives respectively, and 2 of 40 pool drives each, because keeping Doppler velocity already anchors heading and speed through the ramped offsets. Correlated error and multipath stay in the data as realistic effects, but the difficulty does not rest on them.

CPU only: the estimator is a small recursive filter updated one sample at a time, so there is nothing for a GPU to parallelize.

## Reference solution

`solution/estimator.py` is a 9-state extended Kalman filter. The state is position, heading, speed, gyro bias, accel bias, gyro scale factor, and a two-axis Gauss-Markov GNSS position error.

- **Latency:** chosen from a 0 to 0.5 s grid by scoring how well the change in Doppler velocity between consecutive fixes matches the IMU-propagated change over the lag-shifted interval. Each fix's innovation is then formed against the lagged state from a short history buffer.
- **Updates:** Doppler velocity is gated only for gross outliers. Position has a chi-square gate.
- **Parameters:** the noise parameters come from characterizing the dev drives.

## Verification

`tests/harness.py` runs `/app/estimator.py` as an unprivileged user in an empty directory. The hidden inputs, ground truth and verifier code under `/tests` are readable by root only. The program is given its own session and process group, and that group is killed once the drive ends, so nothing it forks off outlives the run. `/logs/verifier`, which holds `reward.txt`, is made root-only (mode 700) by `test.sh` before any agent code executes, so the reward cannot be written by the program or by a process it leaves behind. The harness streams each hidden drive over the line protocol and never sends data past a query until that query is answered.

`tests/test_verify.py` requires, on every one of the 6 drives:

- position RMSE ≤ 3.0 m
- position RMSE inside GNSS outages ≤ 4.5 m, where an outage is a gap of more than 2 s between GPS lines
- heading RMSE ≤ 0.8° over queries where true speed exceeds 2 m/s

**How the bars were set.** They were calibrated on a 40-drive pool disjoint from the hidden drives, using two independently written estimators: the reference, and `authoring/evidence/blind_estimator.py`. The second was written by an author who saw only a written contract and the dev drives. Its results:

- It meets every bar on all 40 pool drives (worst 2.31 m / 3.33 m / 0.62°).
- On the hidden drives its worst is 1.83 m / 2.80 m / 0.44°.

The reference's worst on the hidden drives is 2.61 m / 3.05 m / 0.68°. It is the weaker of the two and fails the bars on 10 of the 40 pool drives. The oracle is deterministic and passes the shipped hidden drives.

**Robustness of the reference's tuning.** Ten perturbations of its knobs were run: the chi-square gate, the Gauss-Markov time constant and sigma, the white position noise, and the Doppler noise. On the hidden drives, six pass every drive and four lose exactly one, always on position RMSE. Three of those four are drive 1006, the highest-latency drive at 0.376 s, where the blind estimator scores 1.15 m, so the thin margin is the reference's, not the bar's. On the pool each perturbation fails 8 to 13 of 40 drives, against 10 for the unperturbed reference.

**Cheat attempts** (`authoring/evidence/run_cheats.sh`) both score 0:

- A program that tries to read the hidden truth under `/tests` reports that it is unreadable.
- A program that answers with garbage fails the protocol.

**Re-running the numbers.** Run `authoring/evidence/evaluate.py` to reproduce every number above. It scores with the verifier's own `tests/scoring.py` and reads the bars from `tests/test_verify.py`. `--variants all` runs the reference and its ablations, `perturb` the knob perturbations, `blind_all` the blind estimator and its ablations, and `shortcut` the shortcut baseline. Outputs are saved as `results_*.txt`.
