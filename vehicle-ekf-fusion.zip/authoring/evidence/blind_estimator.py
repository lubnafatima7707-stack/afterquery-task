#!/usr/bin/env python3
"""
Online planar IMU/GNSS fusion for a ground vehicle (no sideslip, flat plane).

Extended Kalman filter, 10 states:
    px, py      position (m)
    th          heading (rad, unwrapped internally)
    v           forward speed (m/s)
    bg          gyro bias (rad/s)
    sg          gyro scale factor error (gyro = (1+sg)*w + bg)
    ba          accelerometer bias (m/s^2)
    ex, ey      slowly varying GNSS position error (first order Gauss-Markov)
    L           GNSS latency (s), constant per drive

A GNSS fix stamped t describes the vehicle at t - L.  The filter keeps a short
history of its own navigation solution, so the fix is compared against the
state at t - L, and the Jacobian with respect to L is the (negative) velocity
or acceleration at that time, which makes the latency observable online.

Multipath is handled by innovation gating on the position part of the fix
(the Doppler velocity is kept, with a larger variance).  A multipath episode is
declared after several rejections in a short window; the filter then rolls back
a few seconds and replays the logged data with the positions on the leading
ramp of the offset removed.

Protocol: the line protocol in instruction.md.  Reads stdin, writes one line per QUERY to stdout.
"""
import math
import sys

import numpy as np

# state indices
PX, PY, TH, V, BG, SG, BA, EX, EY, LAT = range(10)
NX = 10

DEFAULTS = dict(
    # IMU noise (per sample, 50 Hz) and bias random walks, from the sensor spec
    gyro_noise=0.003,
    accel_noise=0.02,
    gyro_rw=1e-5,
    accel_rw=1e-4,
    # process noise inflation for model mismatch
    q_scale_gyro=2.0,
    q_scale_accel=2.0,
    q_pos=0.0,          # m^2/s extra position noise
    q_sg=1e-9,          # per second
    # initial uncertainty
    bg0=0.012,
    sg0=0.03,
    ba0=0.09,
    lat0=0.25,
    lat_sd0=0.09,
    lat_min=0.05,
    lat_max=0.50,
    # GNSS model
    gm_sd=1.5,
    gm_tau=30.0,
    pos_sd=1.0,
    vel_sd=0.15,
    vel_sd_mp=0.35,
    # gating
    pos_gate=11.0,      # chi2, 2 dof, normal operation
    pos_gate_mp=9.2,    # tighter gate to leave a multipath episode
    replay_gate=12.0,   # after rollback, replayed fixes consistent with the clean state are kept
    vel_gate=16.0,
    confirm_n=3,        # rejections needed to declare multipath ...
    confirm_window=2.5, # ... within this many seconds of the first one
    mp_max_time=45.0,   # after this long of rejected positions, force re-acceptance
    rollback=True,
    rollback_s=6.0,
    reacq_keep=1.0,     # never roll back over the first seconds after an outage
    # trend detector on the estimated GNSS error: a slow multipath ramp is tracked
    # by the Gauss-Markov states without large innovations, so also flag a change
    # of the estimated error over a window that is too large for a 30 s process
    trend=True,
    trend_windows=((4.0, 3.5), (8.0, 4.5)),   # (window s, threshold m)
    trend_back=2.0,     # extra seconds to roll back before the window start
    trend_settle=12.0,  # no trend test this long after an outage
    # ablation switch (evaluate.py); every other crux is pinned off through the values above
    use_velocity=True,
)


def wrap(a):
    return (a + math.pi) % (2.0 * math.pi) - math.pi


class Estimator(object):
    def __init__(self, cfg=None):
        c = dict(DEFAULTS)
        if cfg:
            c.update(cfg)
        self.c = c
        self.x = np.zeros(NX)
        self.P = np.zeros((NX, NX))
        self.t = 0.0
        self.last_imu = None       # (t, a, w)
        # history of nav solution: t, px, py, th, v, w, a
        self.hist = []
        self.hist_len = 60
        # GNSS bookkeeping
        self.last_gps_t = None
        self.reacq_t = None
        # multipath bookkeeping
        self.in_mp = False
        self.rej_start = None
        self.suspect_t = None
        self.suspect_n = 0
        # rollback support
        self.snaps = []
        self.events = []
        self.replaying = False
        self.force_from = 1e18
        self.ehist = []            # (t, ex, ey) after each fix
        self.dbg = [] if c.get('debug') else None

    # ------------------------------------------------------------------ init
    def init(self, x, y, th, v):
        c = self.c
        self.x[:] = 0.0
        self.x[PX], self.x[PY], self.x[TH], self.x[V] = x, y, th, v
        self.x[LAT] = c['lat0']
        d = np.zeros(NX)
        d[PX] = d[PY] = 0.05 ** 2
        d[TH] = 0.002 ** 2
        d[V] = 0.02 ** 2
        d[BG] = c['bg0'] ** 2
        d[SG] = c['sg0'] ** 2
        d[BA] = c['ba0'] ** 2
        d[EX] = d[EY] = c['gm_sd'] ** 2
        d[LAT] = c['lat_sd0'] ** 2
        self.P = np.diag(d)
        self.t = 0.0
        self.hist = []

    # ------------------------------------------------------------ propagate
    def _push_hist(self, w, a):
        x = self.x
        self.hist.append((self.t, x[PX], x[PY], x[TH], x[V], w, a))
        if len(self.hist) > self.hist_len:
            del self.hist[0]

    def imu(self, t, a, w):
        if self.c['rollback']:
            self.events.append((0, t, a, w))
        if self.last_imu is None:
            self.last_imu = (t, a, w)
            self.t = t
            x = self.x
            self._push_hist((w - x[BG]) / (1.0 + x[SG]), a - x[BA])
            return
        t0, a0, w0 = self.last_imu
        dt = t - t0
        self.last_imu = (t, a, w)
        if dt <= 0.0:
            return
        self._propagate(dt, 0.5 * (a0 + a), 0.5 * (w0 + w))
        self.t = t
        x = self.x
        self._push_hist((w - x[BG]) / (1.0 + x[SG]), a - x[BA])

    def _propagate(self, dt, am, gm):
        c = self.c
        x = self.x
        th, v, bg, sg, ba = x[TH], x[V], x[BG], x[SG], x[BA]
        k = 1.0 / (1.0 + sg)
        w = (gm - bg) * k
        a = am - ba
        thm = th + 0.5 * w * dt
        vm = v + 0.5 * a * dt
        if vm < 0.0:
            vm = 0.0
        cm, sm = math.cos(thm), math.sin(thm)
        x[PX] += vm * cm * dt
        x[PY] += vm * sm * dt
        x[TH] = th + w * dt
        vn = v + a * dt
        x[V] = vn if vn > 0.0 else 0.0
        phi = math.exp(-dt / c['gm_tau'])
        x[EX] *= phi
        x[EY] *= phi

        F = np.eye(NX)
        dth_dbg = -k * dt
        dth_dsg = -w * k * dt
        F[TH, BG] = dth_dbg
        F[TH, SG] = dth_dsg
        F[V, BA] = -dt
        dpx_dth = -vm * sm * dt
        dpy_dth = vm * cm * dt
        F[PX, TH] = dpx_dth
        F[PY, TH] = dpy_dth
        F[PX, V] = cm * dt
        F[PY, V] = sm * dt
        F[PX, BG] = dpx_dth * 0.5 * dth_dbg
        F[PY, BG] = dpy_dth * 0.5 * dth_dbg
        F[PX, SG] = dpx_dth * 0.5 * dth_dsg
        F[PY, SG] = dpy_dth * 0.5 * dth_dsg
        F[PX, BA] = -cm * dt * 0.5 * dt
        F[PY, BA] = -sm * dt * 0.5 * dt
        F[EX, EX] = phi
        F[EY, EY] = phi

        P = F @ self.P @ F.T
        P[TH, TH] += (c['gyro_noise'] * dt * k) ** 2 * c['q_scale_gyro']
        P[V, V] += (c['accel_noise'] * dt) ** 2 * c['q_scale_accel']
        P[PX, PX] += c['q_pos'] * dt
        P[PY, PY] += c['q_pos'] * dt
        P[BG, BG] += c['gyro_rw'] ** 2 * dt
        P[SG, SG] += c['q_sg'] * dt
        P[BA, BA] += c['accel_rw'] ** 2 * dt
        qe = c['gm_sd'] ** 2 * (1.0 - phi * phi)
        P[EX, EX] += qe
        P[EY, EY] += qe
        self.P = P

    # --------------------------------------------------------------- history
    def _hist_at(self, tm):
        """Interpolated nav solution (px, py, th, v, w, a) at time tm."""
        h = self.hist
        if tm <= h[0][0]:
            return h[0][1:]
        if tm >= h[-1][0]:
            return h[-1][1:]
        i = len(h) - 1
        while h[i - 1][0] > tm:
            i -= 1
        r0, r1 = h[i - 1], h[i]
        f = (tm - r0[0]) / (r1[0] - r0[0])
        return tuple(r0[j] + f * (r1[j] - r0[j]) for j in range(1, 7))

    # ---------------------------------------------------------------- update
    def _update(self, r, H, R):
        P = self.P
        PHt = P @ H.T
        S = H @ PHt + R
        K = PHt @ np.linalg.inv(S)
        dx = K @ r
        self.x += dx
        # keep the stored nav history consistent with the corrected state, so the
        # next (delayed) fix is not compared against pre-correction values
        d0, d1, d2, d3 = dx[PX], dx[PY], dx[TH], dx[V]
        self.hist = [(h[0], h[1] + d0, h[2] + d1, h[3] + d2, h[4] + d3, h[5], h[6])
                     for h in self.hist]
        IKH = np.eye(NX) - K @ H
        P = IKH @ P @ IKH.T + K @ R @ K.T
        self.P = 0.5 * (P + P.T)
        c = self.c
        x = self.x
        if x[LAT] < c['lat_min']:
            x[LAT] = c['lat_min']
        elif x[LAT] > c['lat_max']:
            x[LAT] = c['lat_max']
        if x[V] < 0.0:
            x[V] = 0.0

    # -------------------------------------------------------------- rollback
    def _snapshot(self, tg):
        self.snaps.append((tg, self.x.copy(), self.P.copy(), self.last_imu, list(self.hist),
                           self.t, self.last_gps_t, self.reacq_t, len(self.events)))
        tcut = tg - self.c['rollback_s'] - self.c['confirm_window'] - 2.0
        while len(self.snaps) > 1 and self.snaps[1][0] < tcut:
            del self.snaps[0]
        n0 = self.snaps[0][8]
        if n0 > 3000:
            self.events = self.events[n0:]
            self.snaps = [s[:8] + (s[8] - n0,) for s in self.snaps]

    def _rollback(self, t_back):
        """Restore the last snapshot stamped at or before t_back and replay the
        logged events, rejecting every GNSS position stamped at or after t_back."""
        idx = None
        for i in range(len(self.snaps) - 1, -1, -1):
            if self.snaps[i][0] <= t_back:
                idx = i
                break
        if idx is None:
            idx = 0
        s = self.snaps[idx]
        evs = self.events[s[8]:]
        (_, x, P, self.last_imu, hist, self.t, self.last_gps_t, self.reacq_t, n) = s
        self.x = x.copy()
        self.P = P.copy()
        self.hist = list(hist)
        self.snaps = self.snaps[:idx]
        self.events = self.events[:n]
        self.ehist = [e for e in self.ehist if e[0] < s[0]]
        self.replaying = True
        self.force_from = min(t_back, s[0]) if idx == 0 and s[0] > t_back else t_back
        for e in evs:
            if e[0] == 0:
                self.imu(e[1], e[2], e[3])
            else:
                self.gps(e[1], e[2], e[3], e[4], e[5])
        self.replaying = False
        self.force_from = 1e18

    # ------------------------------------------------------------------ GNSS
    def gps(self, t, zx, zy, zvx, zvy):
        c = self.c
        if c['rollback']:
            self._snapshot(t)
            self.events.append((1, t, zx, zy, zvx, zvy))
        if self.last_gps_t is None or t - self.last_gps_t > 2.0:
            self.reacq_t = t
        self.last_gps_t = t

        # ---- velocity update
        if c['use_velocity']:
            x = self.x
            tm = t - x[LAT]
            px_m, py_m, th_m, v_m, w_m, a_m = self._hist_at(tm)
            cm, sm = math.cos(th_m), math.sin(th_m)
            hv = np.array([v_m * cm, v_m * sm])
            Hv = np.zeros((2, NX))
            Hv[0, TH] = -v_m * sm
            Hv[1, TH] = v_m * cm
            Hv[0, V] = cm
            Hv[1, V] = sm
            # d/dL of v(t - L): minus the acceleration vector at t - L
            Hv[0, LAT] = -(a_m * cm - v_m * w_m * sm)
            Hv[1, LAT] = -(a_m * sm + v_m * w_m * cm)
            vsd = c['vel_sd_mp'] if self.in_mp else c['vel_sd']
            Rv = np.eye(2) * vsd ** 2
            rv = np.array([zvx, zvy]) - hv
            Sv = Hv @ self.P @ Hv.T + Rv
            dv2 = float(rv @ np.linalg.solve(Sv, rv))
            if dv2 > c['vel_gate']:
                Rv = Rv * (dv2 / c['vel_gate'])
            self._update(rv, Hv, Rv)

        # ---- position update
        x = self.x
        tm = t - x[LAT]
        d = self.t - tm
        px_m, py_m, th_m, v_m, w_m, a_m = self._hist_at(tm)
        cm, sm = math.cos(th_m), math.sin(th_m)
        hp = np.array([px_m + x[EX], py_m + x[EY]])
        Hp = np.zeros((2, NX))
        Hp[0, PX] = 1.0
        Hp[1, PY] = 1.0
        Hp[0, EX] = 1.0
        Hp[1, EY] = 1.0
        Hp[0, TH] = d * v_m * sm
        Hp[1, TH] = -d * v_m * cm
        Hp[0, V] = -d * cm
        Hp[1, V] = -d * sm
        Hp[0, LAT] = -v_m * cm
        Hp[1, LAT] = -v_m * sm
        Rp = np.eye(2) * c['pos_sd'] ** 2
        rp = np.array([zx, zy]) - hp
        Sp = Hp @ self.P @ Hp.T + Rp
        dp2 = float(rp @ np.linalg.solve(Sp, rp))

        forced = self.replaying and t >= self.force_from
        if forced and c.get('replay_gate') is not None and not self.in_mp \
                and dp2 < c['replay_gate']:
            # replay mode 'gate': keep fixes that agree with the clean pre-episode state
            forced = False
        gate = c['pos_gate_mp'] if self.in_mp else c['pos_gate']
        accept = (dp2 < gate) and not forced
        if not accept and not forced and self.in_mp and self.rej_start is not None \
                and t - self.rej_start > c['mp_max_time']:
            # rejected for too long: the filter is more likely wrong than the fix
            self.P[PX, PX] += 25.0
            self.P[PY, PY] += 25.0
            accept = True
        if self.dbg is not None:
            self.dbg.append((t, dp2, accept, forced, self.replaying))
        if accept:
            self._update(rp, Hp, Rp)
            if self.in_mp:
                self.in_mp = False
                self.rej_start = None
            self._trend_check(t)
            return
        if forced:
            self.in_mp = True
            if self.rej_start is None:
                self.rej_start = t
            return
        if self.in_mp:
            return
        # not yet in a multipath episode: count rejections
        if self.suspect_t is None or t - self.suspect_t > c['confirm_window']:
            self.suspect_t = t
            self.suspect_n = 1
        else:
            self.suspect_n += 1
        if self.suspect_n >= c['confirm_n'] and not self.replaying:
            ts = self.suspect_t
            self.suspect_t = None
            self.suspect_n = 0
            if c['rollback']:
                tb = ts - c['rollback_s']
                if self.reacq_t is not None and self.reacq_t > tb - 1.0:
                    tb = max(tb, self.reacq_t + c['reacq_keep'])
                self._rollback(min(tb, ts))
            self.in_mp = True
            self.rej_start = ts

    def _trend_check(self, t):
        c = self.c
        x = self.x
        eh = self.ehist
        eh.append((t, x[EX], x[EY]))
        wmax = max(w for w, _ in c['trend_windows'])
        while len(eh) > 2 and eh[1][0] < t - wmax - 1.0:
            del eh[0]
        if not c['trend'] or self.replaying or self.in_mp:
            return
        if self.reacq_t is not None and t - self.reacq_t < c['trend_settle']:
            return
        for w, thr in c['trend_windows']:
            old = None
            for e in eh:
                if e[0] <= t - w:
                    old = e
                else:
                    break
            if old is None or t - old[0] > w + 1.0:
                continue
            de = math.hypot(x[EX] - old[1], x[EY] - old[2])
            if de > thr:
                tb = old[0] - c['trend_back']
                if self.reacq_t is not None and self.reacq_t > tb - 1.0:
                    tb = max(tb, self.reacq_t + c['reacq_keep'])
                if self.dbg is not None:
                    self.dbg.append((t, -de, False, False, 'trend'))
                self.suspect_t = None
                self.suspect_n = 0
                if c['rollback']:
                    self._rollback(tb)
                self.in_mp = True
                self.rej_start = tb
                return

    # ----------------------------------------------------------------- query
    def query(self, t):
        x = self.x
        px, py, th, v = x[PX], x[PY], x[TH], x[V]
        dt = t - self.t
        if 0.0 < dt < 1.0 and self.last_imu is not None:
            w = (self.last_imu[2] - x[BG]) / (1.0 + x[SG])
            a = self.last_imu[1] - x[BA]
            thm = th + 0.5 * w * dt
            vm = max(v + 0.5 * a * dt, 0.0)
            px += vm * math.cos(thm) * dt
            py += vm * math.sin(thm) * dt
            th += w * dt
            v = max(v + a * dt, 0.0)
        return px, py, wrap(th), v


def main():
    est = Estimator()
    rd = sys.stdin.readline
    out = sys.stdout
    while True:
        line = rd()
        if not line:
            break
        p = line.split()
        if not p:
            continue
        k = p[0]
        if k == 'IMU':
            est.imu(float(p[1]), float(p[2]), float(p[3]))
        elif k == 'GPS':
            est.gps(float(p[1]), float(p[2]), float(p[3]), float(p[4]), float(p[5]))
        elif k == 'QUERY':
            px, py, th, v = est.query(float(p[1]))
            out.write('%s %.4f %.4f %.6f %.4f\n' % (p[1], px, py, th, v))
            out.flush()
        elif k == 'INIT':
            est.init(float(p[1]), float(p[2]), float(p[3]), float(p[4]))
        elif k == 'END':
            break


if __name__ == '__main__':
    main()
