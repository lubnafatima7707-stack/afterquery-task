# Cheat attempts and baselines

Every number here comes from `evaluate.py` and from `run_cheats.sh`. `evaluate.py` scores with the verifier's own `tests/scoring.py` and reads the bars from `tests/test_verify.py`. Its outputs are saved in `results_hidden.txt` and `results_hidden_extra.txt` (the 6 hidden drives, seeds 1001 to 1006) and in `results_pool_a.txt`, `results_pool_b.txt` and `results_pool_extra.txt` (the 40 drive calibration pool, seeds 100 to 139).

The bars apply to every drive: position ≤ 3.0 m, outage ≤ 4.5 m and heading ≤ 0.8°. Outages are gaps of more than 2 s between GPS lines.

## Cheats, run through the real verifier container

- **`cheats/read_tests.py`** tries to read `/tests/scenarios/*/truth.csv` and answer from it. It reports `/tests readable: False, truth found: False`. Reward 0.
- **`cheats/garbage.py`** answers every query with `ok`. It fails the protocol check. Reward 0.
- **The reference solution**, run as a positive control, gets reward 1.

## Each ingredient switched off in both correct designs (6 hidden drives)

Every crux was removed from the reference and, separately, from the structurally different blind estimator, so no claim rests on one implementation. Cells give drives failed out of 6, then the worst position / outage / heading RMSE.

| Ingredient switched off | Reference | Blind estimator |
|---|---|---|
| Latency estimation | 6 (24.08 m / 41.79 m / 4.40°) | 6 (14.47 m / 25.20 m / 2.99°) |
| Gyro scale factor | 5 (11.28 m / 16.02 m / 3.71°) | 5 (14.89 m / 15.38 m / 3.44°) |
| Bias states | 6 (213.88 m / 339.85 m / 115.19°) | 6 (1110.16 m / 1062.47 m / 119.54°) |
| Doppler velocity | 5 (7.39 m / 5.38 m / 1.13°) | 4 (9.21 m / 5.44 m / 0.91°) |
| Correlated GNSS error model (white noise at the spec's 1.8 m instead) | 2 (3.16 m / 3.99 m / 0.81°) | 1 (3.19 m / 3.83 m / 0.51°) |
| Multipath handling (reference: position gate; blind: gate, rollback and trend detector) | 3 (3.42 m / 3.60 m / 0.67°) | 0 (2.52 m / 3.28 m / 0.44°) |

With nothing switched off, the reference's worst is 2.61 m / 3.05 m / 0.68° and the blind estimator's is 1.83 m / 2.80 m / 0.44°.

Each metric catches failures on its own. For the reference, the heading bar alone fails 6 drives for no latency, 5 for no scale factor and 3 for no Doppler velocity. The outage bar alone fails 5, 4 and 2 of those same variants' drives. The position bar alone fails 3 drives for no position gate.

## Baselines that are not correct designs (6 hidden drives)

| Estimator | Drives failed | Worst position / outage / heading |
|---|---|---|
| Naive textbook loosely coupled filter (reference with latency, scale, bias and correlated error all off) | 6 | 226.43 m / 357.92 m / 103.49° |
| Fixed gain complementary filter (`independent_estimator.py`) | 6 | 21.83 m / 41.57 m / 7.15° |
| Reviewer style shortcut (`shortcut_estimator.py`: latest fix dead reckoned forward, course from Doppler, biases averaged from Doppler increments) | 6 | 21.52 m / 38.09 m / 10.67° |

## Reference knob perturbations (6 hidden drives)

The reference's tuning knobs were moved well off their chosen values to check its pass does not hold only at one exact setting.

| Knob, default → perturbed | Drives failed | Failure |
|---|---|---|
| gate 9.21 → 6.0 | 0 | |
| gate 9.21 → 13.8 | 1 | drive 1006, position 3.80 m |
| gm_tau 30 → 15 s | 0 | |
| gm_tau 30 → 60 s | 0 | |
| gm_sigma 1.5 → 1.0 m | 0 | |
| gm_sigma 1.5 → 2.25 m | 1 | drive 1006, position 3.70 m |
| pos_white 1.0 → 0.7 m | 0 | |
| pos_white 1.0 → 1.4 m | 1 | drive 1006, position 3.76 m |
| vel_noise 0.15 → 0.10 m/s | 1 | drive 1002, position 3.36 m |
| vel_noise 0.15 → 0.25 m/s | 0 | |

Six of the ten perturbations pass every drive and four lose exactly one, always on position RMSE. Three of the four are drive 1006, which has the largest latency of the six (0.376 s) and where the reference's unperturbed position RMSE is 2.14 m. The blind estimator's position RMSE on that drive is 1.15 m, so the thin margin belongs to the reference's design, not to the bar.

## Calibration pool (40 drives, disjoint from the hidden drives)

- **Blind independent estimator:** 0 of 40 drives fail. Worst 2.31 m / 3.33 m / 0.62°.
- **Reference:** 10 of 40 drives fail. Worst 4.56 m / 7.31 m / 1.11°.
- **Blind estimator with one crux removed** (`results_pool_extra.txt`): no latency estimation fails 38 of 40, no gyro scale factor 32, no bias states 40, no Doppler velocity 24, white GNSS noise instead of the correlated model 2, no multipath handling 2.
- **Reviewer style shortcut:** 40 of 40 drives fail. Worst 38.02 m / 64.24 m / 8.04°.
- **Reference knob perturbations:** each of the ten fails between 8 and 13 of 40 drives, against 10 for the unperturbed reference. They move the reference within its existing pool failure rate rather than exposing a setting it depends on.

## What the ablations support

Latency estimation, the gyro scale factor, bias states and Doppler velocity are load bearing in both correct designs, on both the hidden drives and the pool. The correlated GNSS error model and multipath handling are not: the blind estimator without them fails 1 and 0 of the 6 hidden drives and 2 of 40 pool drives each, because keeping Doppler velocity already anchors heading and speed through the ramped offsets. README.md and task.toml therefore do not claim either as a necessary ingredient. The effects stay in the data, since real receivers have them, but the difficulty does not rest on them.
