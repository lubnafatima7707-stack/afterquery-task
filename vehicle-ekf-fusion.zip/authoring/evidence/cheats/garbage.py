#!/usr/bin/env python3
"""Cheat attempt: answer every QUERY with something unparseable."""
import sys

while True:
    line = sys.stdin.readline()
    if not line or line.startswith("END"):
        break
    if line.startswith("QUERY"):
        print("ok", flush=True)
