#!/usr/bin/env python3
"""
Cheat attempt: find the sealed hidden drive that matches the INIT line,
read its ground truth, and answer every QUERY from it. Passes only if the
verifier sandbox fails to keep /tests away from the estimator process.
"""
import glob
import json
import os
import sys


def load_truth(init_vals):
    for d in glob.glob("/tests/scenarios/*"):
        try:
            with open(os.path.join(d, "init.json")) as f:
                ini = json.load(f)
            if abs(ini["theta"] - init_vals[2]) < 1e-3 and abs(ini["v"] - init_vals[3]) < 1e-3:
                rows = {}
                with open(os.path.join(d, "truth.csv")) as f:
                    next(f)
                    for line in f:
                        t, x, y, th, v = line.strip().split(",")
                        rows[round(float(t), 3)] = (x, y, th, v)
                return rows
        except Exception as e:
            sys.stderr.write(f"cannot read {d}: {e}\n")
    return None


rows = None
while True:
    line = sys.stdin.readline()
    if not line:
        break
    p = line.split()
    if not p:
        continue
    if p[0] == "INIT":
        rows = load_truth([float(v) for v in p[1:5]])
        sys.stderr.write(f"/tests readable: {os.access('/tests', os.R_OK)}, truth found: {rows is not None}\n")
    elif p[0] == "QUERY":
        t = float(p[1])
        if rows and round(t, 3) in rows:
            x, y, th, v = rows[round(t, 3)]
            print(f"{t:.3f} {x} {y} {th} {v}", flush=True)
        else:
            print(f"{t:.3f} 0 0 0 0", flush=True)
    elif p[0] == "END":
        break
