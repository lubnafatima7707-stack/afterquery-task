"""
Scores estimator variants on generated drives, in process, through exactly
the same protocol lines the verifier sends, with the verifier's own metric
code (tests/scoring.py) and bars (read from tests/test_verify.py). Used to
calibrate thresholds on a pool of drives that is disjoint from the hidden
verifier drives, and to record ablation results.

  python evaluate.py --seeds 100-139 --variants reference
  python evaluate.py --seeds 1001-1006 --variants all
  python evaluate.py --seeds 1001-1006 --variants perturb
  python evaluate.py --seeds 1001-1006 --variants blind_all,shortcut

Variant groups: all (reference and its ablations), perturb (reference knob
perturbations), blind_all (blind_estimator.py and its ablations).
"""
import argparse
import io
import os
import re
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "authoring", "provenance"))
sys.path.insert(0, os.path.join(ROOT, "tests"))
sys.path.insert(0, os.path.join(ROOT, "solution"))
sys.path.insert(0, HERE)

import scenarios  # noqa: E402
import scoring  # noqa: E402
import estimator as reference  # noqa: E402
import blind_estimator as blind  # noqa: E402
import shortcut_estimator as shortcut  # noqa: E402


def _bars():
    """The bars exactly as the verifier defines them."""
    src = open(os.path.join(ROOT, "tests", "test_verify.py")).read()
    get = lambda k: float(re.search(rf"^{k}\s*=\s*([0-9.]+)", src, re.M).group(1))
    return get("POS_RMSE_MAX_M"), get("OUTAGE_RMSE_MAX_M"), get("HEADING_RMSE_MAX_DEG")


BARS = _bars()

VARIANTS = {
    "reference": {},
    "no_latency": {"estimate_latency": False},
    "no_scale": {"estimate_scale": False},
    "white_gnss": {"model_correlated_gnss": False},
    "no_gate": {"use_gate": False},
    "no_velocity": {"use_velocity": False},
    "no_bias": {"estimate_bias": False},
    # what a textbook loosely coupled EKF looks like: position + Doppler,
    # gated, but no latency, no scale factor, no bias states, white GNSS noise
    "naive": {"estimate_latency": False, "estimate_scale": False,
              "estimate_bias": False, "model_correlated_gnss": False},
}

# the reference's own tuning knobs moved well off their chosen values, to show
# its pass is not a knife edge that holds only at one exact setting
PERTURB = {
    "ref_gate_6.0": {"gate": 6.0},
    "ref_gate_13.8": {"gate": 13.8},
    "ref_gm_tau_15": {"gm_tau": 15.0},
    "ref_gm_tau_60": {"gm_tau": 60.0},
    "ref_gm_sigma_1.0": {"gm_sigma": 1.0},
    "ref_gm_sigma_2.25": {"gm_sigma": 2.25},
    "ref_pos_white_0.7": {"pos_white": 0.7},
    "ref_pos_white_1.4": {"pos_white": 1.4},
    "ref_vel_noise_0.10": {"vel_noise": 0.10},
    "ref_vel_noise_0.25": {"vel_noise": 0.25},
}

# the same cruxes switched off inside the structurally different blind
# estimator, so each difficulty claim is tested on a second correct design
BLIND_VARIANTS = {
    "blind": {},
    # latency pinned at zero: no initial uncertainty, no process noise, floor at 0
    "blind_no_latency": {"lat0": 0.0, "lat_sd0": 0.0, "lat_min": 0.0},
    "blind_no_scale": {"sg0": 0.0, "q_sg": 0.0},
    "blind_no_bias": {"bg0": 0.0, "ba0": 0.0, "gyro_rw": 0.0, "accel_rw": 0.0},
    # GNSS error states pinned at zero, all of the spec accuracy treated as white
    "blind_white_gnss": {"gm_sd": 0.0, "pos_sd": 1.8},
    "blind_no_velocity": {"use_velocity": False},
    # no gate, no multipath detection, no rollback
    "blind_no_multipath": {"pos_gate": 1e9, "pos_gate_mp": 1e9, "replay_gate": None,
                           "rollback": False, "trend": False},
}

GROUPS = {"all": list(VARIANTS), "perturb": list(PERTURB), "blind_all": list(BLIND_VARIANTS)}


def blind_handle(est, line, out):
    p = line.split()
    if not p:
        return True
    k = p[0]
    if k == "IMU":
        est.imu(float(p[1]), float(p[2]), float(p[3]))
    elif k == "GPS":
        est.gps(float(p[1]), float(p[2]), float(p[3]), float(p[4]), float(p[5]))
    elif k == "QUERY":
        px, py, th, v = est.query(float(p[1]))
        out.write("%s %.4f %.4f %.6f %.4f\n" % (p[1], px, py, th, v))
    elif k == "INIT":
        est.init(float(p[1]), float(p[2]), float(p[3]), float(p[4]))
    elif k == "END":
        return False
    return True


def maker(name):
    if name in VARIANTS or name in PERTURB:
        cfg = VARIANTS.get(name, PERTURB.get(name))
        return (lambda: reference.Estimator(**cfg)), reference.handle
    if name in BLIND_VARIANTS:
        cfg = BLIND_VARIANTS[name]
        return (lambda: blind.Estimator(dict(cfg))), blind_handle
    if name == "shortcut":
        return shortcut.Estimator, shortcut.handle
    raise SystemExit(f"unknown variant {name}")


def run_lines(make_estimator, lines, handle):
    est = make_estimator()
    out = io.StringIO()
    for line in lines:
        if not handle(est, line, out):
            break
    rows = [list(map(float, r.split())) for r in out.getvalue().splitlines()]
    return np.array(rows)


def run_program(path, lines, timeout_s=120):
    """Runs a standalone estimator program over the real line protocol
    (threaded, works on Windows and Linux) and returns its answers."""
    import queue
    import subprocess
    import threading
    proc = subprocess.Popen([sys.executable, path], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL, text=True, bufsize=1)
    q = queue.Queue()

    def reader():
        for out in proc.stdout:
            q.put(out)
        q.put(None)

    threading.Thread(target=reader, daemon=True).start()
    deadline = time.time() + timeout_s
    answers, buf = [], []
    for line in lines:
        buf.append(line)
        if line.startswith("QUERY"):
            proc.stdin.write("\n".join(buf) + "\n")
            proc.stdin.flush()
            buf = []
            resp = q.get(timeout=max(0.001, deadline - time.time()))
            if resp is None:
                raise RuntimeError("program exited early")
            answers.append([float(v) for v in resp.split()])
    proc.stdin.write("\n".join(buf) + "\n")
    proc.stdin.close()
    proc.wait(timeout=10)
    return np.array(answers)


def parse_seeds(s):
    seeds = []
    for part in s.split(","):
        if "-" in part:
            a, b = part.split("-")
            seeds.extend(range(int(a), int(b) + 1))
        else:
            seeds.append(int(part))
    return seeds


def fails(m):
    pos, out, head = BARS
    return m["pos_rmse"] > pos or m["outage_rmse"] > out or m["heading_rmse_deg"] > head


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", default="100-139")
    ap.add_argument("--variants", default="reference")
    ap.add_argument("--program", action="append", default=[],
                    help="name=path of a standalone estimator program, run over the line protocol")
    ap.add_argument("--out", help="also write the log here, with LF line endings")
    args = ap.parse_args()
    seeds = parse_seeds(args.seeds)
    names = []
    if args.variants != "none":
        for tok in args.variants.split(","):
            names.extend(GROUPS.get(tok, [tok]))

    log = []

    def emit(s):
        print(s, flush=True)
        log.append(s)

    makers = {n: maker(n) for n in names}
    programs = dict(p.split("=", 1) for p in args.program)
    results = {n: [] for n in list(makers) + list(programs)}
    w = max(12, max(len(n) for n in results))
    for seed in seeds:
        sc = scenarios.generate(seed)
        lines = scoring.build_lines(sc["init"], sc["imu"], sc["gnss"], sc["queries"])
        jobs = [(n, lambda mk=mk, h=h: run_lines(mk, lines, h)) for n, (mk, h) in makers.items()]
        jobs += [(n, lambda p=p: run_program(p, lines)) for n, p in programs.items()]
        for n, job in jobs:
            t0 = time.time()
            est = job()
            m = scoring.metrics(est, sc["truth_q"], scoring.outage_windows(sc["gnss"][:, 0]))
            m["secs"] = time.time() - t0
            results[n].append(m)
            emit(f"seed {seed:5d} {n:{w}s} pos {m['pos_rmse']:7.2f}  outage {m['outage_rmse']:7.2f}  "
                 f"head {m['heading_rmse_deg']:6.2f} deg  L={sc['params']['gnss_latency_s']:.3f}  "
                 f"{'FAIL' if fails(m) else 'pass'}  ({m['secs']:.1f}s)")

    emit(f"\nsummary over {len(seeds)} drives (mean / worst), bars {BARS[0]} m / {BARS[1]} m / {BARS[2]} deg")
    for n, ms in results.items():
        pr = np.array([m["pos_rmse"] for m in ms])
        orr = np.array([m["outage_rmse"] for m in ms])
        hr = np.array([m["heading_rmse_deg"] for m in ms])
        nf = sum(fails(m) for m in ms)
        emit(f"{n:{w}s} pos {pr.mean():6.2f} / {pr.max():6.2f}   outage {orr.mean():6.2f} / {orr.max():6.2f}   "
             f"head {hr.mean():5.2f} / {hr.max():5.2f}   failed {nf} of {len(ms)}")
    if args.out:
        with open(args.out, "w", newline="\n") as f:
            f.write("\n".join(log) + "\n")


if __name__ == "__main__":
    main()
