#!/usr/bin/env python3
"""
A second estimator, written separately from the reference and deliberately
different in structure, used to check that the thresholds are reachable by
more than one correct design (the reviewer's point that thresholds were only
calibrated against the reference and its own ablations).

No covariance propagation at all: fixed gain complementary loops.
  heading  : gyro integration with bias and scale factor, corrected by GNSS
             course over ground when moving (PI loop, scale adapted by the
             product of course error and yaw rate)
  speed    : accel integration, corrected by GNSS ground speed (PI loop on
             accel bias)
  latency  : grid search on GNSS speed magnitude against the lagged
             dead reckoned speed
  position : dead reckoning plus a small fixed gain pull toward GNSS, with a
             residual magnitude gate that widens with time since the last
             accepted fix
Still the author's code, so it is a different design, not an independent
author.
"""
import math
import sys
from collections import deque

import numpy as np


def wrap(a):
    return (a + math.pi) % (2.0 * math.pi) - math.pi


class Estimator:
    def __init__(self):
        self.lat_grid = np.arange(0.0, 0.501, 0.01)
        self.lat_score = np.zeros_like(self.lat_grid)
        self.lat_n = 0
        self.L = 0.25

    def init(self, x, y, th, v):
        self.x, self.y, self.th, self.v = x, y, th, v
        self.bg = 0.0
        self.ba = 0.0
        self.sf = 0.0
        self.t = 0.0
        self.w_last = 0.0
        self.hist = deque(maxlen=50)
        self.hist.append([0.0, x, y, th, v])
        self.res_scale = 3.0
        self.last_accept = 0.0
        self.big_eth = 0
        self.big_ev = 0
        self.last_fix_t = 0.0

    def imu(self, t, am, wm):
        dt = t - self.t
        if dt <= 0.0:
            return
        self.t = t
        w = (wm - self.bg) / (1.0 + self.sf)
        a = am - self.ba
        v_new = max(self.v + a * dt, 0.0)
        v_mid = 0.5 * (self.v + v_new)
        th_mid = self.th + 0.5 * w * dt
        self.x += v_mid * math.cos(th_mid) * dt
        self.y += v_mid * math.sin(th_mid) * dt
        self.th += w * dt
        self.v = v_new
        self.w_last = w
        self.hist.append([t, self.x, self.y, self.th, self.v])

    def _lagged(self, tl):
        H = np.array(self.hist)
        return [float(np.interp(tl, H[:, 0], H[:, i])) for i in range(1, 5)]

    def _shift(self, dx=0.0, dy=0.0, dth=0.0, dv=0.0):
        self.x += dx
        self.y += dy
        self.th += dth
        self.v += dv
        for e in self.hist:
            e[1] += dx
            e[2] += dy
            e[3] += dth
            e[4] += dv

    def gps(self, t, zx, zy, zvx, zvy):
        gap = t - self.last_fix_t
        self.last_fix_t = t
        H = np.array(self.hist)
        gs = math.hypot(zvx, zvy)
        tq = t - self.lat_grid
        vv = np.interp(tq, H[:, 0], H[:, 4])
        r2 = (gs - vv) ** 2
        if r2.min() < 1.0:
            self.lat_score = 0.995 * self.lat_score + r2
            self.lat_n += 1
        if self.lat_n >= 25:
            self.L = float(self.lat_grid[int(np.argmin(self.lat_score))])
        xl, yl, thl, vl = self._lagged(t - self.L)

        # small errors go through the PI loops; a run of large errors (typical
        # right after a long outage) snaps the state instead of locking out
        ev = gs - vl
        if abs(ev) < 1.5:
            self._shift(dv=0.2 * ev)
            self.ba -= 0.01 * ev
            self.big_ev = 0
        else:
            self.big_ev += 1
            if self.big_ev >= 5:
                self._shift(dv=ev)
                self.big_ev = 0

        if gs > 3.0:
            eth = wrap(math.atan2(zvy, zvx) - thl)
            if abs(eth) < 0.2:
                self._shift(dth=0.1 * eth)
                self.bg -= 0.002 * eth
                self.sf = min(max(self.sf - 0.2 * eth * self.w_last, -0.08), 0.08)
                self.big_eth = 0
            else:
                self.big_eth += 1
                if self.big_eth >= 5:
                    self._shift(dth=eth)
                    self.big_eth = 0

        rx, ry = zx - xl, zy - yl
        rm = math.hypot(rx, ry)
        if gap > 3.0:
            # first fix after an outage: dead reckoning has drifted and GNSS
            # is the better source, so re-anchor instead of gating it out
            self._shift(dx=rx, dy=ry)
            self.last_accept = t
            return
        thr = max(4.0 * self.res_scale, 6.0) + 0.5 * (t - self.last_accept)
        if rm < thr:
            self._shift(dx=0.04 * rx, dy=0.04 * ry)
            self.res_scale = 0.98 * self.res_scale + 0.02 * rm
            self.last_accept = t

    def query(self, t):
        return (t, self.x, self.y, wrap(self.th), self.v)


def handle(est, line, out):
    p = line.split()
    if not p:
        return True
    kind = p[0]
    if kind == "IMU":
        est.imu(float(p[1]), float(p[2]), float(p[3]))
    elif kind == "GPS":
        est.gps(float(p[1]), float(p[2]), float(p[3]), float(p[4]), float(p[5]))
    elif kind == "QUERY":
        t, x, y, th, v = est.query(float(p[1]))
        out.write(f"{t:.3f} {x:.4f} {y:.4f} {th:.6f} {v:.4f}\n")
        out.flush()
    elif kind == "INIT":
        est.init(float(p[1]), float(p[2]), float(p[3]), float(p[4]))
    elif kind == "END":
        return False
    return True


def main():
    est = Estimator()
    while True:
        line = sys.stdin.readline()
        if not line or not handle(est, line, sys.stdout):
            break


if __name__ == "__main__":
    main()
