#!/bin/bash
# Builds the verifier image from tests/ and pushes each program in cheats/
# through the real verifier, placed at /app/estimator.py exactly as harbor
# places the artifact. The reference solution runs first as a positive control.
# Expected: reference reward 1, every cheat reward 0.
set -uo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
root="$(cd "$here/../.." && pwd)"
docker build -q -t vef-verifier "$root/tests" >/dev/null

run() {
  local src_dir="$1" name="$2"
  echo "== $name"
  docker run --rm -v "$src_dir:/src:ro" vef-verifier bash -c "
    cp /src/$name.py /app/estimator.py && bash /tests/test.sh > /dev/null
    echo reward=\$(cat /logs/verifier/reward.txt)
    head -3 /logs/verifier/estimator_stderr_h1.txt 2>/dev/null"
}

run "$root/solution" estimator
for c in "$here"/cheats/*.py; do
  run "$here/cheats" "$(basename "$c" .py)"
done
