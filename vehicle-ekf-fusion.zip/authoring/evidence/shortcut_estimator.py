#!/usr/bin/env python3
"""
Reviewer style shortcut: the kind of causal heuristic someone writes in a few
minutes instead of a filter. Used to confirm the bars are not reachable
without the real modelling.

  position : the latest GNSS fix, dead reckoned forward from its stamp
  heading  : course over ground from the Doppler velocity of that fix
  speed    : Doppler ground speed of that fix
  outages  : IMU dead reckoning from the last fix, with gyro and accel biases
             tracked by comparing IMU increments with Doppler increments
             between consecutive fixes (exponential averaging)

No latency, no scale factor, no GNSS error model, no multipath handling, no
covariance. Protocol as in instruction.md.
"""
import math
import sys


def wrap(a):
    return (a + math.pi) % (2.0 * math.pi) - math.pi


class Estimator(object):
    ALPHA = 0.02      # bias averaging weight per fix (about 10 s at 5 Hz)
    MIN_SPEED = 2.0   # Doppler course is unreliable below this

    def init(self, x, y, th, v):
        self.x, self.y, self.th, self.v = x, y, th, v
        self.t = 0.0
        self.bg = 0.0
        self.ba = 0.0
        self.gyro_int = 0.0
        self.acc_int = 0.0
        self.prev = None   # (t, course, speed) of the previous fix

    def imu(self, t, a, w):
        dt = t - self.t
        if dt <= 0.0:
            return
        self.t = t
        self.gyro_int += w * dt
        self.acc_int += a * dt
        wc = w - self.bg
        ac = a - self.ba
        self.x += self.v * math.cos(self.th) * dt
        self.y += self.v * math.sin(self.th) * dt
        self.th += wc * dt
        self.v = max(self.v + ac * dt, 0.0)

    def gps(self, t, zx, zy, zvx, zvy):
        speed = math.hypot(zvx, zvy)
        course = math.atan2(zvy, zvx) if speed > self.MIN_SPEED else self.th
        if self.prev is not None:
            t0, c0, s0 = self.prev
            dt = t - t0
            if 0.0 < dt < 0.5 and speed > self.MIN_SPEED and s0 > self.MIN_SPEED:
                self.bg += self.ALPHA * ((self.gyro_int - wrap(course - c0)) / dt - self.bg)
                self.ba += self.ALPHA * ((self.acc_int - (speed - s0)) / dt - self.ba)
        self.prev = (t, course, speed)
        self.gyro_int = 0.0
        self.acc_int = 0.0
        self.x, self.y, self.th, self.v = zx, zy, course, speed

    def query(self, t):
        return self.x, self.y, wrap(self.th), self.v


def handle(est, line, out):
    p = line.split()
    if not p:
        return True
    k = p[0]
    if k == "IMU":
        est.imu(float(p[1]), float(p[2]), float(p[3]))
    elif k == "GPS":
        est.gps(float(p[1]), float(p[2]), float(p[3]), float(p[4]), float(p[5]))
    elif k == "QUERY":
        x, y, th, v = est.query(float(p[1]))
        out.write(f"{p[1]} {x:.4f} {y:.4f} {th:.6f} {v:.4f}\n")
        out.flush()
    elif k == "INIT":
        est.init(float(p[1]), float(p[2]), float(p[3]), float(p[4]))
    elif k == "END":
        return False
    return True


def main():
    est = Estimator()
    while True:
        line = sys.stdin.readline()
        if not line or not handle(est, line, sys.stdout):
            break


if __name__ == "__main__":
    main()
