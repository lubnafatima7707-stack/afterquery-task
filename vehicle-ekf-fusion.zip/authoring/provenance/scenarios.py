"""
Seeded scenario generator for vehicle-ekf-fusion. Never mounted into any
container; this is the record of how every drive (dev, hidden, calibration
pool) was produced.

Each scenario is a 480 s drive of a unicycle model vehicle with a randomized
speed and curvature schedule. The true trajectory is integrated first at
200 Hz and is the ground truth. The IMU stream (50 Hz forward accel and yaw
rate) and GNSS stream (about 5 Hz position plus Doppler velocity) are derived
from it afterward with:
  - gyro and accel biases that start at a random value and random walk,
  - a gyro scale factor error of up to 5 percent,
  - white IMU noise,
  - a per drive GNSS latency L between 0.1 and 0.4 s: each fix is stamped
    L seconds after the epoch it actually describes,
  - GNSS position error = first order Gauss-Markov (correlated) + white,
  - 2 to 3 complete GNSS outages of 30 to 75 s,
  - 1 to 2 multipath windows of 15 to 35 s in which a position offset of
    10 to 30 m ramps in over 5 to 12 s and then drifts slowly (velocity is
    only mildly noisier).
Nothing here depends on any estimator, so ground truth is independent of
the reference solution.

Run from this directory:  python scenarios.py
"""
import json
import math
import os

import numpy as np

DT = 0.005
DURATION = 480.0
IMU_STEP = 4                 # one IMU sample every 4 fine steps = 0.02 s
GNSS_PERIOD = 0.2
QUERY_PERIOD = 1.0

SPEC = {
    "imu_rate_hz": 50.0,
    "gyro_white_noise_std_rad_per_s": 0.003,
    "accel_white_noise_std_m_per_s2": 0.02,
    "gyro_bias_initial_max_abs_rad_per_s": 0.02,
    "gyro_bias_random_walk_rad_per_s_per_sqrt_s": 1e-5,
    "accel_bias_initial_max_abs_m_per_s2": 0.15,
    "accel_bias_random_walk_m_per_s2_per_sqrt_s": 1e-4,
    "gyro_scale_factor_error_max_abs": 0.05,
    "gnss_nominal_rate_hz": 5.0,
    "gnss_position_white_noise_std_m": 1.0,
    "gnss_position_correlated_error_std_m": 1.5,
    "gnss_position_correlated_error_time_constant_s": 30.0,
    "gnss_velocity_noise_std_m_per_s": 0.15,
    "gnss_latency_range_s": [0.10, 0.40],
}

# What the agent is given as the vendor spec sheet. Latency, the split of GNSS
# error into correlated and white parts, outages and multipath are deliberately
# not listed: they have to be characterized from the dev drives.
PUBLIC_SPEC = {
    "imu_rate_hz": SPEC["imu_rate_hz"],
    "gyro_white_noise_std_rad_per_s": SPEC["gyro_white_noise_std_rad_per_s"],
    "accel_white_noise_std_m_per_s2": SPEC["accel_white_noise_std_m_per_s2"],
    "gyro_bias_initial_max_abs_rad_per_s": SPEC["gyro_bias_initial_max_abs_rad_per_s"],
    "gyro_bias_random_walk_rad_per_s_per_sqrt_s": SPEC["gyro_bias_random_walk_rad_per_s_per_sqrt_s"],
    "accel_bias_initial_max_abs_m_per_s2": SPEC["accel_bias_initial_max_abs_m_per_s2"],
    "accel_bias_random_walk_m_per_s2_per_sqrt_s": SPEC["accel_bias_random_walk_m_per_s2_per_sqrt_s"],
    "gyro_scale_factor_error_max_abs": SPEC["gyro_scale_factor_error_max_abs"],
    "gnss_nominal_rate_hz": SPEC["gnss_nominal_rate_hz"],
    "gnss_position_accuracy_1sigma_per_axis_m": 1.8,
    "gnss_velocity_accuracy_1sigma_per_axis_m_per_s": SPEC["gnss_velocity_noise_std_m_per_s"],
}

DEV_SEEDS = {"dev_1": 2001, "dev_2": 2002}
HIDDEN_SEEDS = {"h1": 1001, "h2": 1002, "h3": 1003, "h4": 1004, "h5": 1005, "h6": 1006}


def _segments(rng, maker):
    segs = []
    t = 0.0
    while t < DURATION + 1.0:
        d, target = maker(t, len(segs))
        segs.append((t + d, target))
        t += d
    ends = np.array([s[0] for s in segs])
    targets = np.array([s[1] for s in segs])
    return ends, targets


def simulate_truth(rng):
    n = int(round(DURATION / DT)) + 1
    t = np.arange(n) * DT

    def speed_seg(t0, i):
        if i == 0:
            return rng.uniform(10, 25), rng.uniform(8, 16)
        r = rng.random()
        if r < 0.15 and t0 > 20:
            return rng.uniform(5, 12), 0.0
        if r < 0.45:
            return rng.uniform(8, 30), rng.uniform(3, 8)
        return rng.uniform(8, 30), rng.uniform(8, 20)

    def curv_seg(t0, i):
        d = rng.uniform(5, 20)
        if rng.random() < 0.45:
            return d, 0.0
        return d, float(rng.choice([-1.0, 1.0]) * rng.uniform(0.004, 0.03))

    s_ends, s_targets = _segments(rng, speed_seg)
    c_ends, c_targets = _segments(rng, curv_seg)
    v_tgt = s_targets[np.searchsorted(s_ends, t, side="right")]
    k_tgt = c_targets[np.searchsorted(c_ends, t, side="right")]

    X = np.zeros(n); Y = np.zeros(n); TH = np.zeros(n); V = np.zeros(n)
    A = np.zeros(n); W = np.zeros(n)
    x, y = 0.0, 0.0
    th = rng.uniform(-math.pi, math.pi)
    v = rng.uniform(5, 12)
    a = 0.0
    kap = 0.0
    for i in range(n):
        a_cmd = min(max((v_tgt[i] - v) / 3.0, -2.0), 1.5)
        a += min(max(a_cmd - a, -3.0 * DT), 3.0 * DT)
        if v <= 0.0 and a < 0.0:
            a = 0.0
        kap += (k_tgt[i] - kap) * DT / 1.5
        kmax = 3.0 / max(v * v, 0.01)
        w = v * min(max(kap, -kmax), kmax)
        X[i], Y[i], TH[i], V[i], A[i], W[i] = x, y, th, v, a, w
        v_new = max(v + a * DT, 0.0)
        v_mid = 0.5 * (v + v_new)
        th_mid = th + 0.5 * w * DT
        x += v_mid * math.cos(th_mid) * DT
        y += v_mid * math.sin(th_mid) * DT
        th += w * DT
        v = v_new
    return {"t": t, "x": X, "y": Y, "th": TH, "v": V, "a": A, "w": W}


def _place_windows(rng, durations):
    placed = []
    for d in durations:
        for _ in range(1000):
            lo = rng.uniform(20.0, DURATION - 10.0 - d)
            hi = lo + d
            if all(hi + 5.0 < p_lo or lo - 5.0 > p_hi for p_lo, p_hi in placed):
                placed.append((lo, hi))
                break
        else:
            raise RuntimeError("could not place window")
    return placed


def generate(seed):
    rng = np.random.default_rng(seed)
    tr = simulate_truth(rng)
    t = tr["t"]

    # IMU
    idx = np.arange(0, t.size, IMU_STEP)
    t_imu = t[idx]
    n_imu = t_imu.size
    dt_imu = DT * IMU_STEP
    bg0 = rng.uniform(-1, 1) * SPEC["gyro_bias_initial_max_abs_rad_per_s"]
    ba0 = rng.uniform(-1, 1) * SPEC["accel_bias_initial_max_abs_m_per_s2"]
    sf = rng.uniform(-1, 1) * SPEC["gyro_scale_factor_error_max_abs"]
    bg = bg0 + np.concatenate([[0.0], np.cumsum(rng.normal(0, SPEC["gyro_bias_random_walk_rad_per_s_per_sqrt_s"] * math.sqrt(dt_imu), n_imu - 1))])
    ba = ba0 + np.concatenate([[0.0], np.cumsum(rng.normal(0, SPEC["accel_bias_random_walk_m_per_s2_per_sqrt_s"] * math.sqrt(dt_imu), n_imu - 1))])
    gyro = (1.0 + sf) * tr["w"][idx] + bg + rng.normal(0, SPEC["gyro_white_noise_std_rad_per_s"], n_imu)
    accel = tr["a"][idx] + ba + rng.normal(0, SPEC["accel_white_noise_std_m_per_s2"], n_imu)
    imu = np.column_stack([np.round(t_imu, 3), accel, gyro])

    # windows
    n_out = int(rng.choice([2, 3], p=[0.6, 0.4]))
    n_mp = int(rng.choice([1, 2]))
    durs = [rng.uniform(30, 75) for _ in range(n_out)] + [rng.uniform(15, 35) for _ in range(n_mp)]
    wins = _place_windows(rng, durs)
    outages = wins[:n_out]
    multipath = []
    for lo, hi in wins[n_out:]:
        mag = rng.uniform(10, 30)
        ang = rng.uniform(0, 2 * math.pi)
        dmag = rng.uniform(0, 0.3)
        dang = rng.uniform(0, 2 * math.pi)
        multipath.append({
            "lo": lo, "hi": hi, "ramp_s": rng.uniform(5, 12),
            "offset": [mag * math.cos(ang), mag * math.sin(ang)],
            "drift": [dmag * math.cos(dang), dmag * math.sin(dang)],
        })

    # GNSS
    L = rng.uniform(*SPEC["gnss_latency_range_s"])
    k = np.arange(1, int(round(DURATION / GNSS_PERIOD)) + 1)
    ts = k * GNSS_PERIOD + rng.normal(0, 0.004, k.size)
    ts = ts[(ts - L >= 0.0) & (ts <= DURATION)]
    tm = ts - L
    th_u = tr["th"]
    gx = np.interp(tm, t, tr["x"]); gy = np.interp(tm, t, tr["y"])
    gth = np.interp(tm, t, th_u); gv = np.interp(tm, t, tr["v"])
    m = ts.size
    sig_gm = SPEC["gnss_position_correlated_error_std_m"]
    tau = SPEC["gnss_position_correlated_error_time_constant_s"]
    e = np.zeros((m, 2))
    cur = rng.normal(0, sig_gm, 2)
    t_prev = tm[0]
    for i in range(m):
        phi = math.exp(-(tm[i] - t_prev) / tau)
        cur = phi * cur + sig_gm * math.sqrt(1 - phi * phi) * rng.normal(0, 1, 2)
        e[i] = cur
        t_prev = tm[i]
    white = rng.normal(0, SPEC["gnss_position_white_noise_std_m"], (m, 2))
    vstd = np.full(m, SPEC["gnss_velocity_noise_std_m_per_s"])
    off = np.zeros((m, 2))
    for mp in multipath:
        mask = (ts >= mp["lo"]) & (ts <= mp["hi"])
        dt_mp = (ts[mask] - mp["lo"])[:, None]
        ramp = np.minimum(dt_mp / mp["ramp_s"], 1.0)
        off[mask] = np.array(mp["offset"]) * ramp + np.array(mp["drift"]) * dt_mp
        vstd[mask] *= 2.0
    vn = rng.normal(0, 1, (m, 2)) * vstd[:, None]
    px = gx + e[:, 0] + white[:, 0] + off[:, 0]
    py = gy + e[:, 1] + white[:, 1] + off[:, 1]
    vx = gv * np.cos(gth) + vn[:, 0]
    vy = gv * np.sin(gth) + vn[:, 1]
    keep = np.ones(m, dtype=bool)
    for lo, hi in outages:
        keep &= ~((ts >= lo) & (ts <= hi))
    gnss = np.column_stack([np.round(ts, 3), px, py, vx, vy])[keep]

    # queries and truth
    queries = np.arange(1, int(round(DURATION / QUERY_PERIOD)) + 1) * QUERY_PERIOD
    def truth_at(times):
        th = np.interp(times, t, th_u)
        return np.column_stack([
            times, np.interp(times, t, tr["x"]), np.interp(times, t, tr["y"]),
            (th + math.pi) % (2 * math.pi) - math.pi, np.interp(times, t, tr["v"]),
        ])
    truth_q = truth_at(queries)
    truth_10hz = truth_at(np.round(np.arange(0, int(DURATION * 10) + 1) * 0.1, 3))

    init = {"t": 0.0, "x": 0.0, "y": 0.0, "theta": float((th_u[0] + math.pi) % (2 * math.pi) - math.pi), "v": float(tr["v"][0])}
    params = {
        "seed": seed, "gyro_bias_initial": bg0, "accel_bias_initial": ba0,
        "gyro_bias_final": float(bg[-1]), "accel_bias_final": float(ba[-1]),
        "gyro_scale_factor": sf, "gnss_latency_s": L,
        "outages": outages, "multipath": multipath,
    }
    return {"init": init, "imu": imu, "gnss": gnss, "queries": queries,
            "truth_q": truth_q, "truth_10hz": truth_10hz,
            "outages": outages, "multipath": multipath, "params": params}


def _write_csv(path, header, rows, fmts):
    with open(path, "w", newline="\n") as f:
        f.write(header + "\n")
        for r in rows:
            f.write(",".join(fmt.format(val) for fmt, val in zip(fmts, r)) + "\n")


def write_inputs(d, sc):
    os.makedirs(d, exist_ok=True)
    _write_csv(os.path.join(d, "imu.csv"), "t,accel_fwd,gyro_z", sc["imu"], ["{:.3f}", "{:.6f}", "{:.6f}"])
    _write_csv(os.path.join(d, "gnss.csv"), "t,x,y,vx,vy", sc["gnss"], ["{:.3f}", "{:.3f}", "{:.3f}", "{:.4f}", "{:.4f}"])
    _write_csv(os.path.join(d, "queries.csv"), "t", [[q] for q in sc["queries"]], ["{:.3f}"])
    with open(os.path.join(d, "init.json"), "w", newline="\n") as f:
        json.dump(sc["init"], f, indent=2)


def write_truth(path, rows):
    _write_csv(path, "t,x,y,theta,v", rows, ["{:.3f}", "{:.4f}", "{:.4f}", "{:.6f}", "{:.4f}"])


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.normpath(os.path.join(here, "..", ".."))
    record = {"spec": SPEC, "dev": {}, "hidden": {}}

    for name, seed in DEV_SEEDS.items():
        sc = generate(seed)
        d = os.path.join(root, "environment", "data", "dev", name)
        write_inputs(d, sc)
        write_truth(os.path.join(d, "truth.csv"), sc["truth_10hz"])
        record["dev"][name] = sc["params"]

    for name, seed in HIDDEN_SEEDS.items():
        sc = generate(seed)
        d = os.path.join(root, "tests", "scenarios", name)
        write_inputs(d, sc)
        write_truth(os.path.join(d, "truth.csv"), sc["truth_q"])
        record["hidden"][name] = sc["params"]

    spec_path = os.path.join(root, "environment", "data", "sensor_spec.json")
    with open(spec_path, "w", newline="\n") as f:
        json.dump(PUBLIC_SPEC, f, indent=2)
    with open(os.path.join(here, "scenario_params.json"), "w", newline="\n") as f:
        json.dump(record, f, indent=2)
    print("wrote", len(DEV_SEEDS), "dev and", len(HIDDEN_SEEDS), "hidden scenarios")


if __name__ == "__main__":
    main()
