#!/usr/bin/env python3
"""
Local replay tool.

Streams one recorded drive through an estimator program over the same line
protocol the grader uses, then scores the answers against that drive's
reference trajectory (truth.csv).

    python3 /app/tools/replay.py /app/estimator.py /app/data/dev/dev_1

GNSS outage windows are inferred here from gaps in gnss.csv longer than 2 s.
"""
import json
import math
import os
import select
import subprocess
import sys
import time

import numpy as np

POS_RMSE_MAX_M = 3.0
OUTAGE_RMSE_MAX_M = 4.5
HEADING_RMSE_MAX_DEG = 0.8
HEADING_MIN_SPEED = 2.0
TIMEOUT_S = 120


def load(d):
    with open(os.path.join(d, "init.json")) as f:
        init = json.load(f)
    imu = np.loadtxt(os.path.join(d, "imu.csv"), delimiter=",", skiprows=1, ndmin=2)
    gnss = np.loadtxt(os.path.join(d, "gnss.csv"), delimiter=",", skiprows=1, ndmin=2)
    queries = np.loadtxt(os.path.join(d, "queries.csv"), delimiter=",", skiprows=1, ndmin=1)
    return init, imu, gnss, queries


def build_lines(init, imu, gnss, queries):
    events = []
    for t, a, w in imu:
        events.append((round(t, 3), 0, f"IMU {t:.3f} {a:.6f} {w:.6f}"))
    for t, x, y, vx, vy in gnss:
        events.append((round(t, 3), 1, f"GPS {t:.3f} {x:.3f} {y:.3f} {vx:.4f} {vy:.4f}"))
    for t in queries:
        events.append((round(t, 3), 2, f"QUERY {t:.3f}"))
    events.sort(key=lambda e: (e[0], e[1]))
    return ([f"INIT {init['x']:.4f} {init['y']:.4f} {init['theta']:.6f} {init['v']:.4f}"]
            + [e[2] for e in events] + ["END"])


def run(program, lines):
    proc = subprocess.Popen([sys.executable, program], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    fd_in, fd_out = proc.stdin.fileno(), proc.stdout.fileno()
    os.set_blocking(fd_in, False)
    deadline = time.monotonic() + TIMEOUT_S
    pending, outbuf, answers = bytearray(), bytearray(), []

    def remaining():
        r = deadline - time.monotonic()
        if r <= 0:
            raise RuntimeError(f"timed out after {TIMEOUT_S} s")
        return r

    def flush():
        while pending:
            _, w, _ = select.select([], [fd_in], [], remaining())
            if w:
                try:
                    n = os.write(fd_in, bytes(pending[:65536]))
                except BlockingIOError:
                    continue
                del pending[:n]

    def read_line():
        while b"\n" not in outbuf:
            r, _, _ = select.select([fd_out], [], [], remaining())
            if r:
                chunk = os.read(fd_out, 65536)
                if not chunk:
                    raise RuntimeError("program exited before answering a query")
                outbuf.extend(chunk)
        i = outbuf.index(b"\n")
        line = bytes(outbuf[:i]).decode().strip()
        del outbuf[:i + 1]
        return line

    try:
        for line in lines:
            pending.extend((line + "\n").encode())
            if line.startswith("QUERY"):
                tq = float(line.split()[1])
                flush()
                vals = [float(v) for v in read_line().split()]
                if len(vals) != 5 or abs(vals[0] - tq) > 1e-3 or not all(map(math.isfinite, vals)):
                    raise RuntimeError(f"bad answer to QUERY {tq:.3f}: {vals}")
                answers.append(vals)
        flush()
    finally:
        proc.stdin.close()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
    return np.array(answers)


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    program, d = sys.argv[1], sys.argv[2]
    init, imu, gnss, queries = load(d)
    truth_all = np.loadtxt(os.path.join(d, "truth.csv"), delimiter=",", skiprows=1, ndmin=2)
    t0 = time.monotonic()
    est = run(program, build_lines(init, imu, gnss, queries))
    secs = time.monotonic() - t0

    idx = np.searchsorted(np.round(truth_all[:, 0], 3), np.round(queries, 3))
    truth = truth_all[idx]
    gt = gnss[:, 0]
    gaps = np.diff(gt)
    outages = [(gt[i], gt[i + 1]) for i in np.nonzero(gaps > 2.0)[0]]

    t = truth[:, 0]
    pos_err = np.hypot(est[:, 1] - truth[:, 1], est[:, 2] - truth[:, 2])
    out_mask = np.zeros(t.size, dtype=bool)
    for lo, hi in outages:
        out_mask |= (t >= lo) & (t <= hi)
    head_mask = truth[:, 4] > HEADING_MIN_SPEED
    head_err = (est[:, 3] - truth[:, 3] + np.pi) % (2 * np.pi) - np.pi

    pos = float(np.sqrt(np.mean(pos_err ** 2)))
    out = float(np.sqrt(np.mean(pos_err[out_mask] ** 2))) if out_mask.any() else 0.0
    head = float(np.degrees(np.sqrt(np.mean(head_err[head_mask] ** 2))))
    ok = pos <= POS_RMSE_MAX_M and out <= OUTAGE_RMSE_MAX_M and head <= HEADING_RMSE_MAX_DEG
    print(f"drive {os.path.basename(os.path.normpath(d))}: {len(est)} answers in {secs:.1f} s")
    print(f"  position RMSE        {pos:7.2f} m    (bar {POS_RMSE_MAX_M})")
    print(f"  outage position RMSE {out:7.2f} m    (bar {OUTAGE_RMSE_MAX_M}, {len(outages)} outages)")
    print(f"  heading RMSE         {head:7.2f} deg  (bar {HEADING_RMSE_MAX_DEG}, speed > {HEADING_MIN_SPEED} m/s)")
    print("  within all bars" if ok else "  NOT within all bars")


if __name__ == "__main__":
    main()
