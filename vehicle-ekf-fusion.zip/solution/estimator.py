#!/usr/bin/env python3
"""
Reference streaming estimator for vehicle-ekf-fusion.

Error model follows the sensor spec sheet. Nine state extended Kalman filter:
x, y, heading, speed, gyro bias, accel bias, gyro scale factor, and the two
components of the time correlated GNSS position error (first order
Gauss-Markov, so the filter does not treat 30 s correlated error as white
and average it away). Biases are random walks, not constants.

GNSS latency: every fix describes the vehicle L seconds before its stamp.
The filter keeps a short history of its own states and scores a grid of
candidate latencies by how well the lagged state predicts the Doppler
velocity; the best candidate is used to form each innovation against the
lagged state, and the correction is applied to the current state.

Velocity and position are gated separately with a chi square test, because
multipath corrupts position but not velocity. A channel that has been
rejected for long enough is force accepted so the filter cannot lock itself
out after a long bad stretch.
"""
import math
import sys
from collections import deque

import numpy as np

IX, IY, ITH, IV, IBG, IBA, ISF, IEX, IEY = range(9)
NS = 9

DEFAULTS = {
    "gyro_noise": 0.003,
    "accel_noise": 0.02,
    "bg_init": 0.02,
    "ba_init": 0.15,
    "sf_init": 0.05,
    "bg_rw": 1e-5,
    "ba_rw": 1e-4,
    "pos_white": 1.0,
    "gm_sigma": 1.5,
    "gm_tau": 30.0,
    "vel_noise": 0.15,
    "q_pos": 1e-4,
    "q_vel": 2.5e-3,
    "latency_grid": (0.0, 0.50, 0.01),
    "latency_prior": 0.25,
    "latency_min_fixes": 50,
    "latency_decay": 0.995,
    "gate": 9.21,
    "vel_gate": 30.0,
    "pos_reacquire_s": 30.0,
    "vel_reacquire_s": 3.0,
    # switches below exist only for ablation studies
    "estimate_latency": True,
    "estimate_scale": True,
    "model_correlated_gnss": True,
    "use_gate": True,
    "use_velocity": True,
    "estimate_bias": True,
    "track_bias_drift": True,
}


def wrap(a):
    return (a + math.pi) % (2.0 * math.pi) - math.pi


class Estimator:
    def __init__(self, **overrides):
        self.c = dict(DEFAULTS)
        self.c.update(overrides)
        lo, hi, st = self.c["latency_grid"]
        self.lat_grid = np.arange(lo, hi + 1e-9, st)
        self.lat_score = np.zeros_like(self.lat_grid)
        self.lat_n = 0
        self.latency = self.c["latency_prior"]
        self.prev_fix = None
        self.X = None

    def init(self, x, y, th, v):
        c = self.c
        self.X = np.zeros(NS)
        self.X[[IX, IY, ITH, IV]] = [x, y, th, v]
        p = np.zeros(NS)
        p[IX] = p[IY] = 1e-4
        p[ITH] = 1e-6
        p[IV] = 1e-4
        if c["estimate_bias"]:
            p[IBG] = c["bg_init"] ** 2 / 3.0
            p[IBA] = c["ba_init"] ** 2 / 3.0
        p[ISF] = c["sf_init"] ** 2 / 3.0 if c["estimate_scale"] else 0.0
        p[IEX] = p[IEY] = c["gm_sigma"] ** 2 if c["model_correlated_gnss"] else 0.0
        self.P = np.diag(p)
        self.t = 0.0
        self.hist = deque(maxlen=50)
        self.hist.append([0.0, x, y, th, v])
        self.last_pos_accept = 0.0
        self.last_vel_accept = 0.0

    def imu(self, t, am, wm):
        dt = t - self.t
        if dt <= 0.0:
            return
        self.t = t
        c = self.c
        X = self.X
        th, v, bg, ba, sf = X[ITH], X[IV], X[IBG], X[IBA], X[ISF]
        k = 1.0 + sf
        w = (wm - bg) / k
        a = am - ba
        v_new = v + a * dt
        v_mid = 0.5 * (v + v_new)
        th_mid = th + 0.5 * w * dt
        cs, sn = math.cos(th_mid), math.sin(th_mid)
        X[IX] += v_mid * cs * dt
        X[IY] += v_mid * sn * dt
        X[ITH] = th + w * dt
        X[IV] = v_new

        F = np.eye(NS)
        F[IX, ITH] = -v_mid * sn * dt
        F[IX, IV] = cs * dt
        F[IY, ITH] = v_mid * cs * dt
        F[IY, IV] = sn * dt
        F[ITH, IBG] = -dt / k
        if c["estimate_scale"]:
            F[ITH, ISF] = -(wm - bg) / (k * k) * dt
        F[IV, IBA] = -dt

        q = np.zeros(NS)
        q[IX] = q[IY] = c["q_pos"] * dt
        q[ITH] = (c["gyro_noise"] * dt / k) ** 2
        q[IV] = (c["accel_noise"] * dt) ** 2 + c["q_vel"] * dt
        if c["track_bias_drift"] and c["estimate_bias"]:
            q[IBG] = c["bg_rw"] ** 2 * dt
            q[IBA] = c["ba_rw"] ** 2 * dt
        if c["model_correlated_gnss"]:
            phi = math.exp(-dt / c["gm_tau"])
            X[IEX] *= phi
            X[IEY] *= phi
            F[IEX, IEX] = F[IEY, IEY] = phi
            q[IEX] = q[IEY] = c["gm_sigma"] ** 2 * (1.0 - phi * phi)
        self.P = F @ self.P @ F.T + np.diag(q)
        self.hist.append([t, X[IX], X[IY], X[ITH], X[IV]])

    def _correct(self, Hm, r, R):
        P = self.P
        S = Hm @ P @ Hm.T + R
        K = np.linalg.solve(S, Hm @ P).T
        dX = K @ r
        self.X += dX
        IKH = np.eye(NS) - K @ Hm
        self.P = IKH @ P @ IKH.T + K @ R @ K.T
        for e in self.hist:
            e[1] += dX[IX]
            e[2] += dX[IY]
            e[3] += dX[ITH]
            e[4] += dX[IV]
        return dX

    def _passes_gate(self, Hm, r, R, force, gate):
        if force or not self.c["use_gate"]:
            return True
        S = Hm @ self.P @ Hm.T + R
        return float(r @ np.linalg.solve(S, r)) <= gate

    def _score_latency(self, t, zvx, zvy, H):
        # Compare the CHANGE in Doppler velocity between consecutive fixes with
        # the change the IMU propagated over the same interval shifted back by
        # each candidate latency. A heading or speed error in the filter shifts
        # both ends equally and mostly cancels, so this does not need the
        # bias and scale estimates to have converged first.
        c = self.c
        if self.prev_fix is not None and 0.0 < t - self.prev_fix[0] <= 0.35:
            tp, pvx, pvy = self.prev_fix
            ht = H[:, 0]
            t1 = t - self.lat_grid
            t0 = tp - self.lat_grid
            v1 = np.interp(t1, ht, H[:, 4]); th1 = np.interp(t1, ht, H[:, 3])
            v0 = np.interp(t0, ht, H[:, 4]); th0 = np.interp(t0, ht, H[:, 3])
            dpx = v1 * np.cos(th1) - v0 * np.cos(th0)
            dpy = v1 * np.sin(th1) - v0 * np.sin(th0)
            r2 = (zvx - pvx - dpx) ** 2 + (zvy - pvy - dpy) ** 2
            if r2.min() < 2.0 * (6.0 * c["vel_noise"]) ** 2:
                self.lat_score = c["latency_decay"] * self.lat_score + r2
                self.lat_n += 1
        self.prev_fix = (t, zvx, zvy)
        if self.lat_n >= c["latency_min_fixes"]:
            self.latency = float(self.lat_grid[int(np.argmin(self.lat_score))])

    def gps(self, t, zx, zy, zvx, zvy):
        c = self.c
        H = np.array(self.hist)
        ht = H[:, 0]
        if c["estimate_latency"]:
            self._score_latency(t, zvx, zvy, H)
            L = self.latency
        else:
            L = 0.0
        tl = t - L
        xl = float(np.interp(tl, ht, H[:, 1]))
        yl = float(np.interp(tl, ht, H[:, 2]))
        thl = float(np.interp(tl, ht, H[:, 3]))
        vl = float(np.interp(tl, ht, H[:, 4]))
        X = self.X

        if c["use_velocity"]:
            th, v = X[ITH], X[IV]
            Hm = np.zeros((2, NS))
            Hm[0, ITH] = -v * math.sin(th)
            Hm[0, IV] = math.cos(th)
            Hm[1, ITH] = v * math.cos(th)
            Hm[1, IV] = math.sin(th)
            r = np.array([zvx - vl * math.cos(thl), zvy - vl * math.sin(thl)])
            R = np.eye(2) * c["vel_noise"] ** 2
            if self._passes_gate(Hm, r, R, t - self.last_vel_accept >= c["vel_reacquire_s"], c["vel_gate"]):
                dX = self._correct(Hm, r, R)
                xl += dX[IX]
                yl += dX[IY]
                self.last_vel_accept = t

        Hm = np.zeros((2, NS))
        Hm[0, IX] = 1.0
        Hm[1, IY] = 1.0
        if c["model_correlated_gnss"]:
            Hm[0, IEX] = 1.0
            Hm[1, IEY] = 1.0
            h = np.array([xl + X[IEX], yl + X[IEY]])
            R = np.eye(2) * c["pos_white"] ** 2
        else:
            h = np.array([xl, yl])
            R = np.eye(2) * (c["pos_white"] ** 2 + c["gm_sigma"] ** 2)
        r = np.array([zx, zy]) - h
        if self._passes_gate(Hm, r, R, t - self.last_pos_accept >= c["pos_reacquire_s"], c["gate"]):
            self._correct(Hm, r, R)
            self.last_pos_accept = t

    def query(self, t):
        X = self.X
        return (t, float(X[IX]), float(X[IY]), wrap(float(X[ITH])), float(X[IV]))


def handle(est, line, out):
    p = line.split()
    if not p:
        return True
    kind = p[0]
    if kind == "IMU":
        est.imu(float(p[1]), float(p[2]), float(p[3]))
    elif kind == "GPS":
        est.gps(float(p[1]), float(p[2]), float(p[3]), float(p[4]), float(p[5]))
    elif kind == "QUERY":
        t, x, y, th, v = est.query(float(p[1]))
        out.write(f"{t:.3f} {x:.4f} {y:.4f} {th:.6f} {v:.4f}\n")
        out.flush()
    elif kind == "INIT":
        est.init(float(p[1]), float(p[2]), float(p[3]), float(p[4]))
    elif kind == "END":
        return False
    return True


def main():
    est = Estimator()
    while True:
        line = sys.stdin.readline()
        if not line:
            break
        if not handle(est, line, sys.stdout):
            break


if __name__ == "__main__":
    main()
