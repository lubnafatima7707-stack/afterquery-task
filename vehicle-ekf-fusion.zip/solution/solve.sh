#!/bin/bash
set -euo pipefail
cp "$(dirname "$0")/estimator.py" /app/estimator.py
python3 /app/tools/replay.py /app/estimator.py /app/data/dev/dev_1
