"""
Runs the agent's estimator program against one scenario over a line protocol.

The program only ever sees data in time order: a QUERY line is written only
after every sensor line stamped at or before the query time, and the harness
waits for the answer before writing anything later. The program is started
as an unprivileged user in an empty working directory, while scenario inputs,
ground truth and this harness live under /tests, readable by root only, so
the program cannot read ahead or read the answers.
"""
import math
import os
import pwd
import select
import shutil
import signal
import subprocess
import tempfile
import time


class EstimatorFailure(Exception):
    pass


RUN_USER = "runner"


def _prepare_workdir(program_path):
    work = tempfile.mkdtemp(prefix="est_")
    dst = os.path.join(work, "estimator.py")
    shutil.copyfile(program_path, dst)
    if os.geteuid() == 0:
        pw = pwd.getpwnam(RUN_USER)
        os.chown(work, pw.pw_uid, pw.pw_gid)
        os.chown(dst, pw.pw_uid, pw.pw_gid)
    os.chmod(work, 0o700)
    return work, dst


def run_scenario(program_path, lines, timeout_s, stderr_path):
    if not os.path.isfile(program_path):
        raise EstimatorFailure(f"{program_path} does not exist")
    work, dst = _prepare_workdir(program_path)
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": work, "PYTHONDONTWRITEBYTECODE": "1",
           "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
    kwargs = {}
    if os.geteuid() == 0:
        kwargs["user"] = RUN_USER
        kwargs["group"] = RUN_USER
        kwargs["extra_groups"] = []
    err = open(stderr_path, "wb")
    # Own session and process group, so anything the program forks off can be
    # swept at the end instead of outliving the run.
    proc = subprocess.Popen(["python3", dst], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=err, cwd=work, env=env, close_fds=True,
                            start_new_session=True, **kwargs)
    fd_in = proc.stdin.fileno()
    fd_out = proc.stdout.fileno()
    os.set_blocking(fd_in, False)
    deadline = time.monotonic() + timeout_s
    pending = bytearray()
    outbuf = bytearray()
    answers = []

    def remaining():
        r = deadline - time.monotonic()
        if r <= 0:
            raise EstimatorFailure(f"timed out after {timeout_s} s")
        return r

    def flush():
        while pending:
            _, w, _ = select.select([], [fd_in], [], remaining())
            if not w:
                continue
            try:
                n = os.write(fd_in, bytes(pending[:65536]))
            except BlockingIOError:
                continue
            except BrokenPipeError:
                raise EstimatorFailure("estimator stopped reading input (exited early?)")
            del pending[:n]

    def read_line():
        while b"\n" not in outbuf:
            r, _, _ = select.select([fd_out], [], [], remaining())
            if not r:
                continue
            chunk = os.read(fd_out, 65536)
            if not chunk:
                raise EstimatorFailure("estimator exited before answering a query")
            outbuf.extend(chunk)
        i = outbuf.index(b"\n")
        line = bytes(outbuf[:i]).decode("utf-8", errors="replace").strip()
        del outbuf[:i + 1]
        return line

    try:
        for line in lines:
            pending.extend((line + "\n").encode())
            if line.startswith("QUERY"):
                tq = float(line.split()[1])
                flush()
                resp = read_line()
                parts = resp.split()
                if len(parts) != 5:
                    raise EstimatorFailure(f"bad answer to QUERY {tq:.3f}: {resp[:120]!r}")
                try:
                    vals = [float(p) for p in parts]
                except ValueError:
                    raise EstimatorFailure(f"non numeric answer to QUERY {tq:.3f}: {resp[:120]!r}")
                if not all(math.isfinite(v) for v in vals):
                    raise EstimatorFailure(f"non finite answer to QUERY {tq:.3f}")
                if abs(vals[0] - tq) > 1e-3:
                    raise EstimatorFailure(f"answer time {vals[0]} does not match QUERY {tq:.3f}")
                answers.append(vals)
        try:
            flush()
        except EstimatorFailure:
            pass
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except OSError:
            pass
        err.close()
        shutil.rmtree(work, ignore_errors=True)
    return answers
