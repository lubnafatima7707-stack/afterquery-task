"""Message stream construction and metrics shared by the verifier."""
import csv
import json
import math
import os

import numpy as np

HEADING_MIN_SPEED = 2.0


def load_inputs(d):
    with open(os.path.join(d, "init.json")) as f:
        init = json.load(f)
    imu = np.loadtxt(os.path.join(d, "imu.csv"), delimiter=",", skiprows=1, ndmin=2)
    gnss = np.loadtxt(os.path.join(d, "gnss.csv"), delimiter=",", skiprows=1, ndmin=2)
    queries = np.loadtxt(os.path.join(d, "queries.csv"), delimiter=",", skiprows=1, ndmin=1)
    return init, imu, gnss, queries


def build_lines(init, imu, gnss, queries):
    """Time ordered protocol lines. A QUERY t is emitted only after every IMU
    and GPS message stamped at or before t."""
    events = []
    for t, a, w in imu:
        events.append((round(t, 3), 0, f"IMU {t:.3f} {a:.6f} {w:.6f}"))
    for t, x, y, vx, vy in gnss:
        events.append((round(t, 3), 1, f"GPS {t:.3f} {x:.3f} {y:.3f} {vx:.4f} {vy:.4f}"))
    for t in queries:
        events.append((round(t, 3), 2, f"QUERY {t:.3f}"))
    events.sort(key=lambda e: (e[0], e[1]))
    lines = [f"INIT {init['x']:.4f} {init['y']:.4f} {init['theta']:.6f} {init['v']:.4f}"]
    lines += [e[2] for e in events]
    lines.append("END")
    return lines


def wrap(a):
    return (a + np.pi) % (2 * np.pi) - np.pi


def outage_windows(gnss_t, min_gap=2.0):
    """GNSS outages as the instruction defines them: every interval between
    consecutive GPS lines that are more than min_gap seconds apart."""
    gt = np.asarray(gnss_t, dtype=float)
    return [(float(gt[i]), float(gt[i + 1])) for i in np.nonzero(np.diff(gt) > min_gap)[0]]


def metrics(est, truth, outages):
    """est and truth are (Q, 5) arrays of t, x, y, theta, v on the same query grid."""
    t = truth[:, 0]
    pos_err = np.hypot(est[:, 1] - truth[:, 1], est[:, 2] - truth[:, 2])
    out_mask = np.zeros(t.size, dtype=bool)
    for lo, hi in outages:
        out_mask |= (t >= lo) & (t <= hi)
    head_mask = truth[:, 4] > HEADING_MIN_SPEED
    head_err = wrap(est[:, 3] - truth[:, 3])
    return {
        "pos_rmse": float(np.sqrt(np.mean(pos_err ** 2))),
        "outage_rmse": float(np.sqrt(np.mean(pos_err[out_mask] ** 2))) if out_mask.any() else 0.0,
        "heading_rmse_deg": float(np.degrees(np.sqrt(np.mean(head_err[head_mask] ** 2)))),
    }
