"""
Sealed verifier for vehicle-ekf-fusion.

Runs the agent's /app/estimator.py on each hidden drive through the causal
line protocol (see harness.py) and scores its answers against ground truth
from the seeded simulator. Hidden drives, ground truth and this file are
readable by root only; the agent's program runs as an unprivileged user.

Every hidden drive must pass every bar. Bars were calibrated against two
independently written correct estimators on a 40 drive pool disjoint from
these hidden drives (authoring/evidence/evaluate.py, results_*.txt).
"""
import json
import os

import numpy as np
import pytest

from harness import EstimatorFailure, run_scenario
from scoring import build_lines, load_inputs, metrics, outage_windows

PROGRAM = "/app/estimator.py"
SCENARIO_DIR = "/tests/scenarios"
LOG_DIR = "/logs/verifier"
EXPECTED_SCENARIOS = 6
TIMEOUT_PER_DRIVE_S = 120

POS_RMSE_MAX_M = 3.0
OUTAGE_RMSE_MAX_M = 4.5
HEADING_RMSE_MAX_DEG = 0.8

SCENARIOS = sorted(os.listdir(SCENARIO_DIR)) if os.path.isdir(SCENARIO_DIR) else []
_results = {}


def _run(name):
    if name in _results:
        return _results[name]
    d = os.path.join(SCENARIO_DIR, name)
    init, imu, gnss, queries = load_inputs(d)
    truth = np.loadtxt(os.path.join(d, "truth.csv"), delimiter=",", skiprows=1, ndmin=2)
    outages = outage_windows(gnss[:, 0])
    lines = build_lines(init, imu, gnss, queries)
    os.makedirs(LOG_DIR, exist_ok=True)
    try:
        answers = run_scenario(PROGRAM, lines, TIMEOUT_PER_DRIVE_S,
                               os.path.join(LOG_DIR, f"estimator_stderr_{name}.txt"))
        est = np.array(answers, dtype=float)
        if est.shape != truth.shape:
            raise EstimatorFailure(f"expected {truth.shape[0]} answers, got {est.shape[0] if est.ndim else 0}")
        res = ("ok", metrics(est, truth, outages))
    except EstimatorFailure as e:
        res = ("fail", str(e))
    _results[name] = res
    try:
        with open(os.path.join(LOG_DIR, "metrics.json"), "w") as f:
            json.dump({k: v[1] for k, v in _results.items()}, f, indent=2)
    except OSError:
        pass
    return res


def test_all_hidden_drives_present():
    assert len(SCENARIOS) == EXPECTED_SCENARIOS


@pytest.mark.parametrize("name", SCENARIOS)
def test_protocol(name):
    status, info = _run(name)
    assert status == "ok", info


@pytest.mark.parametrize("name", SCENARIOS)
def test_position_rmse(name):
    status, m = _run(name)
    assert status == "ok", m
    assert m["pos_rmse"] <= POS_RMSE_MAX_M, f"{name}: position RMSE {m['pos_rmse']:.2f} m > {POS_RMSE_MAX_M} m"


@pytest.mark.parametrize("name", SCENARIOS)
def test_outage_rmse(name):
    status, m = _run(name)
    assert status == "ok", m
    assert m["outage_rmse"] <= OUTAGE_RMSE_MAX_M, f"{name}: outage RMSE {m['outage_rmse']:.2f} m > {OUTAGE_RMSE_MAX_M} m"


@pytest.mark.parametrize("name", SCENARIOS)
def test_heading_rmse(name):
    status, m = _run(name)
    assert status == "ok", m
    assert m["heading_rmse_deg"] <= HEADING_RMSE_MAX_DEG, (
        f"{name}: heading RMSE {m['heading_rmse_deg']:.2f} deg > {HEADING_RMSE_MAX_DEG} deg")
